using Microsoft.EntityFrameworkCore;
using DataApi.Models;

namespace DataApi.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<AspNetUser> AspNetUsers { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Configure AspNetUser entity
        modelBuilder.Entity<AspNetUser>(entity =>
        {
            entity.HasKey(e => e.AspNetUserId);
            
            entity.HasIndex(e => e.UserName)
                .IsUnique();
            
            entity.HasIndex(e => e.EmailAddress);

            entity.Property(e => e.AspNetUserId)
                .IsRequired()
                .HasMaxLength(128);

            entity.Property(e => e.UserName)
                .IsRequired()
                .HasMaxLength(256);

            entity.Property(e => e.EmailAddress)
                .IsRequired()
                .HasMaxLength(256);

            entity.Property(e => e.IsActive)
                .IsRequired()
                .HasDefaultValue(true);

            entity.Property(e => e.CreatedDate)
                .IsRequired()
                .HasDefaultValueSql("SYSDATE");
        });
    }
}
