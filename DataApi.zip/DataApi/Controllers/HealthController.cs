using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataApi.Data;

namespace DataApi.Controllers;

[ApiController]
[Route("[controller]")]
public class HealthController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<HealthController> _logger;

    public HealthController(ApplicationDbContext context, ILogger<HealthController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> Get()
    {
        var health = new
        {
            status = "healthy",
            timestamp = DateTime.UtcNow,
            dependencies = new Dictionary<string, string>()
        };

        try
        {
            // Check database connectivity
            await _context.Database.CanConnectAsync();
            health.dependencies["database"] = "healthy";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database health check failed");
            health.dependencies["database"] = "unhealthy";
            
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                status = "unhealthy",
                timestamp = DateTime.UtcNow,
                dependencies = health.dependencies
            });
        }

        return Ok(health);
    }
}
