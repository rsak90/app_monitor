using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataApi.Data;
using DataApi.DTOs;
using DataApi.Models;

namespace DataApi.Controllers;

[ApiController]
[Route("api/v1/[controller]")]
[Authorize]
public class AspNetUsersController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<AspNetUsersController> _logger;

    public AspNetUsersController(ApplicationDbContext context, ILogger<AspNetUsersController> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Get all AspNetUsers
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<AspNetUserDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<AspNetUserDto>>> GetAspNetUsers(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        [FromQuery] bool? isActive = null)
    {
        var query = _context.AspNetUsers.AsQueryable();

        if (isActive.HasValue)
        {
            query = query.Where(u => u.IsActive == isActive.Value);
        }

        var totalCount = await query.CountAsync();
        var users = await query
            .OrderBy(u => u.CreatedDate)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(u => new AspNetUserDto
            {
                AspNetUserId = u.AspNetUserId,
                UserName = u.UserName,
                EmailAddress = u.EmailAddress,
                IsActive = u.IsActive,
                CreatedDate = u.CreatedDate
            })
            .ToListAsync();

        Response.Headers.Append("X-Total-Count", totalCount.ToString());
        Response.Headers.Append("X-Page", page.ToString());
        Response.Headers.Append("X-Page-Size", pageSize.ToString());

        return Ok(users);
    }

    /// <summary>
    /// Get AspNetUser by ID
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(AspNetUserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<AspNetUserDto>> GetAspNetUser(string id)
    {
        var user = await _context.AspNetUsers.FindAsync(id);

        if (user == null)
        {
            _logger.LogWarning("User with ID {UserId} not found", id);
            return NotFound(new { error = "User not found", userId = id });
        }

        var userDto = new AspNetUserDto
        {
            AspNetUserId = user.AspNetUserId,
            UserName = user.UserName,
            EmailAddress = user.EmailAddress,
            IsActive = user.IsActive,
            CreatedDate = user.CreatedDate
        };

        return Ok(userDto);
    }

    /// <summary>
    /// Create a new AspNetUser
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(AspNetUserDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<AspNetUserDto>> CreateAspNetUser([FromBody] CreateAspNetUserDto createDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // Check if username already exists
        if (await _context.AspNetUsers.AnyAsync(u => u.UserName == createDto.UserName))
        {
            return BadRequest(new { error = "Username already exists", userName = createDto.UserName });
        }

        var user = new AspNetUser
        {
            AspNetUserId = Guid.NewGuid().ToString(),
            UserName = createDto.UserName,
            EmailAddress = createDto.EmailAddress,
            IsActive = createDto.IsActive,
            CreatedDate = DateTime.UtcNow
        };

        _context.AspNetUsers.Add(user);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created new user with ID {UserId}", user.AspNetUserId);

        var userDto = new AspNetUserDto
        {
            AspNetUserId = user.AspNetUserId,
            UserName = user.UserName,
            EmailAddress = user.EmailAddress,
            IsActive = user.IsActive,
            CreatedDate = user.CreatedDate
        };

        return CreatedAtAction(nameof(GetAspNetUser), new { id = user.AspNetUserId }, userDto);
    }

    /// <summary>
    /// Update an AspNetUser (full update)
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateAspNetUser(string id, [FromBody] CreateAspNetUserDto updateDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var user = await _context.AspNetUsers.FindAsync(id);
        if (user == null)
        {
            return NotFound(new { error = "User not found", userId = id });
        }

        // Check if new username conflicts with existing user
        if (updateDto.UserName != user.UserName &&
            await _context.AspNetUsers.AnyAsync(u => u.UserName == updateDto.UserName && u.AspNetUserId != id))
        {
            return BadRequest(new { error = "Username already exists", userName = updateDto.UserName });
        }

        user.UserName = updateDto.UserName;
        user.EmailAddress = updateDto.EmailAddress;
        user.IsActive = updateDto.IsActive;

        await _context.SaveChangesAsync();

        _logger.LogInformation("Updated user with ID {UserId}", id);

        return NoContent();
    }

    /// <summary>
    /// Partially update an AspNetUser
    /// </summary>
    [HttpPatch("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> PatchAspNetUser(string id, [FromBody] JsonPatchDocument<UpdateAspNetUserDto> patchDoc)
    {
        if (patchDoc == null)
        {
            return BadRequest(new { error = "Patch document is required" });
        }

        var user = await _context.AspNetUsers.FindAsync(id);
        if (user == null)
        {
            return NotFound(new { error = "User not found", userId = id });
        }

        var updateDto = new UpdateAspNetUserDto
        {
            UserName = user.UserName,
            EmailAddress = user.EmailAddress,
            IsActive = user.IsActive
        };

        patchDoc.ApplyTo(updateDto, ModelState);

        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // Apply changes
        if (updateDto.UserName != null)
        {
            // Check username uniqueness
            if (updateDto.UserName != user.UserName &&
                await _context.AspNetUsers.AnyAsync(u => u.UserName == updateDto.UserName && u.AspNetUserId != id))
            {
                return BadRequest(new { error = "Username already exists", userName = updateDto.UserName });
            }
            user.UserName = updateDto.UserName;
        }

        if (updateDto.EmailAddress != null)
        {
            user.EmailAddress = updateDto.EmailAddress;
        }

        if (updateDto.IsActive.HasValue)
        {
            user.IsActive = updateDto.IsActive.Value;
        }

        await _context.SaveChangesAsync();

        _logger.LogInformation("Patched user with ID {UserId}", id);

        return NoContent();
    }

    /// <summary>
    /// Delete an AspNetUser
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteAspNetUser(string id)
    {
        var user = await _context.AspNetUsers.FindAsync(id);
        if (user == null)
        {
            return NotFound(new { error = "User not found", userId = id });
        }

        _context.AspNetUsers.Remove(user);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Deleted user with ID {UserId}", id);

        return NoContent();
    }
}
