using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataApi.Models;

[Table("ASPNETUSERS")]
public class AspNetUser
{
    [Key]
    [Column("ASPNETUSERID")]
    [MaxLength(128)]
    public string AspNetUserId { get; set; } = string.Empty;

    [Column("USERNAME")]
    [Required]
    [MaxLength(256)]
    public string UserName { get; set; } = string.Empty;

    [Column("EMAILADDRESS")]
    [Required]
    [MaxLength(256)]
    [EmailAddress]
    public string EmailAddress { get; set; } = string.Empty;

    [Column("ISACTIVE")]
    public bool IsActive { get; set; } = true;

    [Column("CREATEDDATE")]
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
}
