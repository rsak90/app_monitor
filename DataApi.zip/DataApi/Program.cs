using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using DataApi.Data;
using DataApi.Middleware;
using DataApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Configure Kestrel for HTTPS and TLS 1.2+
builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.ConfigureHttpsDefaults(httpsOptions =>
    {
        httpsOptions.SslProtocols = System.Security.Authentication.SslProtocols.Tls12 | 
                                   System.Security.Authentication.SslProtocols.Tls13;
    });
});

// Add Application Insights
builder.Services.AddApplicationInsightsTelemetry();

// Add Key Vault service
builder.Services.AddSingleton<IKeyVaultService, KeyVaultService>();

// Configure Oracle database connection
// Connection string will be retrieved from Key Vault at runtime
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") 
    ?? "Data Source=localhost;User Id=system;Password=placeholder;";

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseOracle(connectionString));

// Add JWT Authentication
var azureAdTenantId = builder.Configuration["AzureAd:TenantId"];
var azureAdAudience = builder.Configuration["AzureAd:Audience"];

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = $"https://login.microsoftonline.com/{azureAdTenantId}/v2.0";
        options.Audience = azureAdAudience;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = $"https://sts.windows.net/{azureAdTenantId}/",
            ValidAudience = azureAdAudience
        };
    });

builder.Services.AddAuthorization();

// Configure HSTS
builder.Services.AddHsts(options =>
{
    options.Preload = true;
    options.IncludeSubDomains = true;
    options.MaxAge = TimeSpan.FromDays(365);
});

// Add controllers with JSON Patch support
builder.Services.AddControllers()
    .AddNewtonsoftJson();

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.WithOrigins(builder.Configuration.GetSection("AllowedOrigins").Get<string[]>() ?? Array.Empty<string>())
              .AllowAnyMethod()
              .AllowAnyHeader()
              .WithExposedHeaders("X-Total-Count", "X-Page", "X-Page-Size", "X-Correlation-ID");
    });
});

// Add Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Data API",
        Version = "v1",
        Description = "Secure Data API with OAuth 2.0 authentication"
    });

    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.OAuth2,
        Flows = new OpenApiOAuthFlows
        {
            ClientCredentials = new OpenApiOAuthFlow
            {
                TokenUrl = new Uri($"https://login.microsoftonline.com/{azureAdTenantId}/oauth2/v2.0/token"),
                Scopes = new Dictionary<string, string>
                {
                    { $"{azureAdAudience}/Data.Read", "Read data" },
                    { $"{azureAdAudience}/Data.Write", "Write data" },
                    { $"{azureAdAudience}/Admin", "Admin access" }
                }
            }
        }
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "oauth2"
                }
            },
            new[] { $"{azureAdAudience}/Data.Read", $"{azureAdAudience}/Data.Write" }
        }
    });
});

// Add health checks
builder.Services.AddHealthChecks();

var app = builder.Build();

// Configure middleware pipeline
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseMiddleware<CorrelationIdMiddleware>();
app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseMiddleware<ApimAuthenticationMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Enforce HTTPS redirection
app.UseHttpsRedirection();

// Add HSTS in production
if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

app.UseCors();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
