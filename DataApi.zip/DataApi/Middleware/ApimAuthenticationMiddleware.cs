namespace DataApi.Middleware;

/// <summary>
/// Middleware to validate requests from Azure API Management
/// Validates subscription key or managed identity and extracts user context from forwarded headers
/// </summary>
public class ApimAuthenticationMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ApimAuthenticationMiddleware> _logger;
    private readonly IConfiguration _configuration;

    public ApimAuthenticationMiddleware(
        RequestDelegate next,
        ILogger<ApimAuthenticationMiddleware> logger,
        IConfiguration configuration)
    {
        _next = next;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Skip authentication for health check endpoint
        if (context.Request.Path.StartsWithSegments("/health"))
        {
            await _next(context);
            return;
        }

        // Validate request comes from APIM
        if (!ValidateApimRequest(context))
        {
            _logger.LogWarning("Request rejected: Invalid APIM authentication");
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await context.Response.WriteAsJsonAsync(new
            {
                error = new
                {
                    code = "Unauthorized",
                    message = "Request must originate from Azure API Management",
                    correlationId = context.TraceIdentifier,
                    timestamp = DateTime.UtcNow
                }
            });
            return;
        }

        // Extract user context from forwarded headers
        ExtractUserContext(context);

        await _next(context);
    }

    private bool ValidateApimRequest(HttpContext context)
    {
        // Option 1: Validate APIM subscription key
        var subscriptionKey = context.Request.Headers["Ocp-Apim-Subscription-Key"].FirstOrDefault();
        var expectedSubscriptionKey = _configuration["Apim:SubscriptionKey"];

        if (!string.IsNullOrEmpty(expectedSubscriptionKey) && 
            !string.IsNullOrEmpty(subscriptionKey) &&
            subscriptionKey == expectedSubscriptionKey)
        {
            _logger.LogDebug("Request authenticated via APIM subscription key");
            return true;
        }

        // Option 2: Validate request comes from APIM via custom header
        var apimRequestId = context.Request.Headers["X-APIM-Request-Id"].FirstOrDefault();
        if (!string.IsNullOrEmpty(apimRequestId))
        {
            _logger.LogDebug("Request authenticated via APIM request ID header");
            return true;
        }

        // Option 3: Validate via managed identity (check for specific header set by APIM)
        var apimServiceName = context.Request.Headers["X-APIM-Service-Name"].FirstOrDefault();
        var expectedServiceName = _configuration["Apim:ServiceName"];
        
        if (!string.IsNullOrEmpty(expectedServiceName) &&
            !string.IsNullOrEmpty(apimServiceName) &&
            apimServiceName == expectedServiceName)
        {
            _logger.LogDebug("Request authenticated via APIM service name header");
            return true;
        }

        // In development mode, allow requests without APIM validation
        if (_configuration.GetValue<bool>("Apim:BypassValidation"))
        {
            _logger.LogWarning("APIM validation bypassed (development mode)");
            return true;
        }

        return false;
    }

    private void ExtractUserContext(HttpContext context)
    {
        // Extract client application ID from forwarded header
        var clientAppId = context.Request.Headers["X-Client-App-Id"].FirstOrDefault();
        if (!string.IsNullOrEmpty(clientAppId))
        {
            context.Items["ClientAppId"] = clientAppId;
            _logger.LogDebug("Extracted client app ID: {ClientAppId}", clientAppId);
        }

        // Extract user principal name if available
        var userPrincipalName = context.Request.Headers["X-User-Principal-Name"].FirstOrDefault();
        if (!string.IsNullOrEmpty(userPrincipalName))
        {
            context.Items["UserPrincipalName"] = userPrincipalName;
            _logger.LogDebug("Extracted user principal name: {UserPrincipalName}", userPrincipalName);
        }

        // Extract OAuth scopes from forwarded header
        var scopes = context.Request.Headers["X-OAuth-Scopes"].FirstOrDefault();
        if (!string.IsNullOrEmpty(scopes))
        {
            context.Items["OAuthScopes"] = scopes.Split(' ');
            _logger.LogDebug("Extracted OAuth scopes: {Scopes}", scopes);
        }

        // Extract client IP address (original client IP before APIM)
        var clientIp = context.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        if (!string.IsNullOrEmpty(clientIp))
        {
            context.Items["ClientIpAddress"] = clientIp.Split(',')[0].Trim();
            _logger.LogDebug("Extracted client IP: {ClientIp}", clientIp);
        }
    }
}
