using System.ComponentModel.DataAnnotations;

namespace DataApi.DTOs;

public class AspNetUserDto
{
    public string? AspNetUserId { get; set; }

    [Required(ErrorMessage = "Username is required")]
    [MaxLength(256, ErrorMessage = "Username cannot exceed 256 characters")]
    public string UserName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email address is required")]
    [EmailAddress(ErrorMessage = "Invalid email address format")]
    [MaxLength(256, ErrorMessage = "Email address cannot exceed 256 characters")]
    public string EmailAddress { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;

    public DateTime? CreatedDate { get; set; }
}

public class CreateAspNetUserDto
{
    [Required(ErrorMessage = "Username is required")]
    [MaxLength(256, ErrorMessage = "Username cannot exceed 256 characters")]
    public string UserName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email address is required")]
    [EmailAddress(ErrorMessage = "Invalid email address format")]
    [MaxLength(256, ErrorMessage = "Email address cannot exceed 256 characters")]
    public string EmailAddress { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;
}

public class UpdateAspNetUserDto
{
    [MaxLength(256, ErrorMessage = "Username cannot exceed 256 characters")]
    public string? UserName { get; set; }

    [EmailAddress(ErrorMessage = "Invalid email address format")]
    [MaxLength(256, ErrorMessage = "Email address cannot exceed 256 characters")]
    public string? EmailAddress { get; set; }

    public bool? IsActive { get; set; }
}
