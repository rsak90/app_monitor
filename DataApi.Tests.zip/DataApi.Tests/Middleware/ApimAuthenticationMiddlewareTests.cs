using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using DataApi.Middleware;

namespace DataApi.Tests.Middleware;

public class ApimAuthenticationMiddlewareTests
{
    private readonly Mock<ILogger<ApimAuthenticationMiddleware>> _loggerMock;
    private readonly Mock<IConfiguration> _configurationMock;
    private readonly Mock<RequestDelegate> _nextMock;

    public ApimAuthenticationMiddlewareTests()
    {
        _loggerMock = new Mock<ILogger<ApimAuthenticationMiddleware>>();
        _configurationMock = new Mock<IConfiguration>();
        _nextMock = new Mock<RequestDelegate>();
    }

    [Fact]
    public async Task InvokeAsync_HealthCheckEndpoint_SkipsAuthentication()
    {
        // Arrange
        var context = new DefaultHttpContext();
        context.Request.Path = "/health";
        
        var middleware = new ApimAuthenticationMiddleware(
            _nextMock.Object,
            _loggerMock.Object,
            _configurationMock.Object);

        // Act
        await middleware.InvokeAsync(context);

        // Assert
        _nextMock.Verify(next => next(context), Times.Once);
    }

    [Fact]
    public async Task InvokeAsync_ValidSubscriptionKey_AllowsRequest()
    {
        // Arrange
        var context = new DefaultHttpContext();
        context.Request.Path = "/api/v1/resources";
        context.Request.Headers["Ocp-Apim-Subscription-Key"] = "test-key";
        
        _configurationMock.Setup(c => c["Apim:SubscriptionKey"]).Returns("test-key");
        
        var middleware = new ApimAuthenticationMiddleware(
            _nextMock.Object,
            _loggerMock.Object,
            _configurationMock.Object);

        // Act
        await middleware.InvokeAsync(context);

        // Assert
        _nextMock.Verify(next => next(context), Times.Once);
    }

    [Fact]
    public async Task InvokeAsync_InvalidAuthentication_Returns401()
    {
        // Arrange
        var context = new DefaultHttpContext();
        context.Request.Path = "/api/v1/resources";
        context.Response.Body = new MemoryStream();
        
        var configSectionMock = new Mock<IConfigurationSection>();
        configSectionMock.Setup(s => s.Value).Returns("false");
        
        _configurationMock.Setup(c => c["Apim:SubscriptionKey"]).Returns("valid-key");
        _configurationMock.Setup(c => c.GetSection("Apim:BypassValidation")).Returns(configSectionMock.Object);
        
        var middleware = new ApimAuthenticationMiddleware(
            _nextMock.Object,
            _loggerMock.Object,
            _configurationMock.Object);

        // Act
        await middleware.InvokeAsync(context);

        // Assert
        Assert.Equal(StatusCodes.Status401Unauthorized, context.Response.StatusCode);
        _nextMock.Verify(next => next(context), Times.Never);
    }
}
