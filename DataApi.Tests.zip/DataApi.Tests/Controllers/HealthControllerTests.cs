using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using DataApi.Controllers;
using DataApi.Data;

namespace DataApi.Tests.Controllers;

public class HealthControllerTests
{
    private readonly Mock<ILogger<HealthController>> _loggerMock;

    public HealthControllerTests()
    {
        _loggerMock = new Mock<ILogger<HealthController>>();
    }

    [Fact]
    public async Task Get_DatabaseHealthy_ReturnsOk()
    {
        // Arrange
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb_Healthy")
            .Options;
        
        using var context = new ApplicationDbContext(options);
        var controller = new HealthController(context, _loggerMock.Object);

        // Act
        var result = await controller.Get();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(200, okResult.StatusCode);
    }

    [Fact]
    public async Task Get_DatabaseUnhealthy_Returns503()
    {
        // Arrange
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb_Unhealthy")
            .Options;
        
        using var context = new ApplicationDbContext(options);
        
        // Dispose the context to simulate database failure
        await context.DisposeAsync();
        
        var controller = new HealthController(context, _loggerMock.Object);

        // Act
        var result = await controller.Get();

        // Assert
        var statusResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(503, statusResult.StatusCode);
    }
}
