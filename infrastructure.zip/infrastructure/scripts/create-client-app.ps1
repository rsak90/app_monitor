# Script to create a client application for testing
param(
    [Parameter(Mandatory=$true)]
    [string]$ClientAppName,
    
    [Parameter(Mandatory=$true)]
    [string]$ApiApplicationId,
    
    [Parameter(Mandatory=$false)]
    [string]$Environment = "dev"
)

Write-Host "Creating client application: $ClientAppName-$Environment" -ForegroundColor Cyan

# Create client app registration
$clientApp = az ad app create `
    --display-name "$ClientAppName-$Environment" `
    --sign-in-audience "AzureADMyOrg" | ConvertFrom-Json

$clientAppId = $clientApp.appId
$clientObjectId = $clientApp.id

Write-Host "Created client application: $clientAppId" -ForegroundColor Green

# Create client secret
Write-Host "Creating client secret..." -ForegroundColor Cyan
$clientSecret = az ad app credential reset --id $clientObjectId --append | ConvertFrom-Json

Write-Host "Client secret created (expires: $($clientSecret.endDateTime))" -ForegroundColor Green

# Grant API permissions
Write-Host "Granting API permissions..." -ForegroundColor Cyan

# Get API service principal
$apiSp = az ad sp list --filter "appId eq '$ApiApplicationId'" | ConvertFrom-Json
if ($apiSp.Count -eq 0) {
    Write-Error "API service principal not found. Please run configure-azure-ad.ps1 first."
    exit 1
}

$apiSpId = $apiSp[0].id

# Add required resource access
$requiredResourceAccess = @{
    resourceAppId = $ApiApplicationId
    resourceAccess = @(
        @{
            id = (az ad sp show --id $apiSpId --query "oauth2PermissionScopes[?value=='Data.Read'].id" -o tsv)
            type = "Scope"
        },
        @{
            id = (az ad sp show --id $apiSpId --query "oauth2PermissionScopes[?value=='Data.Write'].id" -o tsv)
            type = "Scope"
        }
    )
}

$resourceAccessJson = $requiredResourceAccess | ConvertTo-Json -Depth 10 -Compress
az ad app update --id $clientObjectId --required-resource-accesses "[$resourceAccessJson]"

Write-Host "API permissions granted" -ForegroundColor Green

# Create service principal for client
az ad sp create --id $clientAppId

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Client Application Created" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Client Application ID: $clientAppId" -ForegroundColor White
Write-Host "Client Secret: $($clientSecret.password)" -ForegroundColor Yellow
Write-Host "`nIMPORTANT: Save the client secret securely!" -ForegroundColor Red
Write-Host "`nToken Endpoint:" -ForegroundColor White
Write-Host "https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token" -ForegroundColor White
Write-Host "`nTo get an access token, use:" -ForegroundColor White
Write-Host "POST https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token" -ForegroundColor Gray
Write-Host "Content-Type: application/x-www-form-urlencoded" -ForegroundColor Gray
Write-Host "" -ForegroundColor Gray
Write-Host "grant_type=client_credentials" -ForegroundColor Gray
Write-Host "&client_id=$clientAppId" -ForegroundColor Gray
Write-Host "&client_secret={client-secret}" -ForegroundColor Gray
Write-Host "&scope=$ApiApplicationId/.default" -ForegroundColor Gray
Write-Host "========================================`n" -ForegroundColor Cyan

# Save client configuration
$clientConfig = @{
    clientApplicationId = $clientAppId
    clientSecret = $clientSecret.password
    apiApplicationId = $ApiApplicationId
    environment = $Environment
    tokenEndpoint = "https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token"
}

$configPath = "infrastructure/config/client-app-$ClientAppName-$Environment.json"
$clientConfig | ConvertTo-Json -Depth 10 | Out-File -FilePath $configPath -Encoding UTF8
Write-Host "Client configuration saved to: $configPath" -ForegroundColor Green
