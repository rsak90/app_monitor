# Script to set up Key Vault secrets
param(
    [Parameter(Mandatory=$true)]
    [string]$KeyVaultName,
    
    [Parameter(Mandatory=$true)]
    [string]$OracleConnectionString,
    
    [Parameter(Mandatory=$false)]
    [string]$Environment = "dev"
)

Write-Host "Setting up secrets in Key Vault: $KeyVaultName" -ForegroundColor Cyan

# Check if Key Vault exists
$kvExists = az keyvault show --name $KeyVaultName 2>$null
if (-not $kvExists) {
    Write-Error "Key Vault '$KeyVaultName' not found. Please deploy infrastructure first."
    exit 1
}

# Set Oracle connection string
Write-Host "Setting Oracle connection string..." -ForegroundColor Cyan
az keyvault secret set `
    --vault-name $KeyVaultName `
    --name "OracleConnectionString" `
    --value $OracleConnectionString `
    --description "Oracle database connection string for $Environment environment" | Out-Null

Write-Host "Oracle connection string set successfully" -ForegroundColor Green

# Set other secrets as needed
Write-Host "`nSetting additional secrets..." -ForegroundColor Cyan

# Example: API keys, certificates, etc.
# az keyvault secret set --vault-name $KeyVaultName --name "ApiKey" --value "your-api-key"

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Key Vault Secrets Configuration Complete" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Key Vault: $KeyVaultName" -ForegroundColor White
Write-Host "Environment: $Environment" -ForegroundColor White
Write-Host "`nSecrets configured:" -ForegroundColor White
Write-Host "  - OracleConnectionString" -ForegroundColor White
Write-Host "`nSecret URIs:" -ForegroundColor White

$kvUri = az keyvault show --name $KeyVaultName --query properties.vaultUri -o tsv
Write-Host "  Oracle: ${kvUri}secrets/OracleConnectionString" -ForegroundColor Gray

Write-Host "`nAccess these secrets in your application using:" -ForegroundColor Yellow
Write-Host "  - Managed Identity authentication" -ForegroundColor White
Write-Host "  - Azure.Identity SDK" -ForegroundColor White
Write-Host "========================================`n" -ForegroundColor Cyan

# List all secrets (names only, not values)
Write-Host "Current secrets in Key Vault:" -ForegroundColor Cyan
az keyvault secret list --vault-name $KeyVaultName --query "[].name" -o table
