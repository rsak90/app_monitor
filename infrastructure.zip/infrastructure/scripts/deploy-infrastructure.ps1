# Deploy Azure infrastructure using Bicep
param(
    [Parameter(Mandatory=$true)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory=$true)]
    [string]$Location,
    
    [Parameter(Mandatory=$false)]
    [string]$Environment = "dev",
    
    [Parameter(Mandatory=$false)]
    [string]$ParametersFile = "infrastructure/parameters/$Environment.parameters.json"
)

Write-Host "Deploying infrastructure to $Environment environment..." -ForegroundColor Cyan

# Create resource group if it doesn't exist
$rgExists = az group exists --name $ResourceGroupName
if ($rgExists -eq "false") {
    Write-Host "Creating resource group $ResourceGroupName..." -ForegroundColor Cyan
    az group create --name $ResourceGroupName --location $Location
    Write-Host "Resource group created" -ForegroundColor Green
}

# Deploy Bicep template
Write-Host "Deploying Bicep template..." -ForegroundColor Cyan
$deploymentName = "infrastructure-deployment-$(Get-Date -Format 'yyyyMMddHHmmss')"

az deployment group create `
    --name $deploymentName `
    --resource-group $ResourceGroupName `
    --template-file infrastructure/main.bicep `
    --parameters $ParametersFile `
    --verbose

if ($LASTEXITCODE -eq 0) {
    Write-Host "`nDeployment completed successfully!" -ForegroundColor Green
    
    # Get deployment outputs
    $outputs = az deployment group show `
        --name $deploymentName `
        --resource-group $ResourceGroupName `
        --query properties.outputs -o json | ConvertFrom-Json
    
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "Deployment Outputs" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "APIM Gateway URL: $($outputs.apimGatewayUrl.value)" -ForegroundColor White
    Write-Host "Backend API URL: $($outputs.backendApiUrl.value)" -ForegroundColor White
    Write-Host "Key Vault Name: $($outputs.keyVaultName.value)" -ForegroundColor White
    Write-Host "App Insights Name: $($outputs.appInsightsName.value)" -ForegroundColor White
    Write-Host "========================================`n" -ForegroundColor Cyan
} else {
    Write-Error "Deployment failed. Check the error messages above."
    exit 1
}
