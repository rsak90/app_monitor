# Azure AD App Registration Configuration Script
# This script creates and configures Azure AD app registrations for the API

param(
    [Parameter(Mandatory=$true)]
    [string]$ApiAppName,
    
    [Parameter(Mandatory=$true)]
    [string]$TenantId,
    
    [Parameter(Mandatory=$false)]
    [string]$Environment = "dev"
)

# Ensure Azure CLI is installed and logged in
Write-Host "Checking Azure CLI authentication..." -ForegroundColor Cyan
$account = az account show 2>$null | ConvertFrom-Json
if (-not $account) {
    Write-Error "Not logged in to Azure CLI. Please run 'az login' first."
    exit 1
}

Write-Host "Logged in as: $($account.user.name)" -ForegroundColor Green
Write-Host "Tenant: $($account.tenantId)" -ForegroundColor Green

# Create API Application Registration
Write-Host "`nCreating API application registration..." -ForegroundColor Cyan
$apiAppIdUri = "api://$ApiAppName-$Environment"

# Check if app already exists
$existingApp = az ad app list --filter "displayName eq '$ApiAppName-$Environment'" | ConvertFrom-Json
if ($existingApp.Count -gt 0) {
    Write-Host "Application '$ApiAppName-$Environment' already exists. Using existing app." -ForegroundColor Yellow
    $apiAppId = $existingApp[0].appId
    $apiObjectId = $existingApp[0].id
} else {
    # Create new app registration
    $apiApp = az ad app create `
        --display-name "$ApiAppName-$Environment" `
        --sign-in-audience "AzureADMyOrg" `
        --identifier-uris $apiAppIdUri | ConvertFrom-Json
    
    $apiAppId = $apiApp.appId
    $apiObjectId = $apiApp.id
    Write-Host "Created API application: $apiAppId" -ForegroundColor Green
}

# Define OAuth 2.0 scopes
Write-Host "`nConfiguring OAuth 2.0 scopes..." -ForegroundColor Cyan

$scopes = @(
    @{
        adminConsentDescription = "Allows the application to read data"
        adminConsentDisplayName = "Read data"
        id = (New-Guid).Guid
        isEnabled = $true
        type = "User"
        userConsentDescription = "Allows the application to read data on your behalf"
        userConsentDisplayName = "Read data"
        value = "Data.Read"
    },
    @{
        adminConsentDescription = "Allows the application to write data"
        adminConsentDisplayName = "Write data"
        id = (New-Guid).Guid
        isEnabled = $true
        type = "User"
        userConsentDescription = "Allows the application to write data on your behalf"
        userConsentDisplayName = "Write data"
        value = "Data.Write"
    },
    @{
        adminConsentDescription = "Allows the application to perform administrative operations"
        adminConsentDisplayName = "Admin access"
        id = (New-Guid).Guid
        isEnabled = $true
        type = "Admin"
        userConsentDescription = "Allows the application to perform administrative operations on your behalf"
        userConsentDisplayName = "Admin access"
        value = "Admin"
    }
)

$oauth2Permissions = @{
    oauth2PermissionScopes = $scopes
}

$oauth2Json = $oauth2Permissions | ConvertTo-Json -Depth 10 -Compress

# Update app with scopes
az ad app update --id $apiObjectId --set api="$oauth2Json"
Write-Host "Configured OAuth 2.0 scopes: Data.Read, Data.Write, Admin" -ForegroundColor Green

# Configure token settings
Write-Host "`nConfiguring token settings..." -ForegroundColor Cyan
az ad app update --id $apiObjectId `
    --set accessTokenAcceptedVersion=2 `
    --set optionalClaims.accessToken='[{\"name\":\"email\",\"essential\":false},{\"name\":\"groups\",\"essential\":false}]'

Write-Host "Token configuration completed" -ForegroundColor Green

# Create service principal if it doesn't exist
Write-Host "`nCreating service principal..." -ForegroundColor Cyan
$existingSp = az ad sp list --filter "appId eq '$apiAppId'" | ConvertFrom-Json
if ($existingSp.Count -eq 0) {
    az ad sp create --id $apiAppId
    Write-Host "Service principal created" -ForegroundColor Green
} else {
    Write-Host "Service principal already exists" -ForegroundColor Yellow
}

# Output configuration details
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Azure AD Configuration Complete" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "API Application ID: $apiAppId" -ForegroundColor White
Write-Host "API Application ID URI: $apiAppIdUri" -ForegroundColor White
Write-Host "Tenant ID: $TenantId" -ForegroundColor White
Write-Host "`nConfigured Scopes:" -ForegroundColor White
Write-Host "  - Data.Read" -ForegroundColor White
Write-Host "  - Data.Write" -ForegroundColor White
Write-Host "  - Admin" -ForegroundColor White
Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Grant admin consent for the API permissions in Azure Portal" -ForegroundColor White
Write-Host "2. Create client applications and grant them access to these scopes" -ForegroundColor White
Write-Host "3. Update APIM configuration with the Application ID URI" -ForegroundColor White
Write-Host "========================================`n" -ForegroundColor Cyan

# Save configuration to file
$config = @{
    apiApplicationId = $apiAppId
    apiApplicationIdUri = $apiAppIdUri
    tenantId = $TenantId
    environment = $Environment
    scopes = @("Data.Read", "Data.Write", "Admin")
}

$configPath = "infrastructure/config/azure-ad-config-$Environment.json"
$config | ConvertTo-Json -Depth 10 | Out-File -FilePath $configPath -Encoding UTF8
Write-Host "Configuration saved to: $configPath" -ForegroundColor Green
