# Security Configuration Guide

## Overview

This guide provides comprehensive instructions for configuring security aspects of the Data API, including Azure AD app registrations, client onboarding, security best practices, and secret rotation procedures.

**Security Principles:**
- Defense in depth
- Principle of least privilege
- Zero trust architecture
- Secure by default
- Regular security audits

## Table of Contents

1. [Azure AD App Registration](#azure-ad-app-registration)
2. [Client Onboarding Process](#client-onboarding-process)
3. [Security Best Practices](#security-best-practices)
4. [Secret Rotation Procedures](#secret-rotation-procedures)
5. [Security Monitoring](#security-monitoring)
6. [Incident Response](#incident-response)
7. [Compliance and Auditing](#compliance-and-auditing)

---

## Azure AD App Registration

### API Application Registration

The API application represents the protected resource in Azure AD.

#### Step 1: Create API Application

**Using Azure Portal:**

1. Navigate to Azure Portal > Azure Active Directory > App registrations
2. Click "New registration"
3. Configure the application:
   - **Name**: `DataApi-{environment}` (e.g., DataApi-prod)
   - **Supported account types**: "Accounts in this organizational directory only"
   - **Redirect URI**: Leave blank (not needed for API)
4. Click "Register"

**Using PowerShell:**

```powershell
# Run the automated script
cd infrastructure/scripts
./configure-azure-ad.ps1 `
    -ApiAppName "DataApi" `
    -TenantId "your-tenant-id" `
    -Environment "prod"
```

**Using Azure CLI:**

```bash
# Create app registration
az ad app create \
    --display-name "DataApi-prod" \
    --sign-in-audience "AzureADMyOrg" \
    --identifier-uris "api://DataApi-prod"
```


#### Step 2: Configure Application ID URI

The Application ID URI uniquely identifies your API.

**Format:** `api://{app-name}-{environment}`  
**Example:** `api://DataApi-prod`

**Using Azure Portal:**
1. Go to App registration > Expose an API
2. Click "Set" next to Application ID URI
3. Enter: `api://DataApi-prod`
4. Click "Save"

**Using Azure CLI:**
```bash
az ad app update \
    --id {app-id} \
    --identifier-uris "api://DataApi-prod"
```

#### Step 3: Define OAuth 2.0 Scopes

Create three scopes for different permission levels:

| Scope | Value | Description | Consent Type |
|-------|-------|-------------|--------------|
| Read Data | `Data.Read` | Read access to data resources | User or Admin |
| Write Data | `Data.Write` | Write access to data resources | User or Admin |
| Admin Access | `Admin` | Administrative access including delete | Admin only |

**Using Azure Portal:**

1. Go to App registration > Expose an API
2. Click "Add a scope"
3. For each scope, configure:

**Data.Read Scope:**
- **Scope name**: `Data.Read`
- **Who can consent**: Admins and users
- **Admin consent display name**: Read data
- **Admin consent description**: Allows the application to read data
- **User consent display name**: Read data
- **User consent description**: Allows the application to read data on your behalf
- **State**: Enabled

**Data.Write Scope:**
- **Scope name**: `Data.Write`
- **Who can consent**: Admins and users
- **Admin consent display name**: Write data
- **Admin consent description**: Allows the application to write data
- **User consent display name**: Write data
- **User consent description**: Allows the application to write data on your behalf
- **State**: Enabled

**Admin Scope:**
- **Scope name**: `Admin`
- **Who can consent**: Admins only
- **Admin consent display name**: Admin access
- **Admin consent description**: Allows the application to perform administrative operations
- **State**: Enabled


#### Step 4: Configure Token Settings

**Using Azure Portal:**
1. Go to App registration > Token configuration
2. Configure access token version:
   - Click "Add optional claim"
   - Select "Access"
   - Add claims: `email`, `groups` (if needed)
3. Go to Manifest
4. Set `accessTokenAcceptedVersion` to `2`
5. Click "Save"

**Token Configuration:**
```json
{
  "accessTokenAcceptedVersion": 2,
  "optionalClaims": {
    "accessToken": [
      {
        "name": "email",
        "essential": false
      },
      {
        "name": "groups",
        "essential": false
      }
    ]
  }
}
```

#### Step 5: Create Service Principal

```bash
# Create service principal for the API app
az ad sp create --id {api-app-id}

# Verify service principal creation
az ad sp show --id {api-app-id}
```

#### Step 6: Grant Admin Consent

**Important:** Admin consent must be granted for the API to function properly.

**Using Azure Portal:**
1. Go to App registration > API permissions
2. Click "Grant admin consent for {tenant}"
3. Confirm the consent

**Verification:**
- All permissions show "Granted for {tenant}" in green
- Status column shows checkmark

---

## Client Onboarding Process

### Overview

This process onboards new client applications that will consume the Data API.

### Prerequisites

Before onboarding a client:
- [ ] Client organization is verified
- [ ] Use case is documented and approved
- [ ] Required scopes are identified
- [ ] Security review is completed
- [ ] Service agreement is signed


### Step 1: Create Client Application Registration

**Using Azure Portal:**

1. Navigate to Azure AD > App registrations
2. Click "New registration"
3. Configure:
   - **Name**: `{ClientName}-DataApiClient-{environment}`
   - **Supported account types**: "Accounts in this organizational directory only"
   - **Redirect URI**: Leave blank for service-to-service
4. Click "Register"
5. Note the **Application (client) ID**

**Using PowerShell Script:**

```powershell
cd infrastructure/scripts
./create-client-app.ps1 `
    -ClientName "PartnerApp" `
    -TenantId "your-tenant-id" `
    -Environment "prod" `
    -RequiredScopes @("Data.Read", "Data.Write")
```

### Step 2: Configure Client Authentication

Choose one of two authentication methods:

#### Option A: Client Secret (Recommended for Development)

**Using Azure Portal:**
1. Go to client app > Certificates & secrets
2. Click "New client secret"
3. Configure:
   - **Description**: "DataApi Access - Expires {date}"
   - **Expires**: 6 months or 12 months (not 24 months)
4. Click "Add"
5. **Important**: Copy the secret value immediately (it won't be shown again)
6. Store securely in client's Key Vault

**Using Azure CLI:**
```bash
az ad app credential reset \
    --id {client-app-id} \
    --append \
    --display-name "DataApi Access" \
    --years 1
```

**Security Notes:**
- Never share secrets via email or chat
- Store in Key Vault or secure secret management system
- Set expiration reminders
- Rotate before expiration

#### Option B: Certificate (Recommended for Production)

**Using Azure Portal:**
1. Generate certificate (or use existing):
```powershell
# Generate self-signed certificate (for testing)
$cert = New-SelfSignedCertificate `
    -Subject "CN=DataApiClient" `
    -CertStoreLocation "Cert:\CurrentUser\My" `
    -KeyExportPolicy Exportable `
    -KeySpec Signature `
    -KeyLength 2048 `
    -KeyAlgorithm RSA `
    -HashAlgorithm SHA256 `
    -NotAfter (Get-Date).AddYears(2)

# Export certificate
Export-Certificate -Cert $cert -FilePath "DataApiClient.cer"
```

2. Upload to Azure AD:
   - Go to client app > Certificates & secrets
   - Click "Upload certificate"
   - Select the .cer file
   - Click "Add"

**Security Notes:**
- Use certificates from trusted CA for production
- Protect private key with strong encryption
- Store private key in Hardware Security Module (HSM) if possible
- Set certificate expiration monitoring


### Step 3: Grant API Permissions

**Using Azure Portal:**

1. Go to client app > API permissions
2. Click "Add a permission"
3. Select "My APIs" tab
4. Select "DataApi-prod"
5. Select "Application permissions" (for service-to-service)
6. Check the required scopes:
   - `Data.Read` (if read access needed)
   - `Data.Write` (if write access needed)
   - `Admin` (if admin access needed)
7. Click "Add permissions"
8. Click "Grant admin consent for {tenant}"

**Using Azure CLI:**
```bash
# Get API app service principal ID
API_SP_ID=$(az ad sp list --filter "displayName eq 'DataApi-prod'" --query "[0].id" -o tsv)

# Get scope IDs
DATA_READ_SCOPE_ID=$(az ad sp show --id $API_SP_ID --query "oauth2PermissionScopes[?value=='Data.Read'].id" -o tsv)

# Add API permission
az ad app permission add \
    --id {client-app-id} \
    --api {api-app-id} \
    --api-permissions $DATA_READ_SCOPE_ID=Scope

# Grant admin consent
az ad app permission admin-consent --id {client-app-id}
```

**Permission Matrix:**

| Client Use Case | Required Scopes |
|----------------|-----------------|
| Read-only reporting | `Data.Read` |
| Data synchronization | `Data.Read`, `Data.Write` |
| Full management | `Data.Read`, `Data.Write`, `Admin` |
| Administrative tools | `Admin` |

### Step 4: Configure IP Restrictions (Optional)

If the client has static IP addresses, add them to the APIM IP filter:

```powershell
# Update APIM policy with client IP ranges
# Edit infrastructure/apim-policies/api-policy.xml
# Add to ip-filter section:
<address-range from="client-ip-start" to="client-ip-end" />
```

### Step 5: Test Client Access

Provide the client with test credentials and documentation:

**Test Script:**
```powershell
# Test token acquisition
$tokenResponse = Invoke-RestMethod -Method Post `
    -Uri "https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token" `
    -Body @{
        grant_type = "client_credentials"
        client_id = "{client-id}"
        client_secret = "{client-secret}"
        scope = "api://DataApi-prod/.default"
    }

# Test API access
$headers = @{
    Authorization = "Bearer $($tokenResponse.access_token)"
}

Invoke-RestMethod -Uri "https://apim-dataapi-prod.azure-api.net/api/v1/health" `
    -Headers $headers
```

**Expected Results:**
- Token acquisition succeeds
- Health endpoint returns 200 OK
- Appropriate scopes are in the token


### Step 6: Document Client Configuration

Create a client configuration document:

**Client Information:**
- Client Name: {name}
- Application ID: {client-id}
- Granted Scopes: {scopes}
- IP Addresses: {ip-ranges}
- Contact: {email}
- Onboarding Date: {date}
- Secret Expiration: {date}
- Review Date: {date}

**Store in secure location** (e.g., SharePoint with restricted access)

### Step 7: Provide Client Documentation

Send the client:
- [ ] API Documentation (docs/API_DOCUMENTATION.md)
- [ ] Client ID and Secret (via secure channel)
- [ ] Tenant ID
- [ ] API Base URL
- [ ] Code examples for their platform
- [ ] Support contact information
- [ ] Rate limit information (100 req/min)

### Client Offboarding

When a client no longer needs access:

1. **Disable the client application:**
```bash
az ad app update --id {client-app-id} --set "availableToOtherTenants=false"
```

2. **Revoke API permissions:**
   - Go to client app > API permissions
   - Remove all Data API permissions

3. **Delete client secrets/certificates:**
   - Go to Certificates & secrets
   - Delete all secrets and certificates

4. **Monitor for unauthorized access attempts:**
   - Check logs for the client ID
   - Set up alert for access attempts

5. **Document offboarding:**
   - Update client registry
   - Note offboarding date and reason
   - Archive configuration

---

## Security Best Practices

### Authentication Best Practices

1. **Use Certificate Authentication in Production**
   - More secure than client secrets
   - Harder to accidentally expose
   - Can be stored in HSM

2. **Implement Token Caching**
   - Cache tokens until expiration
   - Reduces authentication overhead
   - Improves performance

3. **Never Log Tokens or Secrets**
   - Sanitize logs before storage
   - Use correlation IDs for tracking
   - Implement log access controls

4. **Validate Token Claims**
   - Always validate audience (`aud`)
   - Check issuer (`iss`)
   - Verify expiration (`exp`)
   - Validate scopes (`scp`)


### Authorization Best Practices

1. **Principle of Least Privilege**
   - Grant minimum required scopes
   - Review permissions quarterly
   - Remove unused permissions promptly

2. **Scope-Based Access Control**
   - Use fine-grained scopes
   - Implement scope validation in policies
   - Document scope requirements

3. **Regular Access Reviews**
   - Review client permissions quarterly
   - Audit scope usage
   - Remove inactive clients

### Network Security Best Practices

1. **Use TLS 1.2 or Higher**
   - Disable TLS 1.0 and 1.1
   - Use strong cipher suites
   - Enable HSTS headers

2. **Implement IP Filtering**
   - Whitelist known client IPs
   - Use CIDR notation for ranges
   - Document IP changes

3. **Enable DDoS Protection**
   - Use Azure DDoS Protection Standard
   - Configure rate limiting
   - Monitor for anomalies

### Data Protection Best Practices

1. **Encrypt Data at Rest**
   - Enable Transparent Data Encryption (TDE) on SQL Database
   - Use encrypted storage accounts
   - Encrypt Key Vault secrets

2. **Encrypt Data in Transit**
   - Enforce HTTPS only
   - Use TLS 1.2+
   - Implement certificate pinning (for mobile apps)

3. **Implement Data Masking**
   - Mask sensitive data in logs
   - Use dynamic data masking in database
   - Sanitize error messages

### Monitoring and Logging Best Practices

1. **Enable Comprehensive Logging**
   - Log all authentication attempts
   - Log authorization failures
   - Log rate limit violations
   - Log policy violations

2. **Implement Security Monitoring**
   - Set up alerts for suspicious activity
   - Monitor for brute force attempts
   - Track unusual access patterns
   - Alert on configuration changes

3. **Regular Log Review**
   - Review security logs weekly
   - Investigate anomalies promptly
   - Document security incidents
   - Conduct quarterly security audits


---

## Secret Rotation Procedures

### Overview

Regular secret rotation is critical for maintaining security. This section covers rotation procedures for all secrets and certificates.

### Rotation Schedule

| Secret Type | Rotation Frequency | Lead Time |
|-------------|-------------------|-----------|
| Client Secrets | Every 6 months | 2 weeks |
| Certificates | Every 12 months | 1 month |
| SQL Passwords | Every 90 days | 1 week |
| API Keys | Every 6 months | 2 weeks |
| Connection Strings | When credentials change | Immediate |

### Client Secret Rotation

**Timeline:** 2 weeks before expiration

#### Step 1: Generate New Secret (T-14 days)

```bash
# Create new secret for client app
az ad app credential reset \
    --id {client-app-id} \
    --append \
    --display-name "DataApi Access - New" \
    --years 1
```

**Important:** Use `--append` to keep the old secret active during transition.

#### Step 2: Notify Client (T-14 days)

Send notification to client:

**Subject:** Action Required: API Client Secret Rotation

**Body:**
```
Dear {Client Name},

Your Data API client secret will expire on {expiration-date}.

New Secret Information:
- Client ID: {client-id} (unchanged)
- New Secret: {new-secret}
- Effective Date: {date}
- Old Secret Expiration: {date}

Action Required:
1. Update your application configuration with the new secret
2. Test in your development environment
3. Deploy to production before {date}
4. Confirm successful rotation by {date}

The old secret will remain valid until {date} to allow for transition.

Support: {support-email}
```

#### Step 3: Monitor Transition (T-7 to T-0 days)

```powershell
# Monitor token requests by secret
az monitor log-analytics query \
    --workspace "log-dataapi-prod" \
    --analytics-query "
        AADServicePrincipalSignInLogs
        | where AppId == '{client-app-id}'
        | where TimeGenerated > ago(7d)
        | summarize count() by CredentialId
    "
```

#### Step 4: Verify New Secret Usage (T-0 days)

Confirm with client that:
- [ ] New secret is deployed to all environments
- [ ] Application is functioning correctly
- [ ] No errors in their logs
- [ ] Token acquisition succeeds


#### Step 5: Remove Old Secret (T+7 days)

After confirming successful transition:

```bash
# List all credentials
az ad app credential list --id {client-app-id}

# Delete old credential
az ad app credential delete \
    --id {client-app-id} \
    --key-id {old-credential-key-id}
```

**Verification:**
- Monitor logs for authentication failures
- Confirm no usage of old secret
- Document rotation completion

### Certificate Rotation

**Timeline:** 1 month before expiration

#### Step 1: Generate New Certificate (T-30 days)

```powershell
# Generate new certificate
$cert = New-SelfSignedCertificate `
    -Subject "CN=DataApiClient" `
    -CertStoreLocation "Cert:\CurrentUser\My" `
    -KeyExportPolicy Exportable `
    -KeySpec Signature `
    -KeyLength 2048 `
    -KeyAlgorithm RSA `
    -HashAlgorithm SHA256 `
    -NotAfter (Get-Date).AddYears(2)

# Export certificate
Export-Certificate -Cert $cert -FilePath "DataApiClient-New.cer"

# Export private key (password protected)
$password = ConvertTo-SecureString -String "StrongPassword123!" -Force -AsPlainText
Export-PfxCertificate -Cert $cert -FilePath "DataApiClient-New.pfx" -Password $password
```

#### Step 2: Upload New Certificate (T-30 days)

```bash
# Upload to Azure AD (keeps old certificate active)
az ad app credential reset \
    --id {client-app-id} \
    --cert @DataApiClient-New.cer \
    --append
```

#### Step 3: Distribute New Certificate (T-30 days)

Securely provide the client with:
- New certificate file (.pfx)
- Certificate password (via separate secure channel)
- Installation instructions
- Transition timeline

#### Step 4: Client Updates Configuration (T-14 to T-0 days)

Client should:
1. Install new certificate in their certificate store
2. Update application configuration
3. Test in development environment
4. Deploy to production
5. Confirm successful authentication

#### Step 5: Remove Old Certificate (T+7 days)

```bash
# List certificates
az ad app credential list --id {client-app-id}

# Delete old certificate
az ad app credential delete \
    --id {client-app-id} \
    --key-id {old-cert-key-id}
```


### SQL Database Password Rotation

**Timeline:** Every 90 days

#### Step 1: Generate New Password

```powershell
# Generate strong password
Add-Type -AssemblyName 'System.Web'
$newPassword = [System.Web.Security.Membership]::GeneratePassword(32, 8)
```

#### Step 2: Update SQL Server

```bash
# Update SQL admin password
az sql server update \
    --resource-group "rg-dataapi-prod" \
    --name "sql-dataapi-prod" \
    --admin-password $newPassword
```

#### Step 3: Update Connection String in Key Vault

```bash
# Build new connection string
$connectionString = "Server=tcp:sql-dataapi-prod.database.windows.net,1433;Database=DataApiDb;User ID=sqladmin;Password=$newPassword;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"

# Update Key Vault secret
az keyvault secret set \
    --vault-name "kv-dataapi-prod" \
    --name "SqlConnectionString" \
    --value $connectionString
```

#### Step 4: Restart Backend API

```bash
# Restart App Service to pick up new connection string
az webapp restart \
    --resource-group "rg-dataapi-prod" \
    --name "app-dataapi-prod"
```

#### Step 5: Verify Connectivity

```powershell
# Test health endpoint
Invoke-WebRequest -Uri "https://app-dataapi-prod.azurewebsites.net/health"

# Check application logs
az webapp log tail \
    --resource-group "rg-dataapi-prod" \
    --name "app-dataapi-prod"
```

### Key Vault Secret Rotation

For secrets stored in Key Vault:

#### Automated Rotation (Recommended)

```bash
# Enable automatic rotation for secrets
az keyvault secret set-attributes \
    --vault-name "kv-dataapi-prod" \
    --name "SqlConnectionString" \
    --enabled true \
    --expires "2026-02-18T00:00:00Z"

# Configure rotation policy
az keyvault secret rotation-policy update \
    --vault-name "kv-dataapi-prod" \
    --name "SqlConnectionString" \
    --value @rotation-policy.json
```

**rotation-policy.json:**
```json
{
  "lifetimeActions": [
    {
      "trigger": {
        "timeBeforeExpiry": "P30D"
      },
      "action": {
        "type": "Notify"
      }
    }
  ],
  "attributes": {
    "expiryTime": "P90D"
  }
}
```

### Rotation Tracking

Maintain a rotation log:

| Secret Type | Last Rotated | Next Rotation | Owner | Status |
|-------------|--------------|---------------|-------|--------|
| Client Secret - PartnerApp | 2025-11-01 | 2026-05-01 | John Doe | Active |
| SQL Password | 2025-10-15 | 2026-01-15 | Jane Smith | Active |
| Certificate - ClientX | 2025-09-01 | 2026-09-01 | Bob Johnson | Active |


---

## Security Monitoring

### Key Security Metrics

Monitor these metrics continuously:

1. **Authentication Metrics**
   - Failed authentication attempts
   - Token validation failures
   - Unusual authentication patterns
   - Authentication from new locations

2. **Authorization Metrics**
   - Scope validation failures
   - Unauthorized access attempts
   - Privilege escalation attempts
   - Access to sensitive endpoints

3. **Rate Limiting Metrics**
   - Rate limit violations
   - Clients approaching limits
   - Unusual request patterns
   - Potential DDoS attacks

4. **Security Policy Metrics**
   - Policy validation failures
   - IP filter violations
   - CORS policy violations
   - Request size violations

### Security Alerts

Configure alerts for security events:

```bash
# Alert for high authentication failure rate
az monitor metrics alert create \
    --name "High Auth Failure Rate" \
    --resource-group "rg-dataapi-prod" \
    --scopes "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.ApiManagement/service/apim-dataapi-prod" \
    --condition "total failed requests > 100" \
    --window-size 5m \
    --evaluation-frequency 1m \
    --severity 2
```

**Alert Thresholds:**

| Alert | Threshold | Severity | Action |
|-------|-----------|----------|--------|
| Authentication failures | >100 in 5 min | High | Investigate immediately |
| Rate limit violations | >50 in 5 min | Medium | Review client behavior |
| Unauthorized access | >10 in 5 min | High | Investigate immediately |
| Policy violations | >20 in 5 min | Medium | Review policy configuration |

### Log Analysis Queries

**Failed Authentication Attempts:**
```kusto
ApiManagementGatewayLogs
| where TimeGenerated > ago(1h)
| where ResponseCode == 401
| summarize Count=count() by ClientIp, bin(TimeGenerated, 5m)
| where Count > 10
| order by Count desc
```

**Scope Validation Failures:**
```kusto
ApiManagementGatewayLogs
| where TimeGenerated > ago(1h)
| where ResponseCode == 403
| extend Reason = tostring(parse_json(ResponseBody).error.message)
| summarize Count=count() by ClientIp, Reason
| order by Count desc
```

**Unusual Access Patterns:**
```kusto
ApiManagementGatewayLogs
| where TimeGenerated > ago(24h)
| summarize RequestCount=count(), UniqueIPs=dcount(ClientIp) by ClientId
| where RequestCount > 10000 or UniqueIPs > 10
| order by RequestCount desc
```


---

## Incident Response

### Security Incident Classification

| Severity | Description | Response Time | Examples |
|----------|-------------|---------------|----------|
| P0 - Critical | Active security breach | Immediate | Data breach, compromised credentials |
| P1 - High | Potential security breach | 15 minutes | Suspicious access patterns, DDoS |
| P2 - Medium | Security policy violation | 1 hour | Rate limit abuse, unauthorized attempts |
| P3 - Low | Security configuration issue | 24 hours | Expired certificates, policy warnings |

### Incident Response Procedures

#### Compromised Client Credentials

**Immediate Actions (0-15 minutes):**

1. **Disable the compromised client:**
```bash
# Disable client application
az ad app update --id {client-app-id} --set "availableToOtherTenants=false"

# Delete all client secrets
az ad app credential list --id {client-app-id}
az ad app credential delete --id {client-app-id} --key-id {key-id}
```

2. **Block client IP addresses (if known):**
```bash
# Update APIM policy to block IPs
# Add to ip-filter deny list
```

3. **Notify security team and client**

**Investigation (15-60 minutes):**

1. **Review access logs:**
```kusto
ApiManagementGatewayLogs
| where ClientId == "{compromised-client-id}"
| where TimeGenerated > ago(7d)
| project TimeGenerated, ClientIp, Method, Url, ResponseCode
| order by TimeGenerated desc
```

2. **Identify unauthorized access:**
   - Check for unusual IP addresses
   - Review accessed endpoints
   - Identify data accessed
   - Determine scope of breach

3. **Document findings**

**Remediation (1-4 hours):**

1. **Generate new credentials for client**
2. **Review and update security policies**
3. **Implement additional monitoring**
4. **Conduct security review**

**Post-Incident (24-48 hours):**

1. **Conduct post-mortem**
2. **Update security procedures**
3. **Provide incident report to stakeholders**
4. **Implement preventive measures**


#### DDoS Attack

**Immediate Actions:**

1. **Enable DDoS protection:**
```bash
# Enable DDoS protection on APIM
az network ddos-protection update \
    --resource-group "rg-dataapi-prod" \
    --name "ddos-protection-plan" \
    --enable true
```

2. **Implement aggressive rate limiting:**
   - Reduce rate limits temporarily
   - Block attacking IP ranges
   - Enable CAPTCHA (if applicable)

3. **Scale up resources:**
```bash
# Scale APIM if needed
az apim update \
    --resource-group "rg-dataapi-prod" \
    --name "apim-dataapi-prod" \
    --sku-capacity 2
```

**Investigation:**
- Identify attack source
- Analyze attack pattern
- Determine attack vector
- Assess impact

**Remediation:**
- Block malicious IPs
- Update security policies
- Implement additional protections
- Monitor for continued attacks

#### Data Breach

**Immediate Actions:**

1. **Contain the breach:**
   - Disable affected clients
   - Block suspicious IPs
   - Revoke compromised credentials

2. **Assess the scope:**
   - Identify accessed data
   - Determine time frame
   - List affected users/records

3. **Notify stakeholders:**
   - Security team
   - Legal team
   - Compliance team
   - Affected parties (as required by law)

4. **Preserve evidence:**
   - Export relevant logs
   - Document timeline
   - Capture system state

**Investigation and Remediation:**
- Conduct forensic analysis
- Identify root cause
- Implement fixes
- Enhance security controls

**Post-Incident:**
- Regulatory reporting (if required)
- Customer notification (if required)
- Security audit
- Update security procedures

---

## Compliance and Auditing

### Compliance Requirements

Ensure compliance with relevant standards:

- **GDPR**: Data protection and privacy
- **SOC 2**: Security controls and monitoring
- **ISO 27001**: Information security management
- **HIPAA**: Healthcare data protection (if applicable)
- **PCI DSS**: Payment card data security (if applicable)


### Security Audit Checklist

Conduct quarterly security audits:

#### Access Control Audit

- [ ] Review all client applications and their permissions
- [ ] Verify principle of least privilege is applied
- [ ] Check for unused or orphaned applications
- [ ] Validate scope assignments are appropriate
- [ ] Review admin consent grants
- [ ] Audit service principal permissions

#### Authentication Audit

- [ ] Review client secret expiration dates
- [ ] Check certificate expiration dates
- [ ] Verify token validation configuration
- [ ] Review authentication failure patterns
- [ ] Audit multi-factor authentication settings (if applicable)
- [ ] Check for weak authentication methods

#### Network Security Audit

- [ ] Review IP whitelist configuration
- [ ] Verify TLS configuration (version and ciphers)
- [ ] Check firewall rules
- [ ] Audit network security groups
- [ ] Review DDoS protection settings
- [ ] Verify VNet integration (if applicable)

#### Data Protection Audit

- [ ] Verify encryption at rest is enabled
- [ ] Check encryption in transit configuration
- [ ] Review data masking policies
- [ ] Audit Key Vault access policies
- [ ] Verify backup encryption
- [ ] Check data retention policies

#### Monitoring and Logging Audit

- [ ] Verify all security logs are being collected
- [ ] Check log retention settings
- [ ] Review alert configurations
- [ ] Test alert notifications
- [ ] Audit log access controls
- [ ] Verify SIEM integration (if applicable)

#### Policy Audit

- [ ] Review APIM policy configuration
- [ ] Verify rate limiting is working
- [ ] Check scope validation logic
- [ ] Audit error handling policies
- [ ] Review CORS configuration
- [ ] Verify request validation policies

### Audit Logging

Enable audit logging for all security-relevant events:

```bash
# Enable diagnostic settings for APIM
az monitor diagnostic-settings create \
    --name "apim-audit-logs" \
    --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.ApiManagement/service/apim-dataapi-prod" \
    --logs '[{"category": "GatewayLogs", "enabled": true}, {"category": "WebSocketConnectionLogs", "enabled": true}]' \
    --workspace "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.OperationalInsights/workspaces/log-dataapi-prod"
```

**Audit Log Retention:**
- Security logs: 1 year minimum
- Access logs: 90 days minimum
- Compliance logs: As required by regulation


### Compliance Reporting

Generate compliance reports regularly:

**Monthly Security Report:**
- Authentication success/failure rates
- Authorization violations
- Rate limit violations
- Security incidents
- Secret rotation status
- Client access summary

**Quarterly Compliance Report:**
- Security audit results
- Policy compliance status
- Access review findings
- Vulnerability assessment results
- Remediation status
- Training completion status

**Annual Security Assessment:**
- Comprehensive security review
- Penetration testing results
- Compliance certification status
- Risk assessment
- Security roadmap
- Budget recommendations

---

## Security Contacts

### Security Team

| Role | Responsibility | Contact |
|------|---------------|---------|
| Security Lead | Overall security strategy | [Email] |
| Security Engineer | Day-to-day security operations | [Email] |
| Compliance Officer | Regulatory compliance | [Email] |
| Incident Response Lead | Security incident management | [Email] |

### Escalation Path

1. **Level 1**: Security Engineer (response time: 15 minutes)
2. **Level 2**: Security Lead (response time: 30 minutes)
3. **Level 3**: CISO (response time: 1 hour)
4. **Level 4**: CTO (response time: 2 hours)

### External Contacts

- **Azure Security Center**: [Portal Link]
- **Microsoft Security Response Center**: secure@microsoft.com
- **Compliance Auditor**: [Contact]
- **Legal Team**: [Contact]

---

## Appendix

### Security Configuration Checklist

**Initial Setup:**
- [ ] API app registration created
- [ ] OAuth scopes defined
- [ ] Service principal created
- [ ] Admin consent granted
- [ ] Token configuration set

**Client Onboarding:**
- [ ] Client app registered
- [ ] Authentication method configured
- [ ] API permissions granted
- [ ] IP restrictions configured (if needed)
- [ ] Client documentation provided
- [ ] Access tested and verified

**Ongoing Maintenance:**
- [ ] Secret rotation schedule established
- [ ] Security monitoring configured
- [ ] Alerts set up and tested
- [ ] Audit logging enabled
- [ ] Compliance requirements documented
- [ ] Incident response plan in place

### Useful Commands

```bash
# List all app registrations
az ad app list --query "[].{Name:displayName, AppId:appId}" --output table

# Check client secret expiration
az ad app credential list --id {app-id} --query "[].{KeyId:keyId, EndDate:endDateTime}"

# Review API permissions
az ad app permission list --id {app-id}

# Export security logs
az monitor log-analytics query --workspace "log-dataapi-prod" --analytics-query "SecurityEvent | take 100" --output json > security-logs.json
```

---

**Document Version:** 1.0.0  
**Last Updated:** November 18, 2025  
**Next Review Date:** February 18, 2026  
**Classification:** Confidential - Internal Use Only
