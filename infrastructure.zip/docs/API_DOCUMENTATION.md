# Data API Documentation

## Overview

The Data API is a secure RESTful API that provides access to AspNetUsers data through Azure API Management (APIM). The API implements OAuth 2.0 authentication with Azure Active Directory and enforces comprehensive security policies including rate limiting, IP filtering, and request validation.

**Base URLs:**
- Development: `https://apim-dataapi-dev.azure-api.net/api/v1`
- Staging: `https://apim-dataapi-staging.azure-api.net/api/v1`
- Production: `https://apim-dataapi-prod.azure-api.net/api/v1`

**API Version:** 1.0.0

## Table of Contents

1. [Authentication](#authentication)
2. [Authorization](#authorization)
3. [Rate Limiting](#rate-limiting)
4. [Error Handling](#error-handling)
5. [API Endpoints](#api-endpoints)
6. [Code Examples](#code-examples)
7. [Troubleshooting](#troubleshooting)

---

## Authentication

The API uses OAuth 2.0 authentication with Azure Active Directory using the Client Credentials flow.

### Prerequisites

1. Azure AD tenant access
2. Registered client application in Azure AD
3. Client ID and Client Secret (or certificate)
4. API permissions granted and admin consent provided

### Obtaining an Access Token

**Token Endpoint:**
```
https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token
```

**Request Parameters:**
- `grant_type`: `client_credentials` (required)
- `client_id`: Your application's client ID (required)
- `client_secret`: Your application's client secret (required)
- `scope`: `api://your-api-name/.default` (required)


**Example Token Request (cURL):**
```bash
curl -X POST https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id={your-client-id}" \
  -d "client_secret={your-client-secret}" \
  -d "scope=api://your-api-name/.default"
```

**Example Token Response:**
```json
{
  "token_type": "Bearer",
  "expires_in": 3599,
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

### Using the Access Token

Include the access token in the `Authorization` header of all API requests:

```
Authorization: Bearer {access_token}
```

### Token Validation

The API Gateway validates the following token claims:
- **Signature**: Verified using Azure AD public keys
- **Expiration** (`exp`): Token must not be expired
- **Audience** (`aud`): Must match the API application ID URI
- **Issuer** (`iss`): Must match the Azure AD tenant
- **Scopes** (`scp`): Must contain at least one required scope

**Token Lifetime:** Access tokens are valid for 1 hour (3600 seconds).

---

## Authorization

The API implements scope-based authorization with three permission levels:

### Available Scopes

| Scope | Description | Operations Allowed |
|-------|-------------|-------------------|
| `Data.Read` | Read access to data | GET operations |
| `Data.Write` | Write access to data | GET, POST, PUT, PATCH operations |
| `Admin` | Administrative access | All operations including DELETE |


### Scope Requirements by Operation

- **GET** `/aspnetusers`, `/aspnetusers/{id}`: Requires `Data.Read`, `Data.Write`, or `Admin`
- **POST** `/aspnetusers`: Requires `Data.Write` or `Admin`
- **PUT/PATCH** `/aspnetusers/{id}`: Requires `Data.Write` or `Admin`
- **DELETE** `/aspnetusers/{id}`: Requires `Admin` only

### Requesting Scopes

When registering your client application, request the appropriate API permissions:
1. Navigate to Azure Portal > App Registrations > Your App
2. Select "API permissions"
3. Click "Add a permission" > "My APIs"
4. Select the Data API
5. Choose the required scopes
6. Click "Grant admin consent"

---

## Rate Limiting

The API enforces rate limiting to protect against abuse and ensure fair usage.

### Rate Limit Policy

- **Requests per minute**: 100 requests per client
- **Concurrent requests**: Maximum 10 simultaneous requests per client
- **Rate limit key**: Based on the client ID from the JWT token

### Rate Limit Headers

Every API response includes rate limit information:

```
X-Rate-Limit-Limit: 100
X-Rate-Limit-Remaining: 95
X-Rate-Limit-Reset: 2025-11-18T10:31:00Z
```

| Header | Description |
|--------|-------------|
| `X-Rate-Limit-Limit` | Maximum requests allowed per minute |
| `X-Rate-Limit-Remaining` | Remaining requests in current window |
| `X-Rate-Limit-Reset` | Timestamp when the rate limit resets |

### Rate Limit Exceeded

When you exceed the rate limit, the API returns:
- **Status Code**: `429 Too Many Requests`
- **Retry-After Header**: Seconds to wait before retrying
- **Error Response**: JSON error object with correlation ID


---

## Error Handling

The API uses standard HTTP status codes and returns consistent error responses.

### HTTP Status Codes

| Status Code | Description |
|-------------|-------------|
| `200 OK` | Request succeeded |
| `201 Created` | Resource created successfully |
| `204 No Content` | Request succeeded with no response body |
| `400 Bad Request` | Invalid request parameters or body |
| `401 Unauthorized` | Missing or invalid access token |
| `403 Forbidden` | Insufficient permissions |
| `404 Not Found` | Resource not found |
| `429 Too Many Requests` | Rate limit exceeded |
| `500 Internal Server Error` | Server error occurred |
| `503 Service Unavailable` | Backend service unavailable |

### Error Response Format

All error responses follow this structure:

```json
{
  "error": {
    "code": "ErrorCode",
    "message": "Human-readable error message",
    "correlationId": "550e8400-e29b-41d4-a716-446655440000",
    "timestamp": "2025-11-18T10:30:00Z",
    "details": [
      {
        "field": "emailAddress",
        "message": "Invalid email format"
      }
    ]
  }
}
```

### Common Error Codes

| Error Code | HTTP Status | Description |
|------------|-------------|-------------|
| `Unauthorized` | 401 | Access token is missing, invalid, or expired |
| `Forbidden` | 403 | Insufficient permissions for the requested operation |
| `InvalidRequest` | 400 | Request validation failed |
| `InvalidContentType` | 400 | Content-Type header is not application/json |
| `NotFound` | 404 | Requested resource does not exist |
| `TooManyRequests` | 429 | Rate limit exceeded |
| `InternalServerError` | 500 | An unexpected error occurred |


### Correlation IDs

Every request is assigned a correlation ID for tracking and troubleshooting:
- Include `X-Correlation-ID` header in your request to use your own ID
- If not provided, the API generates one automatically
- The correlation ID is returned in the `X-Correlation-ID` response header
- Include the correlation ID when contacting support

---

## API Endpoints

### Health Check

Check the API service health status.

**Endpoint:** `GET /health`

**Authentication:** None required

**Response (200 OK):**
```json
{
  "status": "healthy",
  "timestamp": "2025-11-18T10:30:00Z",
  "dependencies": {
    "database": "healthy",
    "cache": "healthy"
  }
}
```

**Response (503 Service Unavailable):**
```json
{
  "status": "unhealthy",
  "timestamp": "2025-11-18T10:30:00Z",
  "dependencies": {
    "database": "unhealthy",
    "cache": "healthy"
  }
}
```

---

### List AspNetUsers

Retrieve a paginated list of AspNetUsers.

**Endpoint:** `GET /aspnetusers`

**Required Scope:** `Data.Read`, `Data.Write`, or `Admin`

**Query Parameters:**

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `page` | integer | No | 1 | Page number (minimum: 1) |
| `pageSize` | integer | No | 50 | Items per page (1-100) |
| `isActive` | boolean | No | - | Filter by active status |


**Response Headers:**
```
X-Total-Count: 250
X-Page: 1
X-Page-Size: 50
X-Correlation-ID: 550e8400-e29b-41d4-a716-446655440000
X-Rate-Limit-Remaining: 95
```

**Response (200 OK):**
```json
[
  {
    "aspNetUserId": "user-123",
    "userName": "john.doe",
    "emailAddress": "john.doe@example.com",
    "isActive": true,
    "createdDate": "2025-01-15T08:30:00Z"
  },
  {
    "aspNetUserId": "user-456",
    "userName": "jane.smith",
    "emailAddress": "jane.smith@example.com",
    "isActive": true,
    "createdDate": "2025-02-20T14:15:00Z"
  }
]
```

---

### Get AspNetUser by ID

Retrieve a specific AspNetUser by ID.

**Endpoint:** `GET /aspnetusers/{id}`

**Required Scope:** `Data.Read`, `Data.Write`, or `Admin`

**Path Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `id` | string | Yes | AspNetUser unique identifier (max 450 chars) |

**Response (200 OK):**
```json
{
  "aspNetUserId": "user-123",
  "userName": "john.doe",
  "emailAddress": "john.doe@example.com",
  "isActive": true,
  "createdDate": "2025-01-15T08:30:00Z"
}
```

**Response (404 Not Found):**
```json
{
  "error": {
    "code": "NotFound",
    "message": "The requested resource was not found",
    "correlationId": "550e8400-e29b-41d4-a716-446655440000",
    "timestamp": "2025-11-18T10:30:00Z"
  }
}
```


---

### Create AspNetUser

Create a new AspNetUser.

**Endpoint:** `POST /aspnetusers`

**Required Scope:** `Data.Write` or `Admin`

**Request Headers:**
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Request Body:**
```json
{
  "userName": "john.doe",
  "emailAddress": "john.doe@example.com",
  "isActive": true
}
```

**Request Body Schema:**

| Field | Type | Required | Constraints | Description |
|-------|------|----------|-------------|-------------|
| `userName` | string | Yes | 1-256 chars, pattern: `^[a-zA-Z0-9._@+-]+$` | User's username |
| `emailAddress` | string | Yes | 3-256 chars, valid email | User's email address |
| `isActive` | boolean | No | - | Active status (default: true) |

**Response (201 Created):**
```json
{
  "aspNetUserId": "user-789",
  "userName": "john.doe",
  "emailAddress": "john.doe@example.com",
  "isActive": true,
  "createdDate": "2025-11-18T10:30:00Z"
}
```

**Response Headers:**
```
Location: /api/v1/aspnetusers/user-789
X-Correlation-ID: 550e8400-e29b-41d4-a716-446655440000
```

**Response (400 Bad Request):**
```json
{
  "error": {
    "code": "InvalidRequest",
    "message": "The request is invalid",
    "correlationId": "550e8400-e29b-41d4-a716-446655440000",
    "timestamp": "2025-11-18T10:30:00Z",
    "details": [
      {
        "field": "emailAddress",
        "message": "Invalid email format"
      }
    ]
  }
}
```


---

### Update AspNetUser

Update an existing AspNetUser (full update).

**Endpoint:** `PUT /aspnetusers/{id}`

**Required Scope:** `Data.Write` or `Admin`

**Path Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `id` | string | Yes | AspNetUser unique identifier |

**Request Body:**
```json
{
  "userName": "john.doe.updated",
  "emailAddress": "john.updated@example.com",
  "isActive": false
}
```

**Response (204 No Content):**
No response body. Check `X-Correlation-ID` header for tracking.

---

### Partially Update AspNetUser

Partially update an AspNetUser using JSON Patch.

**Endpoint:** `PATCH /aspnetusers/{id}`

**Required Scope:** `Data.Write` or `Admin`

**Request Headers:**
```
Content-Type: application/json-patch+json
Authorization: Bearer {access_token}
```

**Request Body (JSON Patch):**
```json
[
  {
    "op": "replace",
    "path": "/isActive",
    "value": false
  },
  {
    "op": "replace",
    "path": "/emailAddress",
    "value": "newemail@example.com"
  }
]
```

**JSON Patch Operations:**

| Operation | Description |
|-----------|-------------|
| `add` | Add a new property |
| `remove` | Remove a property |
| `replace` | Replace a property value |
| `move` | Move a property |
| `copy` | Copy a property |
| `test` | Test a property value |

**Response (204 No Content):**
No response body.


---

### Delete AspNetUser

Delete an AspNetUser.

**Endpoint:** `DELETE /aspnetusers/{id}`

**Required Scope:** `Admin` (only)

**Path Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `id` | string | Yes | AspNetUser unique identifier |

**Response (204 No Content):**
No response body.

**Response (403 Forbidden):**
```json
{
  "error": {
    "code": "Forbidden",
    "message": "Insufficient permissions. Admin scope required for delete operations.",
    "correlationId": "550e8400-e29b-41d4-a716-446655440000",
    "timestamp": "2025-11-18T10:30:00Z"
  }
}
```

---

## Code Examples

### C# / .NET

**Install NuGet Package:**
```bash
dotnet add package Microsoft.Identity.Client
```

**Example Code:**
```csharp
using Microsoft.Identity.Client;
using System.Net.Http.Headers;

public class DataApiClient
{
    private readonly string _tenantId = "your-tenant-id";
    private readonly string _clientId = "your-client-id";
    private readonly string _clientSecret = "your-client-secret";
    private readonly string _scope = "api://your-api-name/.default";
    private readonly string _baseUrl = "https://apim-dataapi-prod.azure-api.net/api/v1";
    
    private readonly HttpClient _httpClient;
    private readonly IConfidentialClientApplication _app;
    
    public DataApiClient()
    {
        _httpClient = new HttpClient { BaseAddress = new Uri(_baseUrl) };
        
        _app = ConfidentialClientApplicationBuilder
            .Create(_clientId)
            .WithClientSecret(_clientSecret)
            .WithAuthority(new Uri($"https://login.microsoftonline.com/{_tenantId}"))
            .Build();
    }
    
    private async Task<string> GetAccessTokenAsync()
    {
        var result = await _app.AcquireTokenForClient(new[] { _scope })
            .ExecuteAsync();
        return result.AccessToken;
    }
    
    public async Task<List<AspNetUser>> GetUsersAsync(int page = 1, int pageSize = 50)
    {
        var token = await GetAccessTokenAsync();
        _httpClient.DefaultRequestHeaders.Authorization = 
            new AuthenticationHeaderValue("Bearer", token);
        
        var response = await _httpClient.GetAsync($"/aspnetusers?page={page}&pageSize={pageSize}");
        response.EnsureSuccessStatusCode();
        
        return await response.Content.ReadFromJsonAsync<List<AspNetUser>>();
    }
    
    public async Task<AspNetUser> CreateUserAsync(CreateAspNetUserRequest request)
    {
        var token = await GetAccessTokenAsync();
        _httpClient.DefaultRequestHeaders.Authorization = 
            new AuthenticationHeaderValue("Bearer", token);
        
        var response = await _httpClient.PostAsJsonAsync("/aspnetusers", request);
        response.EnsureSuccessStatusCode();
        
        return await response.Content.ReadFromJsonAsync<AspNetUser>();
    }
}

public class AspNetUser
{
    public string AspNetUserId { get; set; }
    public string UserName { get; set; }
    public string EmailAddress { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedDate { get; set; }
}

public class CreateAspNetUserRequest
{
    public string UserName { get; set; }
    public string EmailAddress { get; set; }
    public bool IsActive { get; set; } = true;
}
```


---

### Python

**Install Required Package:**
```bash
pip install msal requests
```

**Example Code:**
```python
import msal
import requests
from typing import List, Dict, Optional

class DataApiClient:
    def __init__(self, tenant_id: str, client_id: str, client_secret: str):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.scope = ["api://your-api-name/.default"]
        self.base_url = "https://apim-dataapi-prod.azure-api.net/api/v1"
        
        self.app = msal.ConfidentialClientApplication(
            client_id,
            authority=f"https://login.microsoftonline.com/{tenant_id}",
            client_credential=client_secret
        )
    
    def get_access_token(self) -> str:
        result = self.app.acquire_token_for_client(scopes=self.scope)
        
        if "access_token" in result:
            return result["access_token"]
        else:
            raise Exception(f"Failed to acquire token: {result.get('error_description')}")
    
    def get_users(self, page: int = 1, page_size: int = 50, 
                  is_active: Optional[bool] = None) -> List[Dict]:
        token = self.get_access_token()
        headers = {"Authorization": f"Bearer {token}"}
        
        params = {"page": page, "pageSize": page_size}
        if is_active is not None:
            params["isActive"] = is_active
        
        response = requests.get(
            f"{self.base_url}/aspnetusers",
            headers=headers,
            params=params
        )
        response.raise_for_status()
        
        return response.json()
    
    def create_user(self, user_name: str, email_address: str, 
                    is_active: bool = True) -> Dict:
        token = self.get_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        data = {
            "userName": user_name,
            "emailAddress": email_address,
            "isActive": is_active
        }
        
        response = requests.post(
            f"{self.base_url}/aspnetusers",
            headers=headers,
            json=data
        )
        response.raise_for_status()
        
        return response.json()

# Usage
client = DataApiClient(
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret"
)

users = client.get_users(page=1, page_size=10)
print(f"Retrieved {len(users)} users")
```


---

### Node.js / JavaScript

**Install Required Package:**
```bash
npm install @azure/identity axios
```

**Example Code:**
```javascript
const { ClientSecretCredential } = require('@azure/identity');
const axios = require('axios');

class DataApiClient {
    constructor(tenantId, clientId, clientSecret) {
        this.tenantId = tenantId;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.scope = 'api://your-api-name/.default';
        this.baseUrl = 'https://apim-dataapi-prod.azure-api.net/api/v1';
        
        this.credential = new ClientSecretCredential(
            tenantId,
            clientId,
            clientSecret
        );
    }
    
    async getAccessToken() {
        const tokenResponse = await this.credential.getToken(this.scope);
        return tokenResponse.token;
    }
    
    async getUsers(page = 1, pageSize = 50, isActive = null) {
        const token = await this.getAccessToken();
        
        const params = { page, pageSize };
        if (isActive !== null) {
            params.isActive = isActive;
        }
        
        const response = await axios.get(`${this.baseUrl}/aspnetusers`, {
            headers: {
                'Authorization': `Bearer ${token}`
            },
            params
        });
        
        return response.data;
    }
    
    async createUser(userName, emailAddress, isActive = true) {
        const token = await this.getAccessToken();
        
        const response = await axios.post(
            `${this.baseUrl}/aspnetusers`,
            {
                userName,
                emailAddress,
                isActive
            },
            {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        
        return response.data;
    }
}

// Usage
const client = new DataApiClient(
    'your-tenant-id',
    'your-client-id',
    'your-client-secret'
);

(async () => {
    try {
        const users = await client.getUsers(1, 10);
        console.log(`Retrieved ${users.length} users`);
    } catch (error) {
        console.error('Error:', error.response?.data || error.message);
    }
})();
```


---

### cURL Examples

**Get Access Token:**
```bash
curl -X POST "https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id={client-id}" \
  -d "client_secret={client-secret}" \
  -d "scope=api://your-api-name/.default"
```

**List Users:**
```bash
curl -X GET "https://apim-dataapi-prod.azure-api.net/api/v1/aspnetusers?page=1&pageSize=50" \
  -H "Authorization: Bearer {access-token}" \
  -H "Accept: application/json"
```

**Get User by ID:**
```bash
curl -X GET "https://apim-dataapi-prod.azure-api.net/api/v1/aspnetusers/user-123" \
  -H "Authorization: Bearer {access-token}" \
  -H "Accept: application/json"
```

**Create User:**
```bash
curl -X POST "https://apim-dataapi-prod.azure-api.net/api/v1/aspnetusers" \
  -H "Authorization: Bearer {access-token}" \
  -H "Content-Type: application/json" \
  -d '{
    "userName": "john.doe",
    "emailAddress": "john.doe@example.com",
    "isActive": true
  }'
```

**Update User:**
```bash
curl -X PUT "https://apim-dataapi-prod.azure-api.net/api/v1/aspnetusers/user-123" \
  -H "Authorization: Bearer {access-token}" \
  -H "Content-Type: application/json" \
  -d '{
    "userName": "john.doe.updated",
    "emailAddress": "john.updated@example.com",
    "isActive": false
  }'
```

**Patch User:**
```bash
curl -X PATCH "https://apim-dataapi-prod.azure-api.net/api/v1/aspnetusers/user-123" \
  -H "Authorization: Bearer {access-token}" \
  -H "Content-Type: application/json-patch+json" \
  -d '[
    {
      "op": "replace",
      "path": "/isActive",
      "value": false
    }
  ]'
```

**Delete User:**
```bash
curl -X DELETE "https://apim-dataapi-prod.azure-api.net/api/v1/aspnetusers/user-123" \
  -H "Authorization: Bearer {access-token}"
```


---

## Troubleshooting

### Common Issues and Solutions

#### 1. 401 Unauthorized - Invalid Token

**Symptoms:**
```json
{
  "error": {
    "code": "Unauthorized",
    "message": "Unauthorized. Access token is missing or invalid."
  }
}
```

**Possible Causes:**
- Token has expired (tokens are valid for 1 hour)
- Token signature is invalid
- Token audience doesn't match the API
- Token issuer doesn't match Azure AD tenant
- Missing Authorization header

**Solutions:**
1. Verify the token hasn't expired - check the `exp` claim
2. Request a new token if expired
3. Ensure the `scope` parameter is correct: `api://your-api-name/.default`
4. Verify the token audience (`aud`) matches the API application ID URI
5. Check that the Authorization header format is: `Bearer {token}`
6. Decode the JWT at jwt.ms to inspect claims

#### 2. 403 Forbidden - Insufficient Permissions

**Symptoms:**
```json
{
  "error": {
    "code": "Forbidden",
    "message": "Insufficient permissions. Data.Write or Admin scope required."
  }
}
```

**Possible Causes:**
- Token doesn't contain required scopes
- Admin consent not granted for API permissions
- Attempting DELETE operation without Admin scope

**Solutions:**
1. Verify your app has the required API permissions in Azure Portal
2. Ensure admin consent has been granted
3. Check the `scp` claim in your token contains the required scope
4. For DELETE operations, ensure you have the Admin scope
5. Re-request API permissions if needed


#### 3. 429 Too Many Requests - Rate Limit Exceeded

**Symptoms:**
```json
{
  "error": {
    "code": "TooManyRequests",
    "message": "Rate limit exceeded. Please retry after some time."
  }
}
```

**Possible Causes:**
- Exceeded 100 requests per minute limit
- Too many concurrent requests (>10)

**Solutions:**
1. Implement exponential backoff retry logic
2. Check the `Retry-After` header for wait time
3. Monitor `X-Rate-Limit-Remaining` header
4. Implement request queuing in your application
5. Cache responses when possible to reduce API calls
6. Contact support if you need higher rate limits

#### 4. 400 Bad Request - Invalid Request

**Symptoms:**
```json
{
  "error": {
    "code": "InvalidRequest",
    "message": "The request is invalid",
    "details": [
      {
        "field": "emailAddress",
        "message": "Invalid email format"
      }
    ]
  }
}
```

**Possible Causes:**
- Invalid request body format
- Missing required fields
- Field validation failures
- Invalid Content-Type header
- Request body exceeds 1 MB limit

**Solutions:**
1. Verify Content-Type is `application/json` or `application/json-patch+json`
2. Check all required fields are present
3. Validate email format and field constraints
4. Ensure request body is valid JSON
5. Check field length constraints (e.g., userName max 256 chars)
6. Review the `details` array for specific field errors


#### 5. 500 Internal Server Error

**Symptoms:**
```json
{
  "error": {
    "code": "InternalServerError",
    "message": "An error occurred processing your request",
    "correlationId": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

**Possible Causes:**
- Backend service error
- Database connectivity issues
- Unexpected server-side exception

**Solutions:**
1. Save the `correlationId` from the error response
2. Retry the request after a short delay
3. If the issue persists, contact support with the correlation ID
4. Check the API status page for known issues

#### 6. Token Acquisition Failures

**Symptoms:**
- Unable to acquire access token from Azure AD
- Error: "invalid_client" or "invalid_secret"

**Possible Causes:**
- Incorrect client ID or client secret
- Client secret has expired
- Wrong tenant ID
- Application not properly registered

**Solutions:**
1. Verify client ID and tenant ID are correct
2. Check client secret hasn't expired in Azure Portal
3. Generate a new client secret if needed
4. Ensure the token endpoint URL includes the correct tenant ID
5. Verify the application is registered in the correct Azure AD tenant

#### 7. CORS Errors (Browser-based Applications)

**Symptoms:**
- CORS policy error in browser console
- Preflight request fails

**Possible Causes:**
- Origin not in allowed origins list
- Missing CORS headers

**Solutions:**
1. Ensure your origin is configured in APIM CORS policy
2. For browser-based apps, consider using a backend proxy
3. Contact API administrator to add your origin to the whitelist
4. Note: OAuth client credentials flow should not be used in browser apps


### Debugging Tips

1. **Decode JWT Tokens**: Use https://jwt.ms to decode and inspect token claims
2. **Check Token Expiration**: Tokens expire after 1 hour - implement token refresh logic
3. **Use Correlation IDs**: Always include correlation IDs when reporting issues
4. **Monitor Rate Limits**: Track `X-Rate-Limit-Remaining` header to avoid throttling
5. **Enable Logging**: Log all API requests and responses in your application
6. **Test with cURL**: Isolate issues by testing with cURL before using SDK
7. **Verify Scopes**: Ensure your token contains the required scopes for the operation

### Getting Help

If you encounter issues not covered in this documentation:

1. **Check Correlation ID**: Save the correlation ID from error responses
2. **Review Logs**: Check your application logs for detailed error information
3. **API Status**: Check the API status page for known issues or maintenance
4. **Contact Support**: Provide the following information:
   - Correlation ID
   - Timestamp of the issue
   - Request details (method, endpoint, headers - excluding sensitive data)
   - Error response received
   - Your client application ID

### Best Practices

1. **Token Caching**: Cache access tokens and reuse until expiration
2. **Retry Logic**: Implement exponential backoff for transient failures
3. **Rate Limit Handling**: Monitor rate limit headers and throttle requests
4. **Error Handling**: Handle all HTTP status codes appropriately
5. **Correlation IDs**: Generate and track correlation IDs for all requests
6. **Secure Secrets**: Never expose client secrets in code or logs
7. **Use HTTPS**: Always use HTTPS for all API communications
8. **Validate Responses**: Validate API responses before processing
9. **Timeout Configuration**: Set appropriate timeout values for HTTP requests
10. **Connection Pooling**: Reuse HTTP connections for better performance

---

## Additional Resources

- **OpenAPI Specification**: See `infrastructure/openapi/data-api.yaml`
- **Azure AD Documentation**: https://docs.microsoft.com/azure/active-directory/
- **OAuth 2.0 Client Credentials Flow**: https://docs.microsoft.com/azure/active-directory/develop/v2-oauth2-client-creds-grant-flow
- **Azure API Management**: https://docs.microsoft.com/azure/api-management/

---

**Document Version:** 1.0.0  
**Last Updated:** November 18, 2025  
**API Version:** 1.0.0
