# Deployment Runbook

## Overview

This runbook provides step-by-step instructions for deploying the Data API infrastructure and application to Azure. It covers prerequisites, deployment procedures, verification steps, and rollback procedures.

**Target Environments:**
- Development (dev)
- Staging (staging)
- Production (prod)

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Pre-Deployment Checklist](#pre-deployment-checklist)
3. [Deployment Steps](#deployment-steps)
4. [Post-Deployment Verification](#post-deployment-verification)
5. [Rollback Procedures](#rollback-procedures)
6. [Troubleshooting](#troubleshooting)
7. [Emergency Contacts](#emergency-contacts)

---

## Prerequisites

### Required Tools

Ensure the following tools are installed and configured:

| Tool | Version | Purpose | Installation |
|------|---------|---------|--------------|
| Azure CLI | 2.50+ | Azure resource management | https://docs.microsoft.com/cli/azure/install-azure-cli |
| PowerShell | 7.0+ | Script execution | https://docs.microsoft.com/powershell/scripting/install/installing-powershell |
| .NET SDK | 8.0+ | Backend API build | https://dotnet.microsoft.com/download |
| Bicep CLI | 0.20+ | Infrastructure deployment | `az bicep install` |

### Azure Permissions

The deployment account must have the following Azure RBAC roles:

- **Subscription Level:**
  - Contributor (for resource creation)
  - User Access Administrator (for role assignments)

- **Azure AD Level:**
  - Application Administrator (for app registrations)
  - Cloud Application Administrator (for service principals)

### Required Information

Gather the following information before deployment:

- Azure Subscription ID
- Azure AD Tenant ID
- Resource Group Name (or name pattern)
- Environment Name (dev/staging/prod)
- Deployment Region (e.g., eastus, westeurope)
- SQL Server Administrator Credentials
- Allowed IP Ranges for IP filtering
- CORS Allowed Origins


---

## Pre-Deployment Checklist

Complete this checklist before starting deployment:

### Infrastructure Checklist

- [ ] Azure subscription is active and accessible
- [ ] Deployment account has required permissions
- [ ] Resource naming convention is defined
- [ ] Target region is selected and available
- [ ] Network configuration is planned (if using VNet integration)
- [ ] Budget alerts are configured
- [ ] Tags are defined for resource organization

### Configuration Checklist

- [ ] Environment-specific parameter files are prepared
- [ ] SQL Server administrator credentials are secured
- [ ] Key Vault access policies are defined
- [ ] APIM named values are documented
- [ ] IP whitelist ranges are confirmed
- [ ] CORS allowed origins are confirmed
- [ ] Backend API connection strings are prepared

### Security Checklist

- [ ] Azure AD app registration plan is reviewed
- [ ] OAuth scopes are defined
- [ ] Client applications are identified
- [ ] Certificate requirements are documented (if using certificate auth)
- [ ] Secret rotation schedule is planned
- [ ] Security contacts are notified

### Communication Checklist

- [ ] Deployment window is scheduled
- [ ] Stakeholders are notified
- [ ] Change request is approved (for production)
- [ ] Rollback plan is reviewed
- [ ] Support team is on standby

---

## Deployment Steps

### Step 1: Authenticate to Azure

**Duration:** 2 minutes

```powershell
# Login to Azure
az login

# Set the target subscription
az account set --subscription "your-subscription-id"

# Verify the current subscription
az account show

# Login to Azure AD (for app registrations)
az login --allow-no-subscriptions
```

**Verification:**
- Confirm the correct subscription is selected
- Verify you have access to the target resource group (or can create it)


### Step 2: Configure Azure AD App Registrations

**Duration:** 10 minutes

```powershell
# Navigate to infrastructure scripts directory
cd infrastructure/scripts

# Run Azure AD configuration script
./configure-azure-ad.ps1 `
    -ApiAppName "DataApi" `
    -TenantId "your-tenant-id" `
    -Environment "dev"
```

**What This Does:**
- Creates API application registration in Azure AD
- Configures OAuth 2.0 scopes (Data.Read, Data.Write, Admin)
- Sets up service principal
- Configures token settings
- Saves configuration to `infrastructure/config/azure-ad-config-{env}.json`

**Verification:**
1. Open Azure Portal > Azure Active Directory > App registrations
2. Find the application "DataApi-{env}"
3. Verify the following:
   - Application ID URI is set
   - Three scopes are exposed (Data.Read, Data.Write, Admin)
   - Token version is 2.0
4. Grant admin consent for the API permissions

**Manual Steps:**
1. In Azure Portal, navigate to the app registration
2. Go to "API permissions"
3. Click "Grant admin consent for {tenant}"
4. Confirm the consent

**Output:**
- API Application ID
- API Application ID URI
- Configuration file saved


### Step 3: Prepare Configuration Parameters

**Duration:** 5 minutes

Edit the environment-specific parameter file:

```powershell
# Edit parameter file
notepad infrastructure/parameters/parameters.dev.json
```

**Required Parameters:**

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "environment": {
      "value": "dev"
    },
    "location": {
      "value": "eastus"
    },
    "apiApplicationIdUri": {
      "value": "api://DataApi-dev"
    },
    "azureAdTenantId": {
      "value": "your-tenant-id"
    },
    "sqlAdministratorLogin": {
      "value": "sqladmin"
    },
    "sqlAdministratorPassword": {
      "value": "your-secure-password"
    },
    "allowedIpRanges": {
      "value": ["10.0.0.0/24", "192.168.1.0/24"]
    },
    "corsAllowedOrigins": {
      "value": ["https://app.example.com"]
    }
  }
}
```

**Verification:**
- All required parameters are filled
- Passwords meet complexity requirements
- IP ranges are in CIDR notation
- URLs use HTTPS protocol


### Step 4: Deploy Azure Infrastructure

**Duration:** 20-30 minutes

```powershell
# Navigate to infrastructure directory
cd infrastructure

# Validate the Bicep template
az deployment sub validate `
    --location eastus `
    --template-file main.bicep `
    --parameters parameters/parameters.dev.json

# Deploy the infrastructure
az deployment sub create `
    --name "dataapi-deployment-$(Get-Date -Format 'yyyyMMddHHmmss')" `
    --location eastus `
    --template-file main.bicep `
    --parameters parameters/parameters.dev.json `
    --verbose
```

**What This Deploys:**
- Resource Group
- Azure SQL Database
- Azure Key Vault
- Azure API Management (Premium tier)
- App Service Plan
- App Service (Backend API)
- Application Insights
- Log Analytics Workspace
- Managed Identities
- Role Assignments

**Monitoring Deployment:**
```powershell
# Watch deployment progress
az deployment sub show `
    --name "dataapi-deployment-{timestamp}" `
    --query "properties.provisioningState"
```

**Verification:**
1. Check deployment status: Should be "Succeeded"
2. Verify all resources are created in the resource group
3. Check for any deployment warnings or errors

**Expected Duration by Resource:**
- Resource Group: 1 minute
- SQL Database: 5-10 minutes
- Key Vault: 2 minutes
- APIM: 15-20 minutes (longest)
- App Service: 3-5 minutes
- Monitoring: 2-3 minutes


### Step 5: Configure Key Vault Secrets

**Duration:** 5 minutes

```powershell
# Navigate to scripts directory
cd infrastructure/scripts

# Run Key Vault setup script
./setup-keyvault-secrets.ps1 `
    -KeyVaultName "kv-dataapi-dev" `
    -Environment "dev" `
    -SqlConnectionString "Server=tcp:sql-dataapi-dev.database.windows.net,1433;Database=DataApiDb;..."
```

**Secrets to Configure:**
- `SqlConnectionString`: Database connection string
- `ApplicationInsightsKey`: Application Insights instrumentation key
- `BackendApiUrl`: Backend API base URL
- `AzureAdTenantId`: Azure AD tenant ID
- `ApiApplicationIdUri`: API application ID URI

**Verification:**
```powershell
# List secrets in Key Vault
az keyvault secret list --vault-name "kv-dataapi-dev" --query "[].name"

# Verify APIM can access Key Vault
az keyvault show --name "kv-dataapi-dev" --query "properties.accessPolicies"
```

**Manual Verification:**
1. Open Azure Portal > Key Vault
2. Navigate to "Secrets"
3. Verify all required secrets are present
4. Check "Access policies" to ensure APIM managed identity has Get permissions


### Step 6: Build and Deploy Backend API

**Duration:** 10 minutes

```powershell
# Navigate to backend API directory
cd src/DataApi

# Restore dependencies
dotnet restore

# Build the application
dotnet build --configuration Release

# Publish the application
dotnet publish --configuration Release --output ./publish

# Deploy to Azure App Service
az webapp deployment source config-zip `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev" `
    --src "./publish.zip"
```

**Alternative: Using Visual Studio:**
1. Open solution in Visual Studio
2. Right-click on DataApi project > Publish
3. Select Azure App Service target
4. Choose the deployed App Service
5. Click Publish

**Verification:**
```powershell
# Check App Service status
az webapp show `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev" `
    --query "state"

# View application logs
az webapp log tail `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev"
```

**Health Check:**
```powershell
# Test health endpoint (should return 200 OK)
curl https://app-dataapi-dev.azurewebsites.net/health
```


### Step 7: Import API Definition to APIM

**Duration:** 5 minutes

```powershell
# Navigate to infrastructure directory
cd infrastructure

# Import OpenAPI specification
az apim api import `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --api-id "data-api" `
    --path "/api/v1" `
    --specification-path "openapi/data-api.yaml" `
    --specification-format OpenApi `
    --display-name "Data API" `
    --protocols https `
    --subscription-required true
```

**Verification:**
1. Open Azure Portal > API Management
2. Navigate to "APIs"
3. Verify "Data API" is listed
4. Check that all operations are imported
5. Verify the API path is "/api/v1"

**Manual Steps (if needed):**
1. In Azure Portal, go to APIM instance
2. Click "APIs" > "Add API" > "OpenAPI"
3. Upload `infrastructure/openapi/data-api.yaml`
4. Set API URL suffix to "api/v1"
5. Click "Create"


### Step 8: Deploy APIM Policies

**Duration:** 5 minutes

```powershell
# Navigate to APIM policies directory
cd infrastructure/apim-policies

# Deploy API-level policy
az apim api policy create `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --api-id "data-api" `
    --xml-file "api-policy.xml"
```

**Verification:**
```powershell
# Retrieve and verify policy
az apim api policy show `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --api-id "data-api" `
    --query "value" `
    --output tsv
```

**Manual Verification:**
1. Open Azure Portal > APIM > APIs > Data API
2. Click on "All operations"
3. In the "Inbound processing" section, click "</>"
4. Verify the policy XML is correctly applied
5. Check for any policy errors or warnings

**Policy Components to Verify:**
- JWT validation with correct tenant ID
- Rate limiting (100 requests/minute)
- Scope-based authorization
- IP filtering (if enabled)
- CORS configuration
- Request validation
- Error handling


### Step 9: Configure APIM Named Values

**Duration:** 5 minutes

```powershell
# Set named values from Key Vault
az apim nv create `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --named-value-id "azure-ad-tenant-id" `
    --display-name "azure-ad-tenant-id" `
    --secret true `
    --key-vault-secret-id "https://kv-dataapi-dev.vault.azure.net/secrets/AzureAdTenantId"

az apim nv create `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --named-value-id "api-application-id-uri" `
    --display-name "api-application-id-uri" `
    --secret true `
    --key-vault-secret-id "https://kv-dataapi-dev.vault.azure.net/secrets/ApiApplicationIdUri"

az apim nv create `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --named-value-id "backend-api-url" `
    --display-name "backend-api-url" `
    --secret true `
    --key-vault-secret-id "https://kv-dataapi-dev.vault.azure.net/secrets/BackendApiUrl"
```

**Required Named Values:**
- `azure-ad-tenant-id`: Azure AD tenant ID
- `api-application-id-uri`: API application ID URI
- `backend-api-url`: Backend API base URL
- `cors-allowed-origin-1`: First allowed CORS origin
- `cors-allowed-origin-2`: Second allowed CORS origin
- `ip-filtering-enabled`: Enable/disable IP filtering (true/false)

**Verification:**
```powershell
# List all named values
az apim nv list `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --query "[].{Name:displayName, Secret:secret}" `
    --output table
```


### Step 10: Configure Monitoring and Alerts

**Duration:** 10 minutes

```powershell
# Create alert rules
az monitor metrics alert create `
    --name "High Error Rate" `
    --resource-group "rg-dataapi-dev" `
    --scopes "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-dev/providers/Microsoft.ApiManagement/service/apim-dataapi-dev" `
    --condition "total failed requests > 50" `
    --window-size 5m `
    --evaluation-frequency 1m `
    --action-group-ids "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-dev/providers/microsoft.insights/actionGroups/api-alerts"

az monitor metrics alert create `
    --name "High Response Time" `
    --resource-group "rg-dataapi-dev" `
    --scopes "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-dev/providers/Microsoft.ApiManagement/service/apim-dataapi-dev" `
    --condition "avg response time > 2000" `
    --window-size 5m `
    --evaluation-frequency 1m `
    --action-group-ids "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-dev/providers/microsoft.insights/actionGroups/api-alerts"
```

**Alerts to Configure:**
- High error rate (>5% of requests)
- High response time (>2 seconds average)
- Backend health check failures
- Rate limit violations spike
- Authentication failure spike

**Verification:**
1. Open Azure Portal > Monitor > Alerts
2. Verify alert rules are created and enabled
3. Check action groups are configured
4. Test alert notifications


---

## Post-Deployment Verification

### Verification Checklist

Complete all verification steps before considering deployment successful:

#### Infrastructure Verification

- [ ] All Azure resources are in "Running" or "Succeeded" state
- [ ] Resource tags are applied correctly
- [ ] Managed identities are created and assigned
- [ ] Key Vault access policies are configured
- [ ] Network security groups are configured (if applicable)
- [ ] Diagnostic settings are enabled for all resources

#### Backend API Verification

```powershell
# Test health endpoint
$response = Invoke-WebRequest -Uri "https://app-dataapi-dev.azurewebsites.net/health" -Method GET
Write-Host "Health Status: $($response.StatusCode)"

# Check application logs
az webapp log tail --resource-group "rg-dataapi-dev" --name "app-dataapi-dev"
```

**Expected Results:**
- Health endpoint returns 200 OK
- Response body shows "healthy" status
- No errors in application logs
- Database dependency is healthy

#### APIM Verification

```powershell
# Test APIM gateway health
$apimUrl = "https://apim-dataapi-dev.azure-api.net/api/v1/health"
$response = Invoke-WebRequest -Uri $apimUrl -Method GET
Write-Host "APIM Health: $($response.StatusCode)"
```

**Expected Results:**
- APIM gateway is accessible
- Health endpoint returns 200 OK through APIM
- API is listed in APIM portal
- Policies are applied correctly


#### Authentication Verification

```powershell
# Acquire access token
$tokenResponse = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token" `
    -Body @{
        grant_type = "client_credentials"
        client_id = "{client-id}"
        client_secret = "{client-secret}"
        scope = "api://DataApi-dev/.default"
    }

$token = $tokenResponse.access_token

# Test authenticated request
$headers = @{
    Authorization = "Bearer $token"
}

$response = Invoke-WebRequest -Uri "https://apim-dataapi-dev.azure-api.net/api/v1/aspnetusers?page=1&pageSize=10" `
    -Method GET -Headers $headers

Write-Host "API Response: $($response.StatusCode)"
Write-Host "Rate Limit Remaining: $($response.Headers['X-Rate-Limit-Remaining'])"
```

**Expected Results:**
- Token acquisition succeeds
- API request with token returns 200 OK
- Rate limit headers are present
- Correlation ID is returned

#### Security Verification

- [ ] JWT validation is working (test with invalid token)
- [ ] Scope-based authorization is enforced
- [ ] Rate limiting is active (test by exceeding limit)
- [ ] IP filtering is working (if enabled)
- [ ] CORS policy is enforced
- [ ] Request size limits are enforced
- [ ] TLS 1.2+ is required

**Test Invalid Token:**
```powershell
# Test with invalid token (should return 401)
$headers = @{
    Authorization = "Bearer invalid-token"
}

try {
    Invoke-WebRequest -Uri "https://apim-dataapi-dev.azure-api.net/api/v1/aspnetusers" `
        -Method GET -Headers $headers
} catch {
    Write-Host "Expected 401: $($_.Exception.Response.StatusCode)"
}
```


#### Monitoring Verification

- [ ] Application Insights is receiving telemetry
- [ ] Log Analytics workspace is collecting logs
- [ ] Alert rules are enabled
- [ ] Dashboards are accessible
- [ ] Correlation IDs are present in logs

**Check Application Insights:**
```powershell
# Query recent requests
az monitor app-insights query `
    --app "appi-dataapi-dev" `
    --analytics-query "requests | where timestamp > ago(1h) | summarize count() by resultCode" `
    --output table
```

**Check Logs:**
```powershell
# Query API Management logs
az monitor log-analytics query `
    --workspace "log-dataapi-dev" `
    --analytics-query "ApiManagementGatewayLogs | where TimeGenerated > ago(1h) | take 10" `
    --output table
```

#### Smoke Tests

Run end-to-end smoke tests:

```powershell
# Run smoke test script
cd tests
./smoke-tests.ps1 -Environment "dev" -BaseUrl "https://apim-dataapi-dev.azure-api.net/api/v1"
```

**Smoke Test Coverage:**
- Health check endpoint
- OAuth token acquisition
- List users (GET)
- Get user by ID (GET)
- Create user (POST)
- Update user (PUT)
- Delete user (DELETE)
- Rate limit enforcement
- Error handling


---

## Rollback Procedures

### When to Rollback

Initiate rollback if:
- Critical functionality is broken
- Security vulnerabilities are discovered
- Performance degradation exceeds acceptable thresholds
- Data integrity issues are detected
- Deployment verification fails

### Rollback Decision Matrix

| Issue Severity | Response Time | Action |
|----------------|---------------|--------|
| Critical (P0) | Immediate | Full rollback |
| High (P1) | 15 minutes | Rollback or hotfix |
| Medium (P2) | 1 hour | Hotfix or scheduled rollback |
| Low (P3) | Next deployment | Fix in next release |

### Rollback Steps

#### Option 1: Infrastructure Rollback (Full)

**Duration:** 20-30 minutes

```powershell
# Identify previous successful deployment
az deployment sub list `
    --query "[?properties.provisioningState=='Succeeded'].{Name:name, Timestamp:properties.timestamp}" `
    --output table

# Redeploy previous version
az deployment sub create `
    --name "dataapi-rollback-$(Get-Date -Format 'yyyyMMddHHmmss')" `
    --location eastus `
    --template-file main.bicep `
    --parameters parameters/parameters.dev.previous.json `
    --verbose
```

**Considerations:**
- Full infrastructure rollback takes 20-30 minutes
- May cause service interruption
- Database changes may need manual rollback
- Consider Option 2 for faster recovery


#### Option 2: Application Rollback (Backend API Only)

**Duration:** 5-10 minutes

```powershell
# List previous deployments
az webapp deployment list `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev" `
    --query "[].{Id:id, Status:status, Timestamp:start_time}" `
    --output table

# Rollback to previous deployment
az webapp deployment slot swap `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev" `
    --slot staging `
    --target-slot production
```

**Alternative: Redeploy Previous Version**
```powershell
# Checkout previous version from git
git checkout {previous-commit-hash}

# Build and deploy
cd src/DataApi
dotnet publish --configuration Release --output ./publish
az webapp deployment source config-zip `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev" `
    --src "./publish.zip"
```

#### Option 3: APIM Policy Rollback

**Duration:** 2-5 minutes

```powershell
# Backup current policy
az apim api policy show `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --api-id "data-api" `
    --query "value" `
    --output tsv > policy-backup.xml

# Restore previous policy
az apim api policy create `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --api-id "data-api" `
    --xml-file "apim-policies/api-policy.previous.xml"
```


#### Option 4: Database Rollback

**Duration:** Varies (5-60 minutes depending on data volume)

**Prerequisites:**
- Database backup exists
- Backup is verified and accessible
- Maintenance window is scheduled

```powershell
# List available backups
az sql db list-backups `
    --resource-group "rg-dataapi-dev" `
    --server "sql-dataapi-dev" `
    --database "DataApiDb"

# Restore from backup
az sql db restore `
    --resource-group "rg-dataapi-dev" `
    --server "sql-dataapi-dev" `
    --name "DataApiDb" `
    --dest-name "DataApiDb-restored" `
    --time "2025-11-18T09:00:00Z"

# After verification, swap databases
# This requires application downtime
```

**Warning:** Database rollback may result in data loss. Coordinate with stakeholders.

### Post-Rollback Verification

After rollback, verify:

- [ ] Service is operational
- [ ] Health checks pass
- [ ] Authentication works
- [ ] No errors in logs
- [ ] Performance is acceptable
- [ ] Monitoring is active
- [ ] Stakeholders are notified

### Rollback Communication

**Immediate Actions:**
1. Notify stakeholders of rollback initiation
2. Update status page
3. Document rollback reason
4. Create incident report

**Post-Rollback:**
1. Conduct post-mortem
2. Document lessons learned
3. Update deployment procedures
4. Plan remediation


---

## Troubleshooting

### Common Deployment Issues

#### Issue 1: APIM Deployment Timeout

**Symptoms:**
- APIM deployment takes longer than 45 minutes
- Deployment appears stuck

**Causes:**
- Azure region capacity issues
- Network configuration problems
- Resource quota limits

**Solutions:**
1. Check Azure Service Health for region issues
2. Verify subscription quotas: `az vm list-usage --location eastus`
3. Try deploying to a different region
4. Contact Azure Support if issue persists

#### Issue 2: Backend API Fails to Start

**Symptoms:**
- App Service shows "Application Error"
- Health endpoint returns 503

**Causes:**
- Missing configuration settings
- Database connection failure
- Application startup errors

**Solutions:**
```powershell
# Check application logs
az webapp log tail --resource-group "rg-dataapi-dev" --name "app-dataapi-dev"

# Verify configuration
az webapp config appsettings list `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev"

# Check Key Vault access
az webapp identity show `
    --resource-group "rg-dataapi-dev" `
    --name "app-dataapi-dev"
```

**Common Fixes:**
- Verify connection string in Key Vault
- Check managed identity has Key Vault access
- Ensure all required app settings are configured
- Review application startup logs


#### Issue 3: JWT Validation Failures

**Symptoms:**
- All API requests return 401 Unauthorized
- Token validation errors in APIM logs

**Causes:**
- Incorrect tenant ID in policy
- Wrong audience configuration
- OpenID configuration URL unreachable

**Solutions:**
```powershell
# Verify named values
az apim nv show `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --named-value-id "azure-ad-tenant-id"

# Test OpenID configuration URL
curl "https://login.microsoftonline.com/{tenant-id}/v2.0/.well-known/openid-configuration"

# Check APIM can reach Azure AD
# Verify network connectivity and firewall rules
```

**Common Fixes:**
- Update tenant ID in named values
- Verify API application ID URI matches token audience
- Check APIM network connectivity to Azure AD
- Review policy XML for syntax errors

#### Issue 4: Rate Limiting Not Working

**Symptoms:**
- Clients can exceed 100 requests/minute
- No rate limit headers in responses

**Causes:**
- Policy not applied correctly
- Counter key extraction failing
- Rate limit policy misconfigured

**Solutions:**
```powershell
# Verify policy is applied
az apim api policy show `
    --resource-group "rg-dataapi-dev" `
    --service-name "apim-dataapi-dev" `
    --api-id "data-api"

# Check APIM logs for policy errors
az monitor log-analytics query `
    --workspace "log-dataapi-dev" `
    --analytics-query "ApiManagementGatewayLogs | where OperationId == 'rate-limit' | take 10"
```

**Common Fixes:**
- Verify rate-limit-by-key policy syntax
- Check counter-key expression extracts client ID correctly
- Ensure policy is in inbound section
- Test with valid JWT token


#### Issue 5: Key Vault Access Denied

**Symptoms:**
- APIM cannot retrieve named values from Key Vault
- Backend API cannot access secrets
- "Access denied" errors in logs

**Causes:**
- Managed identity not configured
- Missing Key Vault access policies
- Firewall blocking access

**Solutions:**
```powershell
# Verify managed identity exists
az apim show `
    --resource-group "rg-dataapi-dev" `
    --name "apim-dataapi-dev" `
    --query "identity"

# Check Key Vault access policies
az keyvault show `
    --name "kv-dataapi-dev" `
    --query "properties.accessPolicies"

# Grant access if missing
az keyvault set-policy `
    --name "kv-dataapi-dev" `
    --object-id "{managed-identity-object-id}" `
    --secret-permissions get list
```

**Common Fixes:**
- Enable managed identity on APIM and App Service
- Add access policies for managed identities
- Check Key Vault firewall settings
- Verify network connectivity

### Getting Help

**During Deployment:**
1. Check Azure Service Health
2. Review deployment logs
3. Consult this runbook
4. Contact deployment team lead

**For Critical Issues:**
1. Initiate rollback if necessary
2. Contact Azure Support (if Azure issue)
3. Escalate to architecture team
4. Document incident for post-mortem


---

## Emergency Contacts

### Deployment Team

| Role | Name | Contact | Availability |
|------|------|---------|--------------|
| Deployment Lead | [Name] | [Email/Phone] | Business hours |
| Infrastructure Engineer | [Name] | [Email/Phone] | On-call 24/7 |
| Application Developer | [Name] | [Email/Phone] | Business hours |
| Security Engineer | [Name] | [Email/Phone] | On-call 24/7 |

### Escalation Path

1. **Level 1**: Deployment team member
2. **Level 2**: Deployment Lead
3. **Level 3**: Engineering Manager
4. **Level 4**: CTO / VP Engineering

### External Contacts

| Service | Contact | Purpose |
|---------|---------|---------|
| Azure Support | [Support Portal] | Azure infrastructure issues |
| Azure AD Support | [Support Portal] | Authentication issues |
| Database Team | [Email] | Database issues |
| Network Team | [Email] | Network connectivity issues |

---

## Appendix

### Deployment Checklist Summary

**Pre-Deployment:**
- [ ] Prerequisites verified
- [ ] Permissions confirmed
- [ ] Configuration prepared
- [ ] Stakeholders notified

**Deployment:**
- [ ] Azure AD configured
- [ ] Infrastructure deployed
- [ ] Key Vault configured
- [ ] Backend API deployed
- [ ] APIM configured
- [ ] Monitoring enabled

**Post-Deployment:**
- [ ] Verification tests passed
- [ ] Smoke tests passed
- [ ] Monitoring confirmed
- [ ] Documentation updated
- [ ] Stakeholders notified

### Useful Commands Reference

```powershell
# Check deployment status
az deployment sub show --name "{deployment-name}"

# View resource group resources
az resource list --resource-group "rg-dataapi-dev" --output table

# Restart App Service
az webapp restart --resource-group "rg-dataapi-dev" --name "app-dataapi-dev"

# View APIM logs
az monitor log-analytics query --workspace "log-dataapi-dev" --analytics-query "ApiManagementGatewayLogs | take 10"

# Test API endpoint
curl -H "Authorization: Bearer {token}" https://apim-dataapi-dev.azure-api.net/api/v1/health
```

---

**Document Version:** 1.0.0  
**Last Updated:** November 18, 2025  
**Next Review Date:** February 18, 2026
