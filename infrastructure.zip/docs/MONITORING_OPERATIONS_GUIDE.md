# Monitoring and Operations Guide

## Overview

This guide provides comprehensive instructions for monitoring, operating, and maintaining the Data API infrastructure. It covers dashboard usage, alert response procedures, log analysis, and performance tuning recommendations.

**Target Audience:**
- Operations engineers
- Site reliability engineers (SRE)
- DevOps engineers
- Support engineers

## Table of Contents

1. [Monitoring Dashboard Usage](#monitoring-dashboard-usage)
2. [Alert Response Procedures](#alert-response-procedures)
3. [Log Analysis](#log-analysis)
4. [Performance Tuning](#performance-tuning)
5. [Operational Procedures](#operational-procedures)
6. [Troubleshooting Guide](#troubleshooting-guide)
7. [Maintenance Windows](#maintenance-windows)

---

## Monitoring Dashboard Usage

### Azure Portal Dashboards

#### Main API Dashboard

**Location:** Azure Portal > Dashboards > "Data API - Production"

**Key Metrics:**

1. **Request Volume**
   - Total requests per minute
   - Requests by endpoint
   - Requests by client
   - Success vs. error rate

2. **Response Times**
   - Average response time
   - P50, P95, P99 percentiles
   - Response time by endpoint
   - Backend vs. gateway latency

3. **Error Rates**
   - 4xx errors (client errors)
   - 5xx errors (server errors)
   - Error rate percentage
   - Errors by type

4. **Authentication Metrics**
   - Successful authentications
   - Failed authentications
   - Token validation failures
   - Authentication latency

5. **Rate Limiting**
   - Clients approaching limits
   - Rate limit violations
   - Throttled requests
   - Quota usage by client


**Accessing the Dashboard:**

```bash
# Open dashboard in browser
az portal dashboard show --name "Data API - Production"
```

**Dashboard Refresh Rate:** 1 minute (auto-refresh enabled)

#### Application Insights Dashboard

**Location:** Azure Portal > Application Insights > "appi-dataapi-prod"

**Key Views:**

1. **Live Metrics**
   - Real-time request rate
   - Real-time failure rate
   - Real-time response time
   - Server metrics (CPU, memory)

2. **Failures**
   - Failed requests
   - Failed dependencies
   - Exception details
   - Failure timeline

3. **Performance**
   - Operation performance
   - Dependency performance
   - Slow requests
   - Performance trends

4. **Availability**
   - Availability tests results
   - Uptime percentage
   - Response time from different locations
   - Failure locations

**Creating Custom Workbooks:**

```bash
# Export workbook template
az monitor app-insights workbook show \
    --resource-group "rg-dataapi-prod" \
    --name "api-performance-workbook" \
    --output json > workbook-template.json
```

### Log Analytics Workspaces

**Location:** Azure Portal > Log Analytics > "log-dataapi-prod"

**Pre-built Queries:**

1. **Request Analysis**
```kusto
ApiManagementGatewayLogs
| where TimeGenerated > ago(1h)
| summarize 
    TotalRequests = count(),
    SuccessRate = countif(ResponseCode < 400) * 100.0 / count(),
    AvgDuration = avg(Duration)
    by bin(TimeGenerated, 5m)
| render timechart
```

2. **Error Analysis**
```kusto
ApiManagementGatewayLogs
| where TimeGenerated > ago(24h)
| where ResponseCode >= 400
| summarize Count = count() by ResponseCode, OperationId
| order by Count desc
```

3. **Client Activity**
```kusto
ApiManagementGatewayLogs
| where TimeGenerated > ago(1h)
| extend ClientId = tostring(parse_json(Properties).clientId)
| summarize 
    Requests = count(),
    UniqueIPs = dcount(ClientIp)
    by ClientId
| order by Requests desc
```


### Key Performance Indicators (KPIs)

Monitor these KPIs continuously:

| KPI | Target | Warning | Critical | Action |
|-----|--------|---------|----------|--------|
| Availability | >99.9% | <99.9% | <99.5% | Investigate immediately |
| Average Response Time | <500ms | >500ms | >1000ms | Performance tuning |
| Error Rate | <1% | >1% | >5% | Investigate errors |
| P95 Response Time | <1000ms | >1000ms | >2000ms | Performance tuning |
| Authentication Success Rate | >99% | <99% | <95% | Check Azure AD |
| Rate Limit Violations | <10/hour | >10/hour | >50/hour | Review client behavior |

### Health Check Monitoring

**Backend API Health:**
```bash
# Check health endpoint
curl https://app-dataapi-prod.azurewebsites.net/health

# Expected response
{
  "status": "healthy",
  "timestamp": "2025-11-18T10:30:00Z",
  "dependencies": {
    "database": "healthy",
    "cache": "healthy"
  }
}
```

**APIM Gateway Health:**
```bash
# Check APIM gateway
curl https://apim-dataapi-prod.azure-api.net/api/v1/health

# Should return 200 OK
```

**Automated Health Checks:**

Configure availability tests in Application Insights:

```bash
# Create availability test
az monitor app-insights web-test create \
    --resource-group "rg-dataapi-prod" \
    --name "api-health-check" \
    --location "eastus" \
    --kind "ping" \
    --web-test-name "API Health Check" \
    --enabled true \
    --frequency 300 \
    --timeout 30 \
    --locations "us-east-1" "us-west-1" "eu-west-1" \
    --synthetic-monitor-id "api-health-check" \
    --web-test-kind "ping" \
    --request-url "https://apim-dataapi-prod.azure-api.net/api/v1/health"
```

**Health Check Schedule:**
- Frequency: Every 5 minutes
- Timeout: 30 seconds
- Locations: 3 geographic locations
- Alert on: 2 consecutive failures

---

## Alert Response Procedures

### Alert Severity Levels

| Severity | Response Time | Escalation | Examples |
|----------|---------------|------------|----------|
| P0 - Critical | Immediate | Immediate | Service down, data breach |
| P1 - High | 15 minutes | 30 minutes | High error rate, performance degradation |
| P2 - Medium | 1 hour | 4 hours | Elevated errors, approaching limits |
| P3 - Low | 24 hours | N/A | Configuration warnings, informational |


### Alert: High Error Rate

**Trigger:** Error rate >5% for 5 minutes

**Severity:** P1 - High

**Response Procedure:**

1. **Acknowledge Alert (0-2 minutes)**
   - Acknowledge in monitoring system
   - Notify team in incident channel

2. **Initial Assessment (2-5 minutes)**
   ```bash
   # Check current error rate
   az monitor metrics list \
       --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.ApiManagement/service/apim-dataapi-prod" \
       --metric "Requests" \
       --aggregation Total \
       --interval PT1M
   
   # Check error distribution
   az monitor log-analytics query \
       --workspace "log-dataapi-prod" \
       --analytics-query "ApiManagementGatewayLogs | where TimeGenerated > ago(15m) | where ResponseCode >= 400 | summarize count() by ResponseCode"
   ```

3. **Identify Root Cause (5-15 minutes)**
   - Check if errors are from specific endpoint
   - Identify if errors are client-side (4xx) or server-side (5xx)
   - Review recent deployments or changes
   - Check backend API health
   - Review Application Insights for exceptions

4. **Mitigation Actions**

   **If Backend API Issue:**
   ```bash
   # Check backend health
   curl https://app-dataapi-prod.azurewebsites.net/health
   
   # Review application logs
   az webapp log tail --resource-group "rg-dataapi-prod" --name "app-dataapi-prod"
   
   # Restart if needed
   az webapp restart --resource-group "rg-dataapi-prod" --name "app-dataapi-prod"
   ```

   **If Database Issue:**
   ```bash
   # Check database status
   az sql db show --resource-group "rg-dataapi-prod" --server "sql-dataapi-prod" --name "DataApiDb"
   
   # Check database metrics
   az monitor metrics list --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.Sql/servers/sql-dataapi-prod/databases/DataApiDb" --metric "cpu_percent"
   ```

   **If APIM Policy Issue:**
   ```bash
   # Review policy errors in logs
   az monitor log-analytics query --workspace "log-dataapi-prod" --analytics-query "ApiManagementGatewayLogs | where TimeGenerated > ago(15m) | where isnotempty(LastError)"
   ```

5. **Communication (Throughout)**
   - Update incident channel with findings
   - Notify stakeholders if customer-impacting
   - Update status page if public-facing

6. **Resolution and Verification**
   - Verify error rate returns to normal
   - Confirm no data loss or corruption
   - Document root cause and resolution

7. **Post-Incident (Within 24 hours)**
   - Create incident report
   - Conduct post-mortem if P0/P1
   - Implement preventive measures
   - Update runbooks if needed


### Alert: High Response Time

**Trigger:** Average response time >2 seconds for 5 minutes

**Severity:** P1 - High

**Response Procedure:**

1. **Check Current Performance**
   ```bash
   # Check response time metrics
   az monitor metrics list \
       --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.ApiManagement/service/apim-dataapi-prod" \
       --metric "Duration" \
       --aggregation Average \
       --interval PT1M
   ```

2. **Identify Slow Operations**
   ```kusto
   ApiManagementGatewayLogs
   | where TimeGenerated > ago(15m)
   | where Duration > 2000
   | summarize 
       Count = count(),
       AvgDuration = avg(Duration),
       MaxDuration = max(Duration)
       by OperationId
   | order by AvgDuration desc
   ```

3. **Check Backend Performance**
   ```bash
   # Check App Service metrics
   az monitor metrics list \
       --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.Web/sites/app-dataapi-prod" \
       --metric "AverageResponseTime" \
       --aggregation Average
   
   # Check database DTU usage
   az monitor metrics list \
       --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.Sql/servers/sql-dataapi-prod/databases/DataApiDb" \
       --metric "dtu_consumption_percent" \
       --aggregation Average
   ```

4. **Mitigation Actions**
   - Scale up App Service if CPU/memory high
   - Scale up database if DTU usage high
   - Enable caching if not already enabled
   - Review slow queries in database
   - Check for N+1 query problems

5. **Temporary Relief**
   ```bash
   # Scale up App Service
   az appservice plan update \
       --resource-group "rg-dataapi-prod" \
       --name "asp-dataapi-prod" \
       --sku P2V2
   
   # Scale up database
   az sql db update \
       --resource-group "rg-dataapi-prod" \
       --server "sql-dataapi-prod" \
       --name "DataApiDb" \
       --service-objective S3
   ```

### Alert: Backend Health Check Failure

**Trigger:** Health check fails 3 consecutive times

**Severity:** P0 - Critical

**Response Procedure:**

1. **Immediate Actions**
   ```bash
   # Check App Service status
   az webapp show --resource-group "rg-dataapi-prod" --name "app-dataapi-prod" --query "state"
   
   # Check recent logs
   az webapp log tail --resource-group "rg-dataapi-prod" --name "app-dataapi-prod" --lines 100
   ```

2. **Restart Application**
   ```bash
   az webapp restart --resource-group "rg-dataapi-prod" --name "app-dataapi-prod"
   ```

3. **If Restart Fails**
   - Check for deployment issues
   - Review configuration changes
   - Check database connectivity
   - Review Key Vault access
   - Consider rollback if recent deployment

4. **Escalation**
   - If not resolved in 15 minutes, escalate to P0
   - Engage development team
   - Consider activating disaster recovery


### Alert: Rate Limit Violations Spike

**Trigger:** >50 rate limit violations in 5 minutes

**Severity:** P2 - Medium

**Response Procedure:**

1. **Identify Violating Clients**
   ```kusto
   ApiManagementGatewayLogs
   | where TimeGenerated > ago(15m)
   | where ResponseCode == 429
   | extend ClientId = tostring(parse_json(Properties).clientId)
   | summarize Count = count() by ClientId, ClientIp
   | order by Count desc
   ```

2. **Assess Impact**
   - Is it a single client or multiple?
   - Is it legitimate traffic spike or abuse?
   - Are other clients affected?

3. **Actions Based on Assessment**

   **Legitimate Traffic Spike:**
   - Contact client to discuss rate limit increase
   - Temporarily increase rate limit if approved
   - Schedule permanent limit adjustment

   **Potential Abuse:**
   - Review client access patterns
   - Check for unusual behavior
   - Consider temporary IP block
   - Contact client security team

   **DDoS Attack:**
   - Escalate to P1
   - Enable DDoS protection
   - Block attacking IPs
   - Implement aggressive rate limiting

4. **Temporary Rate Limit Adjustment**
   ```xml
   <!-- Update APIM policy temporarily -->
   <rate-limit-by-key calls="200" 
                      renewal-period="60" 
                      counter-key="@((string)context.Variables["clientId"])" />
   ```

### Alert: Authentication Failure Spike

**Trigger:** >100 authentication failures in 5 minutes

**Severity:** P1 - High

**Response Procedure:**

1. **Identify Pattern**
   ```kusto
   ApiManagementGatewayLogs
   | where TimeGenerated > ago(15m)
   | where ResponseCode == 401
   | summarize Count = count() by ClientIp, bin(TimeGenerated, 1m)
   | order by Count desc
   ```

2. **Determine Cause**
   - Expired client credentials?
   - Azure AD outage?
   - Brute force attack?
   - Configuration issue?

3. **Mitigation**

   **If Azure AD Issue:**
   - Check Azure AD service health
   - Verify OpenID configuration endpoint
   - Check APIM connectivity to Azure AD

   **If Brute Force Attack:**
   - Block attacking IPs
   - Implement temporary IP restrictions
   - Notify security team
   - Review security logs

   **If Expired Credentials:**
   - Identify affected clients
   - Notify clients
   - Assist with credential renewal

---

## Log Analysis

### Log Types and Locations

| Log Type | Location | Retention | Purpose |
|----------|----------|-----------|---------|
| APIM Gateway Logs | Log Analytics | 90 days | Request/response tracking |
| Application Logs | App Service Logs | 30 days | Application errors |
| Security Logs | Azure AD Logs | 30 days | Authentication events |
| Database Logs | SQL Diagnostics | 90 days | Query performance |
| Audit Logs | Activity Log | 90 days | Configuration changes |


### Common Log Analysis Queries

#### Request Volume Analysis

```kusto
// Requests per hour by endpoint
ApiManagementGatewayLogs
| where TimeGenerated > ago(24h)
| summarize Count = count() by OperationId, bin(TimeGenerated, 1h)
| render timechart
```

#### Error Analysis by Client

```kusto
// Errors by client and error type
ApiManagementGatewayLogs
| where TimeGenerated > ago(24h)
| where ResponseCode >= 400
| extend ClientId = tostring(parse_json(Properties).clientId)
| summarize 
    Count = count(),
    UniqueErrors = dcount(ResponseCode)
    by ClientId, ResponseCode
| order by Count desc
```

#### Performance Analysis

```kusto
// Response time percentiles by endpoint
ApiManagementGatewayLogs
| where TimeGenerated > ago(1h)
| summarize 
    P50 = percentile(Duration, 50),
    P95 = percentile(Duration, 95),
    P99 = percentile(Duration, 99),
    Avg = avg(Duration)
    by OperationId
| order by P99 desc
```

#### Authentication Analysis

```kusto
// Authentication failures by reason
ApiManagementGatewayLogs
| where TimeGenerated > ago(24h)
| where ResponseCode == 401
| extend Reason = tostring(parse_json(ResponseBody).error.message)
| summarize Count = count() by Reason, bin(TimeGenerated, 1h)
| render timechart
```

#### Rate Limiting Analysis

```kusto
// Clients approaching rate limits
ApiManagementGatewayLogs
| where TimeGenerated > ago(1h)
| extend ClientId = tostring(parse_json(Properties).clientId)
| summarize RequestCount = count() by ClientId, bin(TimeGenerated, 1m)
| where RequestCount > 80  // 80% of 100 req/min limit
| order by RequestCount desc
```

#### Correlation ID Tracking

```kusto
// Track request flow by correlation ID
ApiManagementGatewayLogs
| where TimeGenerated > ago(24h)
| where CorrelationId == "550e8400-e29b-41d4-a716-446655440000"
| project TimeGenerated, OperationId, Method, Url, ResponseCode, Duration
| order by TimeGenerated asc
```

### Log Export and Archival

**Export Logs for Compliance:**

```bash
# Export logs to storage account
az monitor log-analytics workspace data-export create \
    --resource-group "rg-dataapi-prod" \
    --workspace-name "log-dataapi-prod" \
    --name "compliance-export" \
    --destination "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.Storage/storageAccounts/stdataapilogs" \
    --enable true \
    --tables "ApiManagementGatewayLogs"
```

**Archive to Cold Storage:**

```bash
# Configure lifecycle management
az storage account management-policy create \
    --account-name "stdataapilogs" \
    --policy @lifecycle-policy.json
```

**lifecycle-policy.json:**
```json
{
  "rules": [
    {
      "enabled": true,
      "name": "archive-old-logs",
      "type": "Lifecycle",
      "definition": {
        "actions": {
          "baseBlob": {
            "tierToArchive": {
              "daysAfterModificationGreaterThan": 90
            },
            "delete": {
              "daysAfterModificationGreaterThan": 365
            }
          }
        },
        "filters": {
          "blobTypes": ["blockBlob"],
          "prefixMatch": ["logs/"]
        }
      }
    }
  ]
}
```


---

## Performance Tuning

### Performance Optimization Checklist

#### APIM Performance Tuning

1. **Enable Caching**
   ```xml
   <!-- Add to APIM policy -->
   <cache-lookup vary-by-developer="false" vary-by-developer-groups="false">
       <vary-by-query-parameter>page</vary-by-query-parameter>
       <vary-by-query-parameter>pageSize</vary-by-query-parameter>
   </cache-lookup>
   
   <cache-store duration="60" />
   ```

2. **Optimize Policy Execution**
   - Minimize policy complexity
   - Use named values for static data
   - Avoid unnecessary transformations
   - Cache external lookups

3. **Scale APIM Capacity**
   ```bash
   # Scale up APIM units
   az apim update \
       --resource-group "rg-dataapi-prod" \
       --name "apim-dataapi-prod" \
       --sku-capacity 2
   ```

4. **Enable Compression**
   ```xml
   <!-- Add to outbound policy -->
   <set-header name="Content-Encoding" exists-action="override">
       <value>gzip</value>
   </set-header>
   ```

#### Backend API Performance Tuning

1. **Database Query Optimization**
   ```sql
   -- Identify slow queries
   SELECT TOP 10
       total_elapsed_time / execution_count AS avg_elapsed_time,
       execution_count,
       SUBSTRING(text, statement_start_offset/2 + 1,
           (CASE WHEN statement_end_offset = -1
               THEN LEN(CONVERT(nvarchar(max), text)) * 2
               ELSE statement_end_offset
           END - statement_start_offset)/2) AS query_text
   FROM sys.dm_exec_query_stats
   CROSS APPLY sys.dm_exec_sql_text(sql_handle)
   ORDER BY avg_elapsed_time DESC;
   ```

2. **Add Database Indexes**
   ```sql
   -- Create indexes for frequently queried columns
   CREATE NONCLUSTERED INDEX IX_AspNetUsers_EmailAddress
   ON AspNetUsers(EmailAddress)
   INCLUDE (UserName, IsActive);
   
   CREATE NONCLUSTERED INDEX IX_AspNetUsers_IsActive_CreatedDate
   ON AspNetUsers(IsActive, CreatedDate DESC);
   ```

3. **Enable Connection Pooling**
   ```csharp
   // In connection string
   "Server=...;Database=...;Min Pool Size=10;Max Pool Size=100;Pooling=true;"
   ```

4. **Implement Response Caching**
   ```csharp
   // In Program.cs
   builder.Services.AddResponseCaching();
   builder.Services.AddMemoryCache();
   
   // In controller
   [ResponseCache(Duration = 60, VaryByQueryKeys = new[] { "page", "pageSize" })]
   public async Task<IActionResult> GetUsers(int page, int pageSize)
   ```


5. **Optimize Serialization**
   ```csharp
   // Use System.Text.Json with optimized settings
   builder.Services.AddControllers()
       .AddJsonOptions(options =>
       {
           options.JsonSerializerOptions.DefaultIgnoreCondition = 
               JsonIgnoreCondition.WhenWritingNull;
           options.JsonSerializerOptions.PropertyNamingPolicy = 
               JsonNamingPolicy.CamelCase;
       });
   ```

6. **Enable Async Operations**
   ```csharp
   // Use async/await throughout
   public async Task<ActionResult<List<AspNetUserDto>>> GetUsers(
       int page = 1, int pageSize = 50)
   {
       var users = await _context.AspNetUsers
           .Where(u => u.IsActive)
           .Skip((page - 1) * pageSize)
           .Take(pageSize)
           .ToListAsync();
       
       return Ok(users);
   }
   ```

#### Scaling Recommendations

**When to Scale:**

| Metric | Threshold | Action |
|--------|-----------|--------|
| CPU Usage | >70% sustained | Scale up or out |
| Memory Usage | >80% sustained | Scale up |
| Response Time | >1s P95 | Scale up or optimize |
| Request Queue | >100 | Scale out |
| Database DTU | >80% | Scale up database |

**Scaling Commands:**

```bash
# Scale App Service Plan
az appservice plan update \
    --resource-group "rg-dataapi-prod" \
    --name "asp-dataapi-prod" \
    --sku P2V2

# Scale out App Service (add instances)
az appservice plan update \
    --resource-group "rg-dataapi-prod" \
    --name "asp-dataapi-prod" \
    --number-of-workers 3

# Scale database
az sql db update \
    --resource-group "rg-dataapi-prod" \
    --server "sql-dataapi-prod" \
    --name "DataApiDb" \
    --service-objective S3

# Scale APIM
az apim update \
    --resource-group "rg-dataapi-prod" \
    --name "apim-dataapi-prod" \
    --sku-capacity 2
```

### Performance Testing

**Load Testing with Azure Load Testing:**

```bash
# Create load test
az load test create \
    --name "api-load-test" \
    --resource-group "rg-dataapi-prod" \
    --test-plan @load-test-plan.jmx \
    --engine-instances 5
```

**Performance Benchmarks:**

| Scenario | Target | Acceptable | Poor |
|----------|--------|------------|------|
| Simple GET | <100ms | <200ms | >500ms |
| Complex GET | <300ms | <500ms | >1000ms |
| POST/PUT | <500ms | <1000ms | >2000ms |
| DELETE | <200ms | <400ms | >800ms |

---

## Operational Procedures

### Daily Operations Checklist

**Morning Checks (9:00 AM):**
- [ ] Review overnight alerts
- [ ] Check system health dashboard
- [ ] Verify backup completion
- [ ] Review error rate trends
- [ ] Check for expiring certificates/secrets
- [ ] Review capacity metrics

**Afternoon Checks (2:00 PM):**
- [ ] Review performance metrics
- [ ] Check for anomalies
- [ ] Review client activity
- [ ] Check rate limit usage
- [ ] Review security logs

**End of Day (5:00 PM):**
- [ ] Document any incidents
- [ ] Update on-call handoff notes
- [ ] Review tomorrow's maintenance
- [ ] Check alert configuration


### Weekly Operations Tasks

**Monday:**
- [ ] Review previous week's incidents
- [ ] Check capacity planning metrics
- [ ] Review client onboarding requests
- [ ] Update documentation if needed

**Wednesday:**
- [ ] Review security logs
- [ ] Check for security updates
- [ ] Verify backup integrity
- [ ] Review performance trends

**Friday:**
- [ ] Generate weekly report
- [ ] Review upcoming maintenance
- [ ] Check certificate expiration (30-day window)
- [ ] Update on-call schedule

### Monthly Operations Tasks

- [ ] Conduct security audit
- [ ] Review and update alert thresholds
- [ ] Capacity planning review
- [ ] Client access review
- [ ] Update operational documentation
- [ ] Review and optimize costs
- [ ] Test disaster recovery procedures
- [ ] Review SLA compliance
- [ ] Conduct performance review
- [ ] Update runbooks based on incidents

### Backup and Recovery

**Backup Schedule:**

| Component | Frequency | Retention | Location |
|-----------|-----------|-----------|----------|
| Database | Daily | 35 days | Geo-redundant |
| APIM Configuration | Daily | 30 days | Storage account |
| Key Vault | Continuous | 90 days | Soft delete enabled |
| Application Code | On commit | Indefinite | Git repository |

**Backup Verification:**

```bash
# Verify database backup
az sql db list-backups \
    --resource-group "rg-dataapi-prod" \
    --server "sql-dataapi-prod" \
    --database "DataApiDb"

# Test restore (to separate database)
az sql db restore \
    --resource-group "rg-dataapi-prod" \
    --server "sql-dataapi-prod" \
    --name "DataApiDb-test-restore" \
    --source-database "DataApiDb" \
    --time "2025-11-18T09:00:00Z"
```

**Recovery Time Objectives (RTO):**
- Database: 1 hour
- Backend API: 30 minutes
- APIM Configuration: 15 minutes
- Full system: 2 hours

**Recovery Point Objectives (RPO):**
- Database: 5 minutes (point-in-time restore)
- Configuration: 24 hours
- Application code: 0 (version controlled)

---

## Troubleshooting Guide

### Common Issues and Solutions

#### Issue: Slow API Response Times

**Symptoms:**
- Response times >2 seconds
- Timeout errors
- Client complaints

**Diagnosis:**
```bash
# Check APIM metrics
az monitor metrics list \
    --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.ApiManagement/service/apim-dataapi-prod" \
    --metric "Duration" \
    --aggregation Average

# Check backend metrics
az monitor metrics list \
    --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.Web/sites/app-dataapi-prod" \
    --metric "AverageResponseTime" \
    --aggregation Average
```

**Solutions:**
1. Identify slow endpoints in logs
2. Check database query performance
3. Review recent code changes
4. Scale up resources if needed
5. Enable caching for read operations
6. Optimize database queries


#### Issue: High Memory Usage

**Symptoms:**
- App Service memory >80%
- Out of memory exceptions
- Application restarts

**Diagnosis:**
```bash
# Check memory metrics
az monitor metrics list \
    --resource "/subscriptions/{sub-id}/resourceGroups/rg-dataapi-prod/providers/Microsoft.Web/sites/app-dataapi-prod" \
    --metric "MemoryWorkingSet" \
    --aggregation Average

# Check for memory leaks in Application Insights
```

**Solutions:**
1. Review application logs for memory issues
2. Check for memory leaks in code
3. Optimize data structures
4. Implement proper disposal patterns
5. Scale up App Service Plan
6. Enable memory profiling

#### Issue: Database Connection Failures

**Symptoms:**
- "Cannot connect to database" errors
- Timeout errors
- Health check failures

**Diagnosis:**
```bash
# Check database status
az sql db show \
    --resource-group "rg-dataapi-prod" \
    --server "sql-dataapi-prod" \
    --name "DataApiDb" \
    --query "status"

# Check connection string in Key Vault
az keyvault secret show \
    --vault-name "kv-dataapi-prod" \
    --name "SqlConnectionString"

# Test connectivity
sqlcmd -S sql-dataapi-prod.database.windows.net -d DataApiDb -U sqladmin -P {password}
```

**Solutions:**
1. Verify database is online
2. Check firewall rules
3. Verify connection string
4. Check managed identity permissions
5. Review connection pool settings
6. Check for connection leaks

#### Issue: Authentication Failures

**Symptoms:**
- 401 Unauthorized errors
- "Invalid token" messages
- Clients unable to authenticate

**Diagnosis:**
```bash
# Check Azure AD service health
az rest --method get --url "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement/healthOverviews"

# Verify APIM policy configuration
az apim api policy show \
    --resource-group "rg-dataapi-prod" \
    --service-name "apim-dataapi-prod" \
    --api-id "data-api"

# Check recent authentication logs
az monitor log-analytics query \
    --workspace "log-dataapi-prod" \
    --analytics-query "ApiManagementGatewayLogs | where ResponseCode == 401 | take 10"
```

**Solutions:**
1. Verify Azure AD is operational
2. Check tenant ID in APIM policy
3. Verify OpenID configuration URL
4. Check client credentials haven't expired
5. Verify API application ID URI
6. Test token acquisition manually

---

## Maintenance Windows

### Scheduled Maintenance

**Standard Maintenance Window:**
- Day: Sunday
- Time: 2:00 AM - 6:00 AM (local time)
- Frequency: Monthly (first Sunday)
- Duration: Up to 4 hours

**Maintenance Activities:**
- Azure platform updates
- Database maintenance
- Certificate renewals
- Configuration updates
- Performance optimization
- Security patches


### Maintenance Procedures

**Pre-Maintenance (T-7 days):**
- [ ] Notify stakeholders
- [ ] Update status page
- [ ] Review maintenance plan
- [ ] Prepare rollback plan
- [ ] Backup all configurations
- [ ] Test in staging environment

**Pre-Maintenance (T-1 day):**
- [ ] Final stakeholder notification
- [ ] Verify backup completion
- [ ] Prepare monitoring dashboards
- [ ] Brief on-call team
- [ ] Verify rollback procedures

**During Maintenance:**
- [ ] Update status page to "Maintenance in Progress"
- [ ] Execute maintenance tasks
- [ ] Monitor system health
- [ ] Document any issues
- [ ] Verify each step before proceeding

**Post-Maintenance:**
- [ ] Run smoke tests
- [ ] Verify all services operational
- [ ] Check performance metrics
- [ ] Review logs for errors
- [ ] Update status page to "Operational"
- [ ] Notify stakeholders of completion
- [ ] Document maintenance results

### Emergency Maintenance

For critical security patches or urgent fixes:

**Approval Required:**
- Change Advisory Board (for production)
- Engineering Manager
- Security Team (for security patches)

**Notification:**
- Minimum 4 hours notice (if possible)
- Update status page immediately
- Email all stakeholders
- Post in communication channels

**Execution:**
- Follow standard maintenance procedures
- Increased monitoring during and after
- Rollback plan ready
- Extended support coverage

---

## Operational Metrics and Reporting

### Daily Operations Report

**Automated Report Contents:**
- Request volume (24h)
- Error rate (24h)
- Average response time (24h)
- Top 5 clients by request volume
- Top 5 errors
- Alert summary
- Capacity utilization

**Generation:**
```bash
# Generate daily report
az monitor log-analytics query \
    --workspace "log-dataapi-prod" \
    --analytics-query @daily-report-query.kql \
    --output json > daily-report-$(date +%Y%m%d).json
```

### Weekly Operations Report

**Contents:**
- Week-over-week trends
- Incident summary
- Performance analysis
- Capacity planning metrics
- Client activity summary
- Security events
- Upcoming maintenance

### Monthly SLA Report

**SLA Targets:**
- Availability: 99.9%
- Response Time (P95): <1 second
- Error Rate: <1%

**Report Contents:**
- Actual vs. target metrics
- Downtime analysis
- Performance trends
- Incident impact
- Improvement recommendations

**SLA Calculation:**
```kusto
// Calculate monthly availability
ApiManagementGatewayLogs
| where TimeGenerated > startofmonth(now())
| summarize 
    TotalRequests = count(),
    SuccessfulRequests = countif(ResponseCode < 500),
    Availability = (countif(ResponseCode < 500) * 100.0) / count()
| project Availability
```

---

## Appendix

### Useful Commands Reference

```bash
# Quick health check
curl https://apim-dataapi-prod.azure-api.net/api/v1/health

# Check APIM status
az apim show --resource-group "rg-dataapi-prod" --name "apim-dataapi-prod" --query "provisioningState"

# Check App Service status
az webapp show --resource-group "rg-dataapi-prod" --name "app-dataapi-prod" --query "state"

# View recent logs
az webapp log tail --resource-group "rg-dataapi-prod" --name "app-dataapi-prod"

# Restart services
az webapp restart --resource-group "rg-dataapi-prod" --name "app-dataapi-prod"

# Check database status
az sql db show --resource-group "rg-dataapi-prod" --server "sql-dataapi-prod" --name "DataApiDb" --query "status"

# View metrics
az monitor metrics list --resource {resource-id} --metric {metric-name}
```

### Contact Information

**Operations Team:**
- On-Call Engineer: [Phone/Email]
- Operations Lead: [Phone/Email]
- Escalation: [Phone/Email]

**Support Channels:**
- Slack: #dataapi-ops
- Email: dataapi-ops@company.com
- Phone: [On-call number]

**External Support:**
- Azure Support: [Portal]
- Database Team: [Email]
- Security Team: [Email]

---

**Document Version:** 1.0.0  
**Last Updated:** November 18, 2025  
**Next Review Date:** February 18, 2026
