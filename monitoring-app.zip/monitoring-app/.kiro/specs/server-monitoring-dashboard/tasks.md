# Implementation Plan

- [x] 1. Create ASP.NET Core MVC project structure and configuration





  - Create new ASP.NET Core MVC project targeting .NET 6 or higher
  - Set up project structure with folders: Controllers, Services, ViewModels, Configuration, Views/Monitoring
  - Create appsettings.json with MonitoringSettings section containing ServerUrls array, RefreshIntervalSeconds (default 10), and RequestTimeoutSeconds (default 5)
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 2. Implement configuration and data models






  - [x] 2.1 Create MonitoringSettings configuration class

    - Write MonitoringSettings.cs in Configuration folder with properties: List<string> ServerUrls, int RefreshIntervalSeconds, int RequestTimeoutSeconds
    - Add default values in property initializers
    - _Requirements: 3.1, 3.2, 3.3, 3.4_
  

  - [x] 2.2 Create ViewModels for data transfer





    - Write MonitoringViewModel.cs with properties: List<ServerMetrics> Servers, DateTime LastRefresh, int TotalUniqueUsers, int TotalSessions, List<string> AllActiveUsers, bool HasErrors, int OnlineServerCount, bool HasLoadImbalance
    - Write ServerMetrics.cs with properties for server identity (ServerName, ServerUrl), status (IsOnline, ErrorMessage, ResponseTimeMs), metrics from all three endpoints, and calculated properties (LoadPercentage, StatusClass, ResponseTimeClass)
    - _Requirements: 1.1, 1.2, 5.1, 5.2, 5.3, 5.4, 5.5, 6.1, 7.1, 7.2_
  


  - [x] 2.3 Create internal API response models


    - Write ActiveUsersResponse class for /api/sessionmetrics/active-users endpoint
    - Write ServerStatsResponse class for /api/sessionmetrics/server-stats endpoint
    - Write MemoryStatsResponse class for /api/sessionmetrics/memory-stats endpoint
    - _Requirements: 5.1, 5.2, 5.3_

- [x] 3. Implement ServerMonitoringService for API calls and data aggregation





  - [x] 3.1 Create service interface


    - Write IServerMonitoringService.cs interface with single method: Task<MonitoringViewModel> GetAllServerMetricsAsync()
    - _Requirements: 1.4, 5.4_
  
  - [x] 3.2 Implement parallel API fetching logic



    - Write ServerMonitoringService.cs class implementing IServerMonitoringService
    - Inject HttpClient and IOptions<MonitoringSettings> via constructor
    - Implement GetAllServerMetricsAsync to iterate through configured ServerUrls
    - Use Task.WhenAll to fetch metrics from all servers in parallel
    - For each server, create three parallel tasks to call /api/sessionmetrics/active-users, /api/sessionmetrics/server-stats, and /api/sessionmetrics/memory-stats
    - Use Stopwatch to measure response time for each server
    - _Requirements: 1.4, 4.1, 4.2, 5.1, 5.2, 5.3, 5.4, 7.1_
  
  - [x] 3.3 Implement error handling and timeout management


    - Wrap each server's API calls in try-catch blocks to isolate failures
    - Handle TaskCanceledException for timeouts (set IsOnline = false, ErrorMessage = "Request timed out")
    - Handle HttpRequestException for network errors (set IsOnline = false, ErrorMessage with exception details)
    - Handle JsonException for invalid JSON responses (set IsOnline = false, ErrorMessage = "Invalid response format")
    - Handle generic exceptions as fallback (set IsOnline = false, ErrorMessage with exception message)
    - Configure JsonSerializerOptions with PropertyNameCaseInsensitive = true for deserialization
    - Continue processing other servers even if one fails
    - _Requirements: 4.3, 9.1, 9.2, 9.3, 9.4, 9.5_
  
  - [x] 3.4 Implement data aggregation and calculations


    - Aggregate ServerMetrics from all servers into MonitoringViewModel
    - Calculate TotalUniqueUsers by deduplicating usernames across all servers using HashSet<string>
    - Calculate TotalSessions by summing ActiveSessions from all online servers
    - Create AllActiveUsers list with distinct, sorted usernames
    - Calculate OnlineServerCount by counting servers with IsOnline = true
    - Set HasErrors = true if any server is offline
    - Calculate LoadPercentage for each server (ActiveUserCount / TotalUniqueUsers * 100)
    - Detect load imbalance by checking if any server has >2x load of another server
    - Set StatusClass ("online" or "offline") and ResponseTimeClass ("fast", "slow", "timeout") for each server
    - _Requirements: 1.1, 1.3, 6.1, 6.2, 6.3, 6.4, 7.2, 7.4, 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 4. Implement MonitoringController with actions


  - [x] 4.1 Create controller with Index action


    - Write MonitoringController.cs in Controllers folder
    - Inject IServerMonitoringService via constructor
    - Implement async Index() action that returns View
    - _Requirements: 1.1_
  
  - [x] 4.2 Create RefreshMetrics action for AJAX calls


    - Implement async RefreshMetrics() action that calls IServerMonitoringService.GetAllServerMetricsAsync()
    - Return JsonResult with MonitoringViewModel
    - Add try-catch to handle errors and return appropriate error response
    - _Requirements: 2.4, 9.1_

- [x] 5. Configure dependency injection and Program.cs



  - Configure services in Program.cs: AddControllersWithViews, Configure<MonitoringSettings> from appsettings
  - Validate MonitoringSettings at startup (ensure ServerUrls is not null or empty)
  - Register HttpClient with Windows Authentication: AddHttpClient<IServerMonitoringService, ServerMonitoringService> with HttpClientHandler UseDefaultCredentials = true and PreAuthenticate = true
  - Configure HttpClient timeout from MonitoringSettings.RequestTimeoutSeconds
  - Set up default route to Monitoring/Index
  - Add middleware: UseStaticFiles, UseRouting, MapControllerRoute
  - _Requirements: 3.1, 3.4, 3.5, 4.1, 4.2_

- [x] 6. Create Razor views for dashboard UI


  - [x] 6.1 Create main dashboard view


    - Write Views/Monitoring/Index.cshtml with @model MonitoringViewModel
    - Create dashboard container with summary cards section displaying TotalUniqueUsers, TotalSessions, OnlineServerCount, and LastRefresh timestamp
    - Add manual refresh button with id="refreshBtn" and 🔄 emoji icon
    - Create server metrics grid container with id="serverMetrics"
    - Add all active users section with user tags display
    - Include hidden input or data attribute with RefreshIntervalSeconds from configuration for JavaScript
    - _Requirements: 1.1, 1.2, 1.3, 2.4, 8.1, 8.2, 8.3, 8.5, 10.4_
  
  - [x] 6.2 Create server metrics partial view


    - Write Views/Monitoring/_ServerMetricsPartial.cshtml with @model List<ServerMetrics>
    - For each server, render a server card with conditional CSS class based on IsOnline status
    - Display server header with status icon (✅ for online, ❌ for offline) and server name
    - Show response time with color-coded class
    - Display metrics section with ActiveUserCount, ActiveSessions, WorkingSetMB, PrivateMemoryMB
    - Render load distribution section with percentage label and progress bar (div with width style set to LoadPercentage)
    - Display active usernames as tag-style spans
    - Conditionally show error message section if IsOnline is false
    - Show warning icon (⚠️) if HasLoadImbalance is true
    - _Requirements: 1.2, 5.5, 6.2, 6.5, 7.2, 7.4, 8.5, 9.1_
  
  - [x] 6.3 Create shared layout


    - Write Views/Shared/_Layout.cshtml with basic HTML structure
    - Include link to monitoring.css stylesheet
    - Include script tag for monitoring.js
    - Add @RenderBody() for view content
    - _Requirements: 8.1, 8.4_

- [x] 7. Implement CSS styling with native CSS



  - Write wwwroot/css/monitoring.css with complete styling
  - Define CSS variables for color scheme: --primary (#3498db), --success (#27ae60), --warning (#f39c12), --danger (#e74c3c), --info (#667eea), --secondary (#95a5a6)
  - Style dashboard container, summary cards with gradient backgrounds
  - Style server cards with border-radius, box-shadow, and conditional left border color (green for online, red for offline)
  - Style progress bars with height, border-radius, background, and animated fill with gradient
  - Style user tags with inline-block display, padding, border-radius, and primary color background
  - Add hover effects for cards (translateY transform, box-shadow increase)
  - Add animations for progress bar fill (width transition), refresh button (rotate during loading), and status indicators
  - Implement responsive design with media queries: desktop (>768px) shows multi-column grid, mobile (<768px) shows single column
  - Style response time with color classes: .fast (green), .slow (orange), .timeout (red)
  - _Requirements: 6.5, 7.4, 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 8. Implement JavaScript for auto-refresh and interactivity



  - [x] 8.1 Create auto-refresh mechanism




    - Write wwwroot/js/monitoring.js with auto-refresh functionality
    - Read refresh interval from page data attribute or hidden input
    - Implement startAutoRefresh() function using setInterval to call refreshMetrics() at configured interval
    - Implement stopAutoRefresh() function to clear interval
    - Add visibility change event listener to pause auto-refresh when page is hidden and resume when visible
    - Use isRefreshing flag to prevent concurrent refresh requests
    - _Requirements: 2.1, 2.2, 2.3_
  


  - [x] 8.2 Implement AJAX refresh functionality

    - Implement async refreshMetrics() function that fetches /Monitoring/RefreshMetrics endpoint
    - Parse JSON response and call updateDashboard() with data
    - Handle fetch errors gracefully with user-friendly error messages
    - Show/hide loading indicator during refresh


    - _Requirements: 2.4, 2.5, 9.1_
  
  - [x] 8.3 Implement DOM update logic

    - Implement updateDashboard(data) function to update summary cards with new values
    - Update server metrics section by replacing innerHTML with rendered server cards
    - Update all active users section with new user tags
    - Format timestamp for display
    - Update last refresh timestamp display
    - _Requirements: 1.1, 1.2, 1.3, 10.4_
  
  - [x] 8.4 Add manual refresh button handler

    - Add click event listener to refresh button
    - Call refreshMetrics() immediately when clicked
    - Disable button and show loading state during refresh
    - Re-enable button after refresh completes
    - _Requirements: 2.4, 2.5_
  
  - [x] 8.5 Initialize on page load

    - Add DOMContentLoaded event listener to initialize auto-refresh
    - Call refreshMetrics() once on page load to get initial data
    - Start auto-refresh timer
    - _Requirements: 2.1_
