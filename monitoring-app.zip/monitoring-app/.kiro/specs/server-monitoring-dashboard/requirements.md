# Requirements Document

## Introduction

This document specifies the requirements for a standalone ASP.NET Core MVC web application that monitors multiple servers by consuming REST API endpoints. The application displays real-time session metrics from multiple servers behind a load balancer, providing administrators with visibility into server health, load distribution, active users, and memory usage across the server farm.

## Glossary

- **Monitoring Application**: The standalone ASP.NET Core MVC web application that consumes metrics from remote servers
- **Target Server**: A remote server being monitored that exposes REST API endpoints for session metrics
- **Dashboard**: The main user interface displaying aggregated and per-server metrics
- **Load Distribution**: The percentage of active users or sessions handled by each Target Server
- **Windows Authentication**: The authentication mechanism using the current Windows user credentials to access remote APIs
- **Auto-refresh**: The automatic periodic fetching of metrics from Target Servers at configured intervals
- **Server Status**: The operational state of a Target Server (online or offline)
- **Response Time**: The duration in milliseconds taken for a Target Server to respond to an API request
- **Active User**: A user with an active session on one or more Target Servers
- **Session Metrics**: Data about active users, sessions, and memory usage on a Target Server

## Requirements

### Requirement 1

**User Story:** As a system administrator, I want to view real-time metrics from multiple servers in a single dashboard, so that I can monitor the health and load distribution of my server farm without accessing each server individually.

#### Acceptance Criteria

1. WHEN the administrator navigates to the Dashboard, THE Monitoring Application SHALL display summary cards showing total unique users, total sessions, online server count, and last refresh timestamp
2. WHEN the administrator views the Dashboard, THE Monitoring Application SHALL display per-server metrics cards for each configured Target Server showing session statistics, memory usage, active usernames, load distribution percentage, Server Status, and Response Time
3. WHEN the administrator views the Dashboard, THE Monitoring Application SHALL display a combined list of all Active Users across all Target Servers
4. WHEN multiple Target Servers are configured, THE Monitoring Application SHALL fetch metrics from all Target Servers simultaneously using parallel requests
5. WHERE a Target Server is unreachable or returns an error, THE Monitoring Application SHALL display the Server Status as offline with an error message while continuing to display metrics from other Target Servers

### Requirement 2

**User Story:** As a system administrator, I want the dashboard to automatically refresh at regular intervals, so that I can see up-to-date metrics without manual intervention.

#### Acceptance Criteria

1. WHEN the Dashboard is loaded, THE Monitoring Application SHALL automatically refresh metrics from all Target Servers at intervals specified in the configuration (default 10 seconds)
2. WHEN the browser tab containing the Dashboard becomes hidden, THE Monitoring Application SHALL pause the Auto-refresh mechanism to conserve resources
3. WHEN the browser tab containing the Dashboard becomes visible again, THE Monitoring Application SHALL resume the Auto-refresh mechanism
4. WHEN the administrator clicks the manual refresh button, THE Monitoring Application SHALL immediately fetch metrics from all Target Servers regardless of the Auto-refresh schedule
5. WHEN a refresh operation is in progress, THE Monitoring Application SHALL display a loading indicator to inform the administrator

### Requirement 3

**User Story:** As a system administrator, I want to configure which servers to monitor and how often to refresh data, so that I can adapt the monitoring to my infrastructure needs.

#### Acceptance Criteria

1. THE Monitoring Application SHALL read configuration from appsettings.json containing server URLs, refresh interval in seconds, and request timeout in seconds
2. WHEN the Monitoring Application starts, THE Monitoring Application SHALL load the list of Target Server URLs from the MonitoringSettings configuration section
3. WHEN the Monitoring Application starts, THE Monitoring Application SHALL load the refresh interval from the MonitoringSettings configuration section with a default value of 10 seconds
4. WHEN the Monitoring Application starts, THE Monitoring Application SHALL load the request timeout from the MonitoringSettings configuration section with a default value of 5 seconds
5. WHERE the configuration file is missing or invalid, THE Monitoring Application SHALL log an error and fail to start with a descriptive error message

### Requirement 4

**User Story:** As a system administrator, I want the application to use Windows Authentication when calling remote APIs, so that I can leverage existing domain security without managing separate credentials.

#### Acceptance Criteria

1. WHEN the Monitoring Application makes HTTP requests to Target Server endpoints, THE Monitoring Application SHALL use Windows Authentication with the current user's default credentials
2. WHEN a Target Server requires authentication, THE Monitoring Application SHALL automatically provide Windows credentials without prompting the administrator
3. WHERE a Target Server denies access due to insufficient permissions, THE Monitoring Application SHALL display the Server Status as offline with an authentication error message

### Requirement 5

**User Story:** As a system administrator, I want to see detailed metrics for each server including active users, sessions, and memory usage, so that I can identify performance issues and resource constraints.

#### Acceptance Criteria

1. WHEN the Monitoring Application fetches metrics from a Target Server, THE Monitoring Application SHALL call the /api/sessionmetrics/active-users endpoint to retrieve active user count, active usernames, users by server, and timestamp
2. WHEN the Monitoring Application fetches metrics from a Target Server, THE Monitoring Application SHALL call the /api/sessionmetrics/server-stats endpoint to retrieve active users on this server, total active users, and timestamp
3. WHEN the Monitoring Application fetches metrics from a Target Server, THE Monitoring Application SHALL call the /api/sessionmetrics/memory-stats endpoint to retrieve working set memory, private memory, active sessions, estimated tracking memory, and timestamp
4. WHEN the Monitoring Application receives responses from all three endpoints for a Target Server, THE Monitoring Application SHALL aggregate the data into a single ServerMetrics object
5. WHEN the Monitoring Application displays server metrics, THE Monitoring Application SHALL show working set memory in megabytes, private memory in megabytes, and estimated tracking memory in kilobytes

### Requirement 6

**User Story:** As a system administrator, I want to see visual indicators of load distribution across servers, so that I can quickly identify load imbalances that may require intervention.

#### Acceptance Criteria

1. WHEN the Dashboard displays per-server metrics, THE Monitoring Application SHALL calculate the Load Distribution percentage for each Target Server based on active user count relative to total active users
2. WHEN the Dashboard displays per-server metrics, THE Monitoring Application SHALL render a progress bar for each Target Server showing the Load Distribution percentage
3. WHEN one Target Server handles more than twice the load of another Target Server, THE Monitoring Application SHALL display a warning indicator on the Dashboard
4. WHEN all Target Servers are offline, THE Monitoring Application SHALL display zero percent Load Distribution for all servers
5. WHEN the Dashboard displays Load Distribution, THE Monitoring Application SHALL use color coding with green for balanced load and orange for imbalanced load

### Requirement 7

**User Story:** As a system administrator, I want to see response times for each server, so that I can identify performance degradation or network issues.

#### Acceptance Criteria

1. WHEN the Monitoring Application makes requests to a Target Server, THE Monitoring Application SHALL measure the Response Time in milliseconds from request initiation to response completion
2. WHEN the Dashboard displays per-server metrics, THE Monitoring Application SHALL show the Response Time for each Target Server
3. WHEN a Target Server fails to respond within the configured timeout period, THE Monitoring Application SHALL record the Response Time as the timeout value and mark the Server Status as offline
4. WHEN the Dashboard displays Response Time, THE Monitoring Application SHALL use color coding with green for fast responses (under 1000ms), orange for slow responses (1000-3000ms), and red for very slow or timed out responses (over 3000ms)

### Requirement 8

**User Story:** As a system administrator, I want a modern, responsive user interface that works on desktop and mobile devices, so that I can monitor servers from any device.

#### Acceptance Criteria

1. THE Monitoring Application SHALL render the Dashboard using responsive CSS that adapts to different screen sizes
2. WHEN the Dashboard is viewed on a mobile device, THE Monitoring Application SHALL display server metrics in a single column layout
3. WHEN the Dashboard is viewed on a desktop device, THE Monitoring Application SHALL display server metrics in a multi-column grid layout
4. THE Monitoring Application SHALL use native CSS without external frameworks such as Bootstrap
5. WHEN the Dashboard displays Server Status, THE Monitoring Application SHALL use color-coded visual indicators with green for online servers and red for offline servers

### Requirement 9

**User Story:** As a system administrator, I want the application to handle errors gracefully, so that temporary issues with one server don't prevent me from monitoring other servers.

#### Acceptance Criteria

1. WHEN a Target Server is unreachable, THE Monitoring Application SHALL continue fetching metrics from other Target Servers without interruption
2. WHEN a Target Server returns an HTTP error status code, THE Monitoring Application SHALL log the error and display the Server Status as offline with the error message
3. WHEN a Target Server times out, THE Monitoring Application SHALL log the timeout and display the Server Status as offline with a timeout message
4. WHEN a Target Server returns invalid JSON, THE Monitoring Application SHALL log the parsing error and display the Server Status as offline with a data format error message
5. WHEN all Target Servers are offline, THE Monitoring Application SHALL display the Dashboard with zero metrics and offline status for all servers

### Requirement 10

**User Story:** As a system administrator, I want to see aggregated statistics across all servers, so that I can understand the overall system load and user activity.

#### Acceptance Criteria

1. WHEN the Dashboard displays summary cards, THE Monitoring Application SHALL calculate the total number of unique Active Users across all Target Servers by deduplicating usernames
2. WHEN the Dashboard displays summary cards, THE Monitoring Application SHALL calculate the total number of sessions by summing active sessions from all online Target Servers
3. WHEN the Dashboard displays summary cards, THE Monitoring Application SHALL count the number of online Target Servers based on Server Status
4. WHEN the Dashboard displays the combined user list, THE Monitoring Application SHALL show all unique Active Users sorted alphabetically
5. WHEN the Dashboard displays aggregated statistics, THE Monitoring Application SHALL exclude metrics from offline Target Servers from the totals
