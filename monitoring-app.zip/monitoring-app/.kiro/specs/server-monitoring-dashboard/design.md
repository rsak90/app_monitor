# Design Document

## Overview

The Server Monitoring Dashboard is a standalone ASP.NET Core MVC application that provides real-time visibility into multiple servers behind a load balancer. The application follows a clean architecture pattern with separation of concerns between presentation (MVC), business logic (services), and configuration. It uses HttpClient with Windows Authentication to consume REST APIs from target servers and aggregates the data for display in a responsive, auto-refreshing dashboard.

### Technology Stack

- **Framework**: ASP.NET Core 6.0 or higher
- **Pattern**: MVC (Model-View-Controller)
- **Authentication**: Windows Authentication (UseDefaultCredentials)
- **HTTP Client**: HttpClient with dependency injection
- **Configuration**: appsettings.json with strongly-typed options
- **Frontend**: Razor Views with native CSS and vanilla JavaScript
- **Async Pattern**: async/await throughout

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Browser (Client)                         │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Dashboard UI (Razor View + JavaScript)                │ │
│  │  - Auto-refresh timer                                  │ │
│  │  - Manual refresh button                               │ │
│  │  - Responsive layout                                   │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            │ HTTP
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              ASP.NET Core MVC Application                    │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  MonitoringController                                  │ │
│  │  - Index() → Returns dashboard view                    │ │
│  │  - RefreshMetrics() → Returns JSON with latest data    │ │
│  └────────────────────────────────────────────────────────┘ │
│                            │                                 │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  IServerMonitoringService                              │ │
│  │  - GetAllServerMetricsAsync()                          │ │
│  └────────────────────────────────────────────────────────┘ │
│                            │                                 │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  ServerMonitoringService                               │ │
│  │  - Parallel API calls to all servers                   │ │
│  │  - Error handling & timeout management                 │ │
│  │  - Data aggregation & deduplication                    │ │
│  └────────────────────────────────────────────────────────┘ │
│                            │                                 │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  HttpClient (Windows Auth)                             │ │
│  │  - UseDefaultCredentials = true                        │ │
│  │  - Configured timeout                                  │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            │ HTTP (Windows Auth)
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Target Servers (1..N)                     │
│  - GET /api/sessionmetrics/active-users                      │
│  - GET /api/sessionmetrics/server-stats                      │
│  - GET /api/sessionmetrics/memory-stats                      │
└─────────────────────────────────────────────────────────────┘
```

### Project Structure

```
ServerMonitoringDashboard/
├── Controllers/
│   └── MonitoringController.cs
├── Services/
│   ├── IServerMonitoringService.cs
│   └── ServerMonitoringService.cs
├── ViewModels/
│   ├── MonitoringViewModel.cs
│   └── ServerMetrics.cs
├── Configuration/
│   └── MonitoringSettings.cs
├── Views/
│   ├── Shared/
│   │   └── _Layout.cshtml
│   └── Monitoring/
│       ├── Index.cshtml
│       └── _ServerMetricsPartial.cshtml
├── wwwroot/
│   ├── css/
│   │   └── monitoring.css
│   └── js/
│       └── monitoring.js
├── appsettings.json
├── appsettings.Development.json
├── Program.cs
└── ServerMonitoringDashboard.csproj
```

## Components and Interfaces

### 1. Configuration Layer

#### MonitoringSettings.cs
Strongly-typed configuration class that maps to appsettings.json:

```csharp
public class MonitoringSettings
{
    public List<string> ServerUrls { get; set; } = new();
    public int RefreshIntervalSeconds { get; set; } = 10;
    public int RequestTimeoutSeconds { get; set; } = 5;
}
```

**Design Decisions:**
- Use List<string> for flexibility in adding/removing servers
- Provide sensible defaults (10s refresh, 5s timeout)
- Validate in Program.cs during startup

### 2. Service Layer

#### IServerMonitoringService.cs
Service interface for fetching and aggregating server metrics:

```csharp
public interface IServerMonitoringService
{
    Task<MonitoringViewModel> GetAllServerMetricsAsync();
}
```

**Design Decisions:**
- Single method keeps interface simple
- Returns complete view model ready for rendering
- Async for non-blocking I/O operations

#### ServerMonitoringService.cs
Implementation that orchestrates parallel API calls:

**Key Responsibilities:**
1. Fetch metrics from all servers in parallel using Task.WhenAll
2. Call three endpoints per server (/active-users, /server-stats, /memory-stats)
3. Measure response time for each server
4. Handle errors gracefully (timeout, network, HTTP errors, JSON parsing)
5. Aggregate data across servers (unique users, total sessions)
6. Return MonitoringViewModel with all data

**Design Decisions:**
- Use HttpClient injected via DI (configured with Windows Auth)
- Parallel execution with Task.WhenAll for performance
- Stopwatch for accurate response time measurement
- Try-catch per server to isolate failures
- Case-insensitive JSON deserialization (JsonSerializerOptions)
- Timeout handled via HttpClient.Timeout property
- Deduplicate users using HashSet<string>

**Error Handling Strategy:**
- Network errors → IsOnline = false, ErrorMessage = exception message
- Timeout → IsOnline = false, ErrorMessage = "Request timed out"
- HTTP errors → IsOnline = false, ErrorMessage = "HTTP {statusCode}"
- JSON parsing errors → IsOnline = false, ErrorMessage = "Invalid response format"
- Continue processing other servers even if one fails

### 3. Controller Layer

#### MonitoringController.cs

**Actions:**

1. **Index() → IActionResult**
   - Initial page load
   - Returns View with empty or cached data
   - Sets up the dashboard structure

2. **RefreshMetrics() → JsonResult**
   - Called by JavaScript for auto-refresh
   - Calls IServerMonitoringService.GetAllServerMetricsAsync()
   - Returns JSON with MonitoringViewModel
   - Used for partial updates without full page reload

**Design Decisions:**
- Separate actions for initial load vs. refresh for efficiency
- Return JSON for AJAX calls to minimize bandwidth
- Use async actions for scalability
- Inject IServerMonitoringService via constructor

### 4. View Layer

#### Views/Monitoring/Index.cshtml

**Structure:**
```html
<div class="dashboard-container">
  <!-- Summary Cards Section -->
  <div class="summary-cards">
    <div class="card">Total Users: {count}</div>
    <div class="card">Total Sessions: {count}</div>
    <div class="card">Online Servers: {count}</div>
    <div class="card">Last Refresh: {timestamp}</div>
  </div>

  <!-- Manual Refresh Button -->
  <button id="refreshBtn">🔄 Refresh Now</button>

  <!-- Server Metrics Grid -->
  <div id="serverMetrics" class="server-grid">
    <!-- Rendered by _ServerMetricsPartial.cshtml -->
  </div>

  <!-- All Active Users Section -->
  <div class="all-users-section">
    <h3>All Active Users</h3>
    <div class="user-tags">
      <!-- User badges -->
    </div>
  </div>
</div>
```

**Design Decisions:**
- Use data attributes for JavaScript interaction
- Semantic HTML structure
- Accessibility considerations (ARIA labels)
- Partial view for server cards to enable reusability

#### Views/Monitoring/_ServerMetricsPartial.cshtml

**Structure per server:**
```html
<div class="server-card {online-class}">
  <div class="server-header">
    <h3>{status-icon} {serverName}</h3>
    <span class="response-time">{responseTime}ms</span>
  </div>
  
  <div class="metrics-section">
    <div class="metric">Active Users: {count}</div>
    <div class="metric">Sessions: {count}</div>
    <div class="metric">Working Set: {mb} MB</div>
    <div class="metric">Private Memory: {mb} MB</div>
  </div>
  
  <div class="load-distribution">
    <label>Load: {percentage}%</label>
    <div class="progress-bar">
      <div class="progress-fill" style="width: {percentage}%"></div>
    </div>
  </div>
  
  <div class="active-users-list">
    <span class="user-tag">{username}</span>
    ...
  </div>
  
  <div class="error-message" *ngIf="!isOnline">
    ❌ {errorMessage}
  </div>
</div>
```

**Design Decisions:**
- Conditional rendering based on IsOnline status
- Emoji icons (✅ ❌ ⚠️) for visual feedback
- Progress bar using CSS width percentage
- Tag-style user display for readability

## Data Models

### ViewModels/MonitoringViewModel.cs

```csharp
public class MonitoringViewModel
{
    public List<ServerMetrics> Servers { get; set; } = new();
    public DateTime LastRefresh { get; set; }
    public int TotalUniqueUsers { get; set; }
    public int TotalSessions { get; set; }
    public List<string> AllActiveUsers { get; set; } = new();
    public bool HasErrors { get; set; }
    public int OnlineServerCount { get; set; }
    public bool HasLoadImbalance { get; set; }
}
```

**Calculated Properties:**
- TotalUniqueUsers: Deduplicated count across all servers
- TotalSessions: Sum of ActiveSessions from all online servers
- AllActiveUsers: Distinct, sorted list of usernames
- HasErrors: True if any server is offline
- OnlineServerCount: Count of servers with IsOnline = true
- HasLoadImbalance: True if any server has >2x load of another

### ViewModels/ServerMetrics.cs

```csharp
public class ServerMetrics
{
    // Server Identity
    public string ServerName { get; set; }
    public string ServerUrl { get; set; }
    
    // Status
    public bool IsOnline { get; set; }
    public string ErrorMessage { get; set; }
    public int ResponseTimeMs { get; set; }
    
    // Active Users Endpoint Data
    public int ActiveUserCount { get; set; }
    public List<string> ActiveUsernames { get; set; } = new();
    
    // Server Stats Endpoint Data
    public int ActiveUsersThisServer { get; set; }
    public int TotalActiveUsers { get; set; }
    
    // Memory Stats Endpoint Data
    public double WorkingSetMB { get; set; }
    public double PrivateMemoryMB { get; set; }
    public int ActiveSessions { get; set; }
    public double EstimatedTrackingMemoryKB { get; set; }
    
    // Metadata
    public DateTime Timestamp { get; set; }
    
    // Calculated Properties
    public double LoadPercentage { get; set; }
    public string StatusClass { get; set; } // "online" or "offline"
    public string ResponseTimeClass { get; set; } // "fast", "slow", "timeout"
}
```

### API Response Models

Internal models for deserializing API responses:

```csharp
// For /api/sessionmetrics/active-users
internal class ActiveUsersResponse
{
    public string ServerName { get; set; }
    public int ActiveUserCount { get; set; }
    public List<string> ActiveUsernames { get; set; }
    public Dictionary<string, int> UsersByServer { get; set; }
    public DateTime Timestamp { get; set; }
}

// For /api/sessionmetrics/server-stats
internal class ServerStatsResponse
{
    public string ServerName { get; set; }
    public int ActiveUsersThisServer { get; set; }
    public int TotalActiveUsers { get; set; }
    public DateTime Timestamp { get; set; }
}

// For /api/sessionmetrics/memory-stats
internal class MemoryStatsResponse
{
    public string ServerName { get; set; }
    public double WorkingSetMB { get; set; }
    public double PrivateMemoryMB { get; set; }
    public int ActiveSessions { get; set; }
    public double EstimatedTrackingMemoryKB { get; set; }
    public DateTime Timestamp { get; set; }
}
```

## Error Handling

### Service Layer Error Handling

**Per-Server Error Isolation:**
```csharp
foreach (var serverUrl in serverUrls)
{
    try
    {
        // Fetch metrics
    }
    catch (TaskCanceledException)
    {
        // Timeout
        serverMetrics.IsOnline = false;
        serverMetrics.ErrorMessage = "Request timed out";
    }
    catch (HttpRequestException ex)
    {
        // Network error
        serverMetrics.IsOnline = false;
        serverMetrics.ErrorMessage = $"Connection failed: {ex.Message}";
    }
    catch (JsonException)
    {
        // Invalid JSON
        serverMetrics.IsOnline = false;
        serverMetrics.ErrorMessage = "Invalid response format";
    }
    catch (Exception ex)
    {
        // Unexpected error
        serverMetrics.IsOnline = false;
        serverMetrics.ErrorMessage = $"Error: {ex.Message}";
    }
}
```

**Logging Strategy:**
- Log errors at Warning level for individual server failures
- Log errors at Error level for configuration issues
- Include server URL and exception details in logs
- Use ILogger<ServerMonitoringService> injected via DI

### Controller Layer Error Handling

```csharp
try
{
    var viewModel = await _monitoringService.GetAllServerMetricsAsync();
    return Json(viewModel);
}
catch (Exception ex)
{
    _logger.LogError(ex, "Failed to refresh metrics");
    return StatusCode(500, new { error = "Failed to fetch metrics" });
}
```

### Frontend Error Handling

**JavaScript error handling:**
- Display error message if AJAX call fails
- Continue auto-refresh even after errors
- Show user-friendly error messages
- Retry failed requests on next interval

## Extensibility for Future Monitoring

The architecture is designed to be extensible for monitoring additional aspects of applications:

**Current Implementation:**
- Session metrics (active users, sessions)
- Memory statistics (working set, private memory)
- Server statistics (load distribution)

**Future Extension Points:**

1. **Additional Endpoints:**
   - Add new methods to IServerMonitoringService for different metric types
   - Create new response models for different API endpoints
   - Extend ServerMetrics with new properties

2. **Pluggable Monitoring Modules:**
   - Create IMetricProvider interface for different metric sources
   - Implement providers for: database metrics, cache metrics, queue metrics, etc.
   - Register providers in DI container

3. **Custom Dashboards:**
   - Add new controllers for different monitoring views
   - Create specialized ViewModels for different metric types
   - Reuse ServerMonitoringService pattern for consistency

4. **Metric History:**
   - Add data persistence layer (optional)
   - Store historical metrics for trend analysis
   - Create time-series views and charts

**Design Principles for Extensions:**
- Keep services focused and single-purpose
- Use dependency injection for flexibility
- Maintain separation between data fetching and presentation
- Follow the same error handling patterns

## UI Design Specifications

### Color Scheme

```css
:root {
    --primary: #3498db;      /* Blue */
    --success: #27ae60;      /* Green */
    --warning: #f39c12;      /* Orange */
    --danger: #e74c3c;       /* Red */
    --info: #667eea;         /* Purple */
    --secondary: #95a5a6;    /* Gray */
    --background: #f5f7fa;   /* Light gray */
    --card-bg: #ffffff;      /* White */
    --text-primary: #2c3e50; /* Dark gray */
    --text-secondary: #7f8c8d; /* Medium gray */
}
```

### Layout Structure

**Desktop (>768px):**
- Summary cards: 4 columns
- Server cards: 2-3 columns grid
- All users section: Full width

**Mobile (<768px):**
- Summary cards: 2 columns
- Server cards: 1 column
- All users section: Full width

### Component Styles

**Server Card:**
- Border radius: 12px
- Box shadow: 0 2px 8px rgba(0,0,0,0.1)
- Padding: 20px
- Background: White with gradient overlay
- Online: Green left border (4px)
- Offline: Red left border (4px)

**Progress Bar:**
- Height: 24px
- Border radius: 12px
- Background: Light gray
- Fill: Gradient (primary to info)
- Animated transition: 0.3s ease

**User Tags:**
- Display: inline-block
- Padding: 6px 12px
- Border radius: 16px
- Background: Primary color with opacity
- Margin: 4px
- Font size: 14px

### Animations

1. **Card hover effect:**
   - Transform: translateY(-4px)
   - Box shadow increase
   - Transition: 0.3s ease

2. **Progress bar fill:**
   - Width transition: 0.5s ease
   - Background gradient animation

3. **Refresh button:**
   - Rotate icon during loading
   - Disable during refresh
   - Pulse effect on hover

4. **Status indicators:**
   - Fade in/out for status changes
   - Pulse animation for warnings

## JavaScript Functionality

### Auto-Refresh Implementation

```javascript
let refreshInterval;
let isRefreshing = false;

function startAutoRefresh() {
    refreshInterval = setInterval(async () => {
        if (!document.hidden && !isRefreshing) {
            await refreshMetrics();
        }
    }, refreshIntervalMs);
}

function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
}

// Pause when page is hidden
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        stopAutoRefresh();
    } else {
        startAutoRefresh();
    }
});
```

### AJAX Refresh Implementation

```javascript
async function refreshMetrics() {
    isRefreshing = true;
    showLoadingIndicator();
    
    try {
        const response = await fetch('/Monitoring/RefreshMetrics');
        const data = await response.json();
        updateDashboard(data);
    } catch (error) {
        showError('Failed to refresh metrics');
    } finally {
        isRefreshing = false;
        hideLoadingIndicator();
    }
}

function updateDashboard(data) {
    // Update summary cards
    document.getElementById('totalUsers').textContent = data.totalUniqueUsers;
    document.getElementById('totalSessions').textContent = data.totalSessions;
    document.getElementById('onlineServers').textContent = data.onlineServerCount;
    document.getElementById('lastRefresh').textContent = formatTimestamp(data.lastRefresh);
    
    // Update server metrics (replace HTML)
    document.getElementById('serverMetrics').innerHTML = renderServerCards(data.servers);
    
    // Update all users list
    document.getElementById('allUsers').innerHTML = renderUserTags(data.allActiveUsers);
}
```

## Program.cs Configuration

```csharp
var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllersWithViews();

// Configure monitoring settings
builder.Services.Configure<MonitoringSettings>(
    builder.Configuration.GetSection("MonitoringSettings"));

// Validate configuration
var monitoringSettings = builder.Configuration
    .GetSection("MonitoringSettings")
    .Get<MonitoringSettings>();

if (monitoringSettings?.ServerUrls == null || !monitoringSettings.ServerUrls.Any())
{
    throw new InvalidOperationException(
        "MonitoringSettings:ServerUrls must be configured with at least one server URL");
}

// Register HttpClient with Windows Authentication
builder.Services.AddHttpClient<IServerMonitoringService, ServerMonitoringService>()
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        UseDefaultCredentials = true,
        PreAuthenticate = true
    })
    .ConfigureHttpClient((sp, client) =>
    {
        var settings = sp.GetRequiredService<IOptions<MonitoringSettings>>().Value;
        client.Timeout = TimeSpan.FromSeconds(settings.RequestTimeoutSeconds);
    });

// Add logging
builder.Services.AddLogging(logging =>
{
    logging.AddConsole();
    logging.AddDebug();
});

var app = builder.Build();

// Configure middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Monitoring}/{action=Index}/{id?}");

app.Run();
```

**Design Decisions:**
- Default route points to Monitoring/Index for immediate dashboard access
- HttpClient configured with timeout from settings
- PreAuthenticate = true for efficiency with Windows Auth
- Configuration validation at startup to fail fast
- Logging configured for both console and debug output

## Performance Considerations

1. **Parallel API Calls**: Use Task.WhenAll to fetch all servers simultaneously
2. **Partial Updates**: AJAX refresh only updates data, not full page reload
3. **Pause on Hidden**: Stop auto-refresh when tab is hidden to save resources
4. **HttpClient Reuse**: Single HttpClient instance via DI (connection pooling)
5. **Timeout Configuration**: Prevent slow servers from blocking dashboard
6. **Minimal JSON**: Return only necessary data in refresh endpoint
7. **CSS Animations**: Use GPU-accelerated transforms for smooth animations
8. **Debounce Manual Refresh**: Prevent multiple simultaneous refresh requests
