namespace ServerMonitoringDashboard.ViewModels;

public class MonitoringViewModel
{
    public List<ServerMetrics> Servers { get; set; } = new();
    public DateTime LastRefresh { get; set; }
    public int TotalUniqueUsers { get; set; }
    public int TotalSessions { get; set; }
    public List<string> AllActiveUsers { get; set; } = new();
    public bool HasErrors { get; set; }
    public int OnlineServerCount { get; set; }
    public bool HasLoadImbalance { get; set; }
}
