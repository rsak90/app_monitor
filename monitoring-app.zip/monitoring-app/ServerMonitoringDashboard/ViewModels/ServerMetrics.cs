namespace ServerMonitoringDashboard.ViewModels;

public class ServerMetrics
{
    // Server Identity
    public string ServerName { get; set; } = string.Empty;
    public string ServerUrl { get; set; } = string.Empty;
    
    // Status
    public bool IsOnline { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;
    public int ResponseTimeMs { get; set; }
    
    // Active Users Endpoint Data
    public int ActiveUserCount { get; set; }
    public List<string> ActiveUsernames { get; set; } = new();
    
    // Server Stats Endpoint Data
    public int ActiveUsersThisServer { get; set; }
    public int TotalActiveUsers { get; set; }
    
    // Memory Stats Endpoint Data
    public double WorkingSetMB { get; set; }
    public double PrivateMemoryMB { get; set; }
    public int ActiveSessions { get; set; }
    public double EstimatedTrackingMemoryKB { get; set; }
    
    // Metadata
    public DateTime Timestamp { get; set; }
    
    // Calculated Properties
    public double LoadPercentage { get; set; }
    public string StatusClass { get; set; } = string.Empty;
    public string ResponseTimeClass { get; set; } = string.Empty;
}
