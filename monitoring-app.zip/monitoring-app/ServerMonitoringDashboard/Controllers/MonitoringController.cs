using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using ServerMonitoringDashboard.Configuration;
using ServerMonitoringDashboard.Services;

namespace ServerMonitoringDashboard.Controllers;

public class MonitoringController : Controller
{
    private readonly IServerMonitoringService _monitoringService;
    private readonly ILogger<MonitoringController> _logger;
    private readonly MonitoringSettings _settings;

    public MonitoringController(
        IServerMonitoringService monitoringService,
        ILogger<MonitoringController> logger,
        IOptions<MonitoringSettings> settings)
    {
        _monitoringService = monitoringService;
        _logger = logger;
        _settings = settings.Value;
    }

    public async Task<IActionResult> Index()
    {
        ViewBag.RefreshIntervalSeconds = _settings.RefreshIntervalSeconds;
        return View();
    }

    [HttpGet]
    public async Task<JsonResult> RefreshMetrics()
    {
        try
        {
            var viewModel = await _monitoringService.GetAllServerMetricsAsync();
            return Json(viewModel);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to refresh metrics");
            return Json(new { error = "Failed to fetch metrics" });
        }
    }
}
