using Microsoft.Extensions.Options;
using ServerMonitoringDashboard.Configuration;
using ServerMonitoringDashboard.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configure monitoring settings
builder.Services.Configure<MonitoringSettings>(
    builder.Configuration.GetSection("MonitoringSettings"));

// Validate configuration at startup
var monitoringSettings = builder.Configuration
    .GetSection("MonitoringSettings")
    .Get<MonitoringSettings>();

if (monitoringSettings?.ServerUrls == null || !monitoringSettings.ServerUrls.Any())
{
    throw new InvalidOperationException(
        "MonitoringSettings:ServerUrls must be configured with at least one server URL in appsettings.json");
}

// Register HttpClient with Windows Authentication
builder.Services.AddHttpClient<IServerMonitoringService, ServerMonitoringService>()
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        UseDefaultCredentials = true,
        PreAuthenticate = true
    })
    .ConfigureHttpClient((sp, client) =>
    {
        var settings = sp.GetRequiredService<IOptions<MonitoringSettings>>().Value;
        client.Timeout = TimeSpan.FromSeconds(settings.RequestTimeoutSeconds);
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Monitoring}/{action=Index}/{id?}");

app.Run();
