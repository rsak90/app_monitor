// Auto-refresh and dashboard management
let refreshInterval = null;
let isRefreshing = false;
let refreshIntervalMs = 10000; // Default 10 seconds

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Get refresh interval from page data attribute
    const container = document.querySelector('.dashboard-container');
    if (container) {
        const intervalSeconds = parseInt(container.dataset.refreshInterval) || 10;
        refreshIntervalMs = intervalSeconds * 1000;
    }

    // Initial refresh
    refreshMetrics();

    // Start auto-refresh
    startAutoRefresh();

    // Setup manual refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            refreshMetrics();
        });
    }

    // Pause auto-refresh when page is hidden
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            stopAutoRefresh();
        } else {
            startAutoRefresh();
        }
    });
});

// Start auto-refresh mechanism
function startAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }

    refreshInterval = setInterval(function() {
        if (!document.hidden && !isRefreshing) {
            refreshMetrics();
        }
    }, refreshIntervalMs);
}

// Stop auto-refresh mechanism
function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}


// Fetch metrics from server
async function refreshMetrics() {
    if (isRefreshing) {
        return;
    }

    isRefreshing = true;
    showLoadingIndicator();

    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.disabled = true;
        refreshBtn.classList.add('loading');
    }

    try {
        const response = await fetch('/Monitoring/RefreshMetrics');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.error) {
            showError(data.error);
        } else {
            updateDashboard(data);
        }
    } catch (error) {
        console.error('Failed to refresh metrics:', error);
        showError('Failed to refresh metrics. Please try again.');
    } finally {
        isRefreshing = false;
        hideLoadingIndicator();

        if (refreshBtn) {
            refreshBtn.disabled = false;
            refreshBtn.classList.remove('loading');
        }
    }
}

// Show loading indicator
function showLoadingIndicator() {
    const indicator = document.getElementById('loadingIndicator');
    if (indicator) {
        indicator.style.display = 'inline';
    }
}

// Hide loading indicator
function hideLoadingIndicator() {
    const indicator = document.getElementById('loadingIndicator');
    if (indicator) {
        indicator.style.display = 'none';
    }
}

// Show error message
function showError(message) {
    // You can enhance this with a toast notification or modal
    console.error(message);
    alert(message);
}


// Update dashboard with new data
function updateDashboard(data) {
    // Update summary cards
    updateElement('totalUsers', data.totalUniqueUsers);
    updateElement('totalSessions', data.totalSessions);
    updateElement('onlineServers', data.onlineServerCount);
    updateElement('lastRefresh', formatTimestamp(data.lastRefresh));
    updateElement('userCount', data.totalUniqueUsers);

    // Update server metrics
    const serverMetrics = document.getElementById('serverMetrics');
    if (serverMetrics && data.servers) {
        serverMetrics.innerHTML = renderServerCards(data.servers);
    }

    // Update all active users
    const allUsers = document.getElementById('allUsers');
    if (allUsers && data.allActiveUsers) {
        allUsers.innerHTML = renderUserTags(data.allActiveUsers);
    }
}

// Update element text content
function updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

// Format timestamp for display
function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
}

// Render server cards HTML
function renderServerCards(servers) {
    if (!servers || servers.length === 0) {
        return '<p>No servers configured</p>';
    }

    return servers.map(server => {
        const statusClass = server.isOnline ? 'online' : 'offline';
        const statusIcon = server.isOnline ? '✅' : '❌';

        let content = `
            <div class="server-card ${statusClass}">
                <div class="server-header">
                    <h3>
                        <span class="status-icon">${statusIcon}</span>
                        ${escapeHtml(server.serverName)}
                    </h3>
                    <span class="response-time ${server.responseTimeClass}">
                        ${server.responseTimeMs} ms
                    </span>
                </div>
        `;

        if (server.isOnline) {
            content += `
                <div class="metrics-section">
                    <div class="metric">
                        <span class="metric-label">Active Users:</span>
                        <span class="metric-value">${server.activeUserCount}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Sessions:</span>
                        <span class="metric-value">${server.activeSessions}</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Working Set:</span>
                        <span class="metric-value">${server.workingSetMB.toFixed(2)} MB</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Private Memory:</span>
                        <span class="metric-value">${server.privateMemoryMB.toFixed(2)} MB</span>
                    </div>
                </div>

                <div class="load-distribution">
                    <div class="load-header">
                        <span class="load-label">Load Distribution</span>
                        <span class="load-percentage">${server.loadPercentage.toFixed(1)}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${server.loadPercentage.toFixed(1)}%"></div>
                    </div>
                </div>
            `;

            if (server.activeUsernames && server.activeUsernames.length > 0) {
                content += `
                    <div class="active-users-list">
                        <div class="users-label">Active Users:</div>
                        <div class="user-tags-container">
                            ${server.activeUsernames.map(username => 
                                `<span class="user-tag">${escapeHtml(username)}</span>`
                            ).join('')}
                        </div>
                    </div>
                `;
            }
        } else {
            content += `
                <div class="error-message">
                    <span class="error-icon">❌</span>
                    <span class="error-text">${escapeHtml(server.errorMessage)}</span>
                </div>
            `;
        }

        content += '</div>';
        return content;
    }).join('');
}

// Render user tags HTML
function renderUserTags(users) {
    if (!users || users.length === 0) {
        return '<p>No active users</p>';
    }

    return users.map(username => 
        `<span class="user-tag">${escapeHtml(username)}</span>`
    ).join('');
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
