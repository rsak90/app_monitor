namespace ServerMonitoringDashboard.Configuration
{
    public class MonitoringSettings
    {
        public List<string> ServerUrls { get; set; } = new();
        public int RefreshIntervalSeconds { get; set; } = 10;
        public int RequestTimeoutSeconds { get; set; } = 5;
    }
}
