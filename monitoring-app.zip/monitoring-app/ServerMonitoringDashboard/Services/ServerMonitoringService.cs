using System.Diagnostics;
using System.Text.Json;
using Microsoft.Extensions.Options;
using ServerMonitoringDashboard.Configuration;
using ServerMonitoringDashboard.ViewModels;

namespace ServerMonitoringDashboard.Services;

public class ServerMonitoringService : IServerMonitoringService
{
    private readonly HttpClient _httpClient;
    private readonly MonitoringSettings _settings;

    public ServerMonitoringService(HttpClient httpClient, IOptions<MonitoringSettings> settings)
    {
        _httpClient = httpClient;
        _settings = settings.Value;
    }

    public async Task<MonitoringViewModel> GetAllServerMetricsAsync()
    {
        var viewModel = new MonitoringViewModel
        {
            LastRefresh = DateTime.UtcNow
        };

        // Fetch metrics from all servers in parallel
        var serverTasks = _settings.ServerUrls.Select(serverUrl => FetchServerMetricsAsync(serverUrl)).ToList();
        var serverMetrics = await Task.WhenAll(serverTasks);

        viewModel.Servers = serverMetrics.ToList();

        // Aggregate data and perform calculations
        AggregateMetrics(viewModel);

        return viewModel;
    }

    private void AggregateMetrics(MonitoringViewModel viewModel)
    {
        var onlineServers = viewModel.Servers.Where(s => s.IsOnline).ToList();

        // Calculate TotalUniqueUsers by deduplicating usernames across all servers
        var allUsernames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var server in onlineServers)
        {
            foreach (var username in server.ActiveUsernames)
            {
                allUsernames.Add(username);
            }
        }
        viewModel.TotalUniqueUsers = allUsernames.Count;

        // Calculate TotalSessions by summing ActiveSessions from all online servers
        viewModel.TotalSessions = onlineServers.Sum(s => s.ActiveSessions);

        // Create AllActiveUsers list with distinct, sorted usernames
        viewModel.AllActiveUsers = allUsernames.OrderBy(u => u, StringComparer.OrdinalIgnoreCase).ToList();

        // Calculate OnlineServerCount
        viewModel.OnlineServerCount = onlineServers.Count;

        // Set HasErrors if any server is offline
        viewModel.HasErrors = viewModel.Servers.Any(s => !s.IsOnline);

        // Calculate LoadPercentage for each server
        foreach (var server in viewModel.Servers)
        {
            if (server.IsOnline && viewModel.TotalUniqueUsers > 0)
            {
                server.LoadPercentage = (double)server.ActiveUserCount / viewModel.TotalUniqueUsers * 100;
            }
            else
            {
                server.LoadPercentage = 0;
            }

            // Set StatusClass
            server.StatusClass = server.IsOnline ? "online" : "offline";

            // Set ResponseTimeClass
            if (!server.IsOnline)
            {
                server.ResponseTimeClass = "timeout";
            }
            else if (server.ResponseTimeMs < 1000)
            {
                server.ResponseTimeClass = "fast";
            }
            else
            {
                server.ResponseTimeClass = "slow";
            }
        }

        // Detect load imbalance
        if (onlineServers.Count > 1)
        {
            var maxLoad = onlineServers.Max(s => s.LoadPercentage);
            var minLoad = onlineServers.Where(s => s.LoadPercentage > 0).DefaultIfEmpty().Min(s => s?.LoadPercentage ?? 0);

            if (minLoad > 0 && maxLoad > minLoad * 2)
            {
                viewModel.HasLoadImbalance = true;
            }
        }
    }

    private async Task<ServerMetrics> FetchServerMetricsAsync(string serverUrl)
    {
        var metrics = new ServerMetrics
        {
            ServerUrl = serverUrl,
            ServerName = ExtractServerName(serverUrl),
            Timestamp = DateTime.UtcNow
        };

        var stopwatch = Stopwatch.StartNew();

        try
        {
            // Create three parallel tasks to fetch data from different endpoints
            var activeUsersTask = _httpClient.GetStringAsync($"{serverUrl}/api/sessionmetrics/active-users");
            var serverStatsTask = _httpClient.GetStringAsync($"{serverUrl}/api/sessionmetrics/server-stats");
            var memoryStatsTask = _httpClient.GetStringAsync($"{serverUrl}/api/sessionmetrics/memory-stats");

            await Task.WhenAll(activeUsersTask, serverStatsTask, memoryStatsTask);

            stopwatch.Stop();
            metrics.ResponseTimeMs = (int)stopwatch.ElapsedMilliseconds;

            // Parse responses
            await ParseActiveUsersResponse(activeUsersTask.Result, metrics);
            await ParseServerStatsResponse(serverStatsTask.Result, metrics);
            await ParseMemoryStatsResponse(memoryStatsTask.Result, metrics);

            metrics.IsOnline = true;
        }
        catch (TaskCanceledException)
        {
            stopwatch.Stop();
            metrics.ResponseTimeMs = (int)stopwatch.ElapsedMilliseconds;
            metrics.IsOnline = false;
            metrics.ErrorMessage = "Request timed out";
        }
        catch (HttpRequestException ex)
        {
            stopwatch.Stop();
            metrics.ResponseTimeMs = (int)stopwatch.ElapsedMilliseconds;
            metrics.IsOnline = false;
            metrics.ErrorMessage = $"Network error: {ex.Message}";
        }
        catch (JsonException)
        {
            stopwatch.Stop();
            metrics.ResponseTimeMs = (int)stopwatch.ElapsedMilliseconds;
            metrics.IsOnline = false;
            metrics.ErrorMessage = "Invalid response format";
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            metrics.ResponseTimeMs = (int)stopwatch.ElapsedMilliseconds;
            metrics.IsOnline = false;
            metrics.ErrorMessage = ex.Message;
        }

        return metrics;
    }

    private string ExtractServerName(string serverUrl)
    {
        var uri = new Uri(serverUrl);
        return uri.Host;
    }

    private Task ParseActiveUsersResponse(string json, ServerMetrics metrics)
    {
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        var data = JsonSerializer.Deserialize<ActiveUsersResponse>(json, options);
        
        if (data != null)
        {
            metrics.ActiveUserCount = data.ActiveUserCount;
            metrics.ActiveUsernames = data.ActiveUsernames ?? new List<string>();
        }

        return Task.CompletedTask;
    }

    private Task ParseServerStatsResponse(string json, ServerMetrics metrics)
    {
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        var data = JsonSerializer.Deserialize<ServerStatsResponse>(json, options);
        
        if (data != null)
        {
            metrics.ActiveUsersThisServer = data.ActiveUsersThisServer;
            metrics.TotalActiveUsers = data.TotalActiveUsers;
        }

        return Task.CompletedTask;
    }

    private Task ParseMemoryStatsResponse(string json, ServerMetrics metrics)
    {
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        var data = JsonSerializer.Deserialize<MemoryStatsResponse>(json, options);
        
        if (data != null)
        {
            metrics.WorkingSetMB = data.WorkingSetMB;
            metrics.PrivateMemoryMB = data.PrivateMemoryMB;
            metrics.ActiveSessions = data.ActiveSessions;
            metrics.EstimatedTrackingMemoryKB = data.EstimatedTrackingMemoryKB;
        }

        return Task.CompletedTask;
    }

    // Response DTOs
    private class ActiveUsersResponse
    {
        public int ActiveUserCount { get; set; }
        public List<string>? ActiveUsernames { get; set; }
    }

    private class ServerStatsResponse
    {
        public int ActiveUsersThisServer { get; set; }
        public int TotalActiveUsers { get; set; }
    }

    private class MemoryStatsResponse
    {
        public double WorkingSetMB { get; set; }
        public double PrivateMemoryMB { get; set; }
        public int ActiveSessions { get; set; }
        public double EstimatedTrackingMemoryKB { get; set; }
    }
}
