using ServerMonitoringDashboard.ViewModels;

namespace ServerMonitoringDashboard.Services;

public interface IServerMonitoringService
{
    Task<MonitoringViewModel> GetAllServerMetricsAsync();
}
